<table width="<?php echo empty($_GET['page']) ? '350' : '100%'; ?>" align="center" border="0" cellspacing="0" cellpadding="0" style="padding-top: px">
	<tr>
		<td align="right">
			<font size="1">[ <?php echo round(getTime() - TIME1, 4); ?> Seconds ]</font>
		</td>
	</tr>
</table>
</body>
</html>