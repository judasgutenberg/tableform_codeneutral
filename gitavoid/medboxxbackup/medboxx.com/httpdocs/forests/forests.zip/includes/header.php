<?php
if ( !defined('TIME1') )
{
	define('TIME1', getTime());
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>txtSQLAdmin v2.0</title>
<link rel="stylesheet" type="text/css" href="includes/colors.css">
<script src="includes/headerJS.js"></script>
</head>
<body bgcolor="F5F5F5" bottommargin="0">
