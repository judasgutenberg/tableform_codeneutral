<?php 
//Gus Mueller January 2006-January 2007////////////////
//provides a web front end admin tool for any MySQL db/
//////////////////////////////////////////////////////
/////core function library///////////////////////////
////////////////////////////////////////////////////

//this is how i like my error reporting, thank you very much.  why should i give a crap about Notice?
error_reporting(E_ERROR | E_WARNING | E_PARSE );
ini_set("display_errors",true );
 
if (file_exists('constants.php'))
{

	include('constants.php');
}
else if(!contains($_SERVER['PHP_SELF'],"buildconstants.php" ))
{
	header("Location:buildconstants.php");
}

class sqldb
{
	var $c=TRUE;
	function disconDB()
	{
		mysql_close($c);
		return($c);
	}
 
	function query($strSQL , $bwlGusStyleConnect=true)
	{
		$c=FALSE;
		if ($bwlGusStyleConnect)
		{
			//echo $_SERVER["SERVER_NAME"] . "<br>";
			$bwlNeedConnection=false;
			
			if (!$c)
			{
				if ($_SERVER["SERVER_NAME"]=="localhost")
				{
					$c = mysql_connect(con_server_localhost, con_user_localhost,con_pwd_localhost);
				}
				else
				{
					$c = mysql_connect(con_server_web, con_user_web, con_pwd_web);
					
				}
				mysql_select_db(our_db);
				$bwlNeedConnection=true;
			}
			$res= mysql_query($strSQL);
			if ($bwlNeedConnection)
			{
				//mysql_close($c);
			}
 		}
		else
		{
			$res= tep_db_query($strSQL);
		}
		$out=array();
		$count=0;
		if (gettype($res)=="resource")
		{
			for ($i=0; $i<mysql_num_rows($res); $i++)
			{
				$record=mysql_fetch_assoc($res);
			 
				$out[$count]=$record;
				$count++;
			}
 		}
 
		return $out;
	}
}


function parseBetween($strIn, $strStart, $strEnd)
//a great function for returning the string between two known strings ($strStart, $strEnd) within $strIn
	{
		$found="";
		$pos1 = strpos($strIn, $strStart) + strlen($strStart);
		if ($pos1+1<strlen($strIn))
		{
			$pos2 = strpos($strIn, $strEnd, $pos1+1);
		}
		if ($pos1<$pos2)
		{
			$found=substr($strIn, $pos1, ($pos2-$pos1));
		}
		return($found);
        
	}
    
function PageNumber($in)
{
//finds the proper page in a page-tagged text
	$strTag="[pagebreak]";
	$arrThis=explode($strTag, $in);
	$out=count($arrThis);
	return $out;
}


function SpecificPageOfPagedText($in, $intPage)
{
//finds the proper page in a page-tagged text
	$strTag="[pagebreak]";
	if($intPage=="")
	{
		$intPage=0;
	}		
	$arrThis=explode($strTag, $in);
	$out=$arrThis[$intPage];
	return $out;
}
 
function prevnextlinks($strDB, $strThisTable, $sortcolumn, $id_column, $strLabel,   $type, $strAdditionalField="", $strAdditionalValue="", $this)
{
	//$this contains the value of the sortable column we're presently on
	$sql=conDB();
	//echo $this . "<br>";
	$strPHP=$_SERVER['PHP_SELF'];
	$strAdditionalSQL="";
	if ($strAdditionalField!="")
	{
		$strAdditionalSQL=" AND " . $strAdditionalField  . "='" . $strAdditionalValue . "'";
	}
	$strBaseSQL="select  * from " . $strDB . "." . $strThisTable . " where " . $sortcolumn;
	if ($type=="newer")
	{
		$strSQL=$strBaseSQL . ">'" . $this . "' " . $strAdditionalSQL . " ORDER BY " . $sortcolumn . " asc limit 0,1";
		$verbiage="Next";
		$pre="";
		$post="&gt;&gt;";
	}
	else
	{
		$strSQL=$strBaseSQL . "<'" . $this . "' " . $strAdditionalSQL . " ORDER BY " . $sortcolumn . " desc limit 0,1";
		$verbiage="Last";
		$pre="&#60;&#60;";
		$post="";
	}
	//echo $strSQL;
	$nrecords = $sql->query($strSQL);
	$nrecord = $nrecords[0];
	$id=$nrecord[$id_column];
	//show the links only if an ID for the next one is found

	if ($id!="")
	{
		$url=$strPHP . "?" . replaceSpecificQueryVariable($id_column, $id);
		$link=$pre . " <a href=\"" . $url .   "\"   class=\"text_news10\">" . $verbiage  . " " . $strLabel . "</a>" . $post;
	}
	return $link;
}



function PageHeader($strTitle, $strExtrajs,$strForBackField="")
//page header for all the pages
	{
		$out="";
		$out.= "<html>
			<head>
			<meta http-equiv=\"cache-control\" content=\"no-cache\"/>
			<title>" . $strTitle . "</title>\n";
					$out.= "<link rel=\"stylesheet\" href=\"tableform_css.css\" type=\"text/css\">\n";
					$out.= "<script src=\"tableform_js.js\"><!-- --></script>
					  
			</head>";
		if (contains($strExtrajs,"complete" )  && !contains($strExtrajs,"updateopener"))//just a compressed version of what i really mean
		{
			$strExtrajs="onLoad='recrank(\"" . $strForBackField . "\")'";
		}
		else if(contains($strExtrajs,"updateopener")  && contains($strExtrajs,"complete"))
		{
			$strExtrajs="onLoad='UpdateOpener()'";
		}
		$out.= "<body " . $strExtrajs . "  marginwidth=\"0\" leftmargin=\"0\" marginheight=\"0\" topmargin=\"0\" >";

		return $out;
	}

function PageFooter()
	{
		$out="";
		//a good place to drop an ajax frame!
		$out.="\n<iframe frameborder=\"0\" marginwidth=\"0\" marginheight=\"0\" width=\"1\" height=\"1\" name=\"ajax\" src=\"\"></iframe>";
		$out.="<script src=\"wz_tooltip.js\"><!-- --></script>";
		$out.="</body>\n";
		$out.="</html>\n";
		return $out;
	}

function conDB()
{
 	$sql=new sqldb();
	return($sql);
}

function disconDB()
{
	mysql_close($c);
	 
	return($c);
}

function kdateformat($intDate)
{
	if (is_numeric($intDate))
	{
		$out=date("m.d.y", intval($intDate));
	}
	else
	{
		$out=date("m.d.y", strtotime($intDate));
	}
	//echo "<p>" . time() . " " . $intDate . " " . $out . "<p>";
	return $out;
}

function mustDisplayField($strTable, $strFieldConfig, $strFieldName)
	{
		//returns yes if $strFieldName is in $strFieldConfig for table, returns no if $strFieldName is not in the found info for table
		//returns nothing if there is no info on this table
		$arrFieldsToRequire=genericdata($strTable,0, 1, $strFieldConfig, "*", "|", true);
		$strFieldRequired="nothing";
		if (is_array($arrFieldsToRequire))
		{
			if (array_search($strFieldName, $arrFieldsToRequire)>0)
			{
				$strFieldRequired="yes";
			}
			else
			{
				$strFieldRequired="no";
			}
		}
		return $strFieldRequired;
	}
	
function GreaterFieldDisplayLogic($strTable, $strFieldConfig, $strFieldName, $intFieldCount, $intFieldLimitLo, $intFieldLimitHi)
	{
		$strFieldRequired=mustDisplayField($strTable, $strFieldConfig, $strFieldName);
		$out=false;
		//echo $intFieldLimitLo . "<br>";
 
		if ((($strFieldRequired=="yes" ||   $intFieldCount<=$intFieldLimitLo) && $intFieldCount<=$intFieldLimitHi) || ($strFieldRequired=="nothing"  && $intFieldCount<=$intFieldLimitHi))
		{	
			$out=true;
		}
		return $out;
	}
	
function qbuild($strPHP, $strDatabase, $strTable, $mode, $idfieldname, $id)
//builds a url from the given info, specific to tableform-style implementation
{
	$out=$strPHP ."?" . qpre . "db=" . $strDatabase  ;
	if ($strTable!="")
	{
		$out.="&" . qpre . "table=". $strTable;
	}
	if ($mode!="")
	{
		$out.="&" . qpre . "mode=" . $mode;
	}
	if ($idfieldname!="")
	{
		$out.="&" . qpre . "idfield=" . $idfieldname;
		if ($id!="")
		{
			$out.="&" . $idfieldname . "=" . $id;
		}
	}
	return $out;
}

function adminbreadcrumb($disablelink)
//breadcrumb nav for the admin tools
	{
		$intArgs =func_num_args();
		$out="";
		$strDelimiter=" : ";
		
		for($i=1; $i<$intArgs; $i=$i+2)
		{
			$out.="<span class=\"heading\">";
			$label=func_get_arg($i);
			$link="";
			if($i+1<$intArgs)
			{
				$link=func_get_arg($i+1);
			}
			//echo $label . " " . $link.  "<br>";
			if ($link=="" || $disablelink==true)
			{
				$out.= $label;
			}
			else
			{
				$out.="<a href=\"" .  $link .     "\">" . $label . "</a>";
			}
			$out.="</span>";
			if ($i<$intArgs-2)
			{
			
				$out.=$strDelimiter;
			}
			//echo $out . "<br>";
		}
		return $out;
	}
	
function CommmaDelimitedDump($strDatabase, $strTable, $strFields="", $strFieldDelimiter=",", $strRowDelimiter="\n", $quotecontent=true, $UserID="", $strSQL="")
//an export feature from table to file
//if $strFields is not empty, then the fields are filtered based on their mention in $strFields
{
	$sql=conDB();
	$strAdminIDRangeAddendum=UserIDToSelectAddendum($strDatabase, $strTable, $strIDFieldName, $UserID);
	if ($strSQL=="")
	{
		$strSQL="SELECT * FROM  " .  $strDatabase . "." . $strTable;
	
		$strSQL=ProperlyAppendSQLWherePhrase($strSQL, $strAdminIDRangeAddendum);
	}
	$out="";
	$records = $sql->query($strSQL);
	foreach ($records as $key=>$value )
	{
		$intFieldCount=0;
		foreach ($value as $key1 => $value1 )
		{
		
			$strpreparedcontent=doublequoteescape($value1);
			if ($quotecontent)
			{
				$strpreparedcontent='"' . $strpreparedcontent . '"';
			}
			if ($strFields!="")
			{
				//echo $key1 . " " . $strFields . "<br>";
			
				if (inList($strFields,  $key1))
				{
				
					$out.=     $strpreparedcontent .  $strFieldDelimiter;
				}
			}
			else
			{
				$out.=   $strpreparedcontent  .  $strFieldDelimiter;
			}
		}
		$out = RemoveEndCharactersIfMatch($out, $strFieldDelimiter);
		$out.=  $strRowDelimiter;
	}
	return $out;
}


////////////////////////////////////////
//UTILITIES////////////////////////////
//////////////////////////////////////

function LinkIfFile($strFile, $strQueryString, $strAnchorText, $strUnlinkedPre="", $strUnlinkedPost="")
{
	//creates a link if the linked-to file exists
	$out="";
	$strURL=$strFile;
	
	if (file_exists($strFile))
	{
		if ($strQueryString!="")
		{
		
			$strURL.="?" .  $strQueryString;
		}
		$out="<a href=\"" . $strFile . "\">" . $strAnchorText . "</a>";
	
	}
	if ($out!="")
	{
		$out=$strUnlinkedPre . $out .  $strUnlinkedPost;
	}
	return $out;
}

function simplelinenav($strconfig)
{
	$strPHP=$_SERVER['PHP_SELF'] . IfAThenB($_SERVER['QUERY_STRING'], "?") . $_SERVER['QUERY_STRING'];
	//provides unified site navigation based on double-delimited strConfig having the form filename1|label1-filename2|label2...
	$arrconfig=split("-",$strconfig);
	$count=count($arrconfig);
	$out="";
 
	for ($i=0; $i<$count; $i++)
	{
		$arrthis=split("\|", $arrconfig[$i]);
		$strthisfile="/" . $arrthis[0];
	 	//echo $strthisfile . " " . $strPHP . "<br>";
		if ($strthisfile!= $strPHP)
		{
			$out.= "<a  \"  class=\"nav\" href=\"" . $strthisfile . "\">" . $arrthis[1] . "</a>" . chr(13);
		}
		else
		{
			$out.= $arrthis[1]  . chr(13);
		}
		if ($i<$count-1)
		{
			$out.=" | ";
		}
	}
	return($out);
}

function endswith($strIn, $what)
{

	if (substr($strIn, strlen($strIn)- strlen($what) , strlen($what))==$what)
	{
		return true;
	}
	return false;
}

function beginswith($strIn, $what)
{
	if (substr($strIn,0, strlen($what))==$what)
	{
		return true;
	}
	return false;
}

function contains($strIn, $what)
{
	if ($strIn!="" && $what !="")
	{
		if (strpos(" " . $strIn, $what)>0)
		{
			return true;
		}
	}
	return false;
}

function gracefuldecay()
{
	//go through the parameters and return the first that isn't empty
		$intArgs =func_num_args();
		for($i=0; $i<$intArgs; $i++)
		{
			$option=func_get_arg($i);
			if ($option!="")
			{
				return $option;
			}
		}
}

function RadioInput($name, $default, $bwlChecked=false, $onClick="",  $strStyle="",  $strClass="")
{
	return GenericInput($name, $default, $bwlChecked, $onClick,  $strStyle, $strClass, "radio");
}

function CheckboxInput($name, $default, $bwlChecked=false, $onClick="", $strStyle="", $strClass="")
{
	return GenericInput($name, $default, $bwlChecked, $onClick, $strStyle, $strClass, "checkbox");
}

function TextInput($name, $default, $size, $onClick="",  $strClass="", $strStyle="")
{
	//$out="<input id=\"id" . $name . "\" name=\"" . $name . "\" size=\"" . $size . "\" type=\"text\" value=\"" . $default . "\">\n";
	return GenericInput($name, $default, false, $onClick,  $strStyle, $strClass, "text", $size);
}

function GenericInput($name, $default, $bwlChecked=false, $onClick="",  $strStyle="", $strClass="", $type="submit", $size="")
{
	if ($onClick!="")
	{
		$onClick=" onclick='javascript:" . $onClick . "'";
	}
	$strSize ="";
	$checkedindication="";
	if ($bwlChecked)
	{
		$checkedindication=" checked ";
	}
	if ($strClass!="")
	{
		$strClass=" class='" .  $strClass . "' ";
	}
	if ($strStyle!="")
	{
		$strStyle=" style='" .  $strStyle . "' ";
	}
	if ($size!="")
	{
		$strSize=" size='" .  $size . "' ";
	}
	$out="<input" . $onClick . $checkedindication . $strClass . $strSize . $strStyle . " id=\"id" . $name . "\" name=\"" . $name . "\" type=\"" . $type . "\" value=\"" . $default . "\">\n";
	return $out;
}

function HiddenInputs($arrIn, $pre=qpre, $strListToAvoid="", $additionalprefix="")
//takes an associative array and makes it into a series of hidden  input tags
	{
		$out="";
		foreach($arrIn as $k=>$v)
		{
			if (!inList($strListToAvoid, $k))
			{ 
				$out.="<input id=\"id" . $additionalprefix . $pre .$k . "\"  name=\"" . $additionalprefix . $pre .$k . "\" value=\"" . $v . "\" type=\"hidden\">\n";
			}
		}
		return $out;
	}
	
function addBwls()
//adds all the bwls and returns the number that were true
{
	$count = func_num_args();
	$out=0;
	for ($i=0; $i<$count; $i++)
	{
		$this[$i]=func_get_arg($i);
		if ($this[$i])
		{
			$out++;
		}
	}
	return $out;
}

function IntToSQLBoul($int)
{
	if (intval($int)==1)
	{
		$out="true";
	}
	else
	{
		$out="false";
	}
	return $out;
}

function ProperlyAppendSQLWherePhrase($strSQL, $strPhrase)
	{
		if (contains($strSQL, " WHERE "))
		{
			$strSQL.= IfAThenB($strPhrase, " AND ") . $strPhrase;
		}
		else
		{
			$strSQL.= IfAThenB($strPhrase, " WHERE ") . $strPhrase;
		}
		return $strSQL;
	
	
	}
					
function ReverseDirectionSQL($strDirection)
	//this function allows me to reverse the sort order by clicking on the heading a second time
	{
		$strDirection=Alternate("ASC", "DESC", $strDirection);
		return $strDirection;
	}
	
function DateTimeForMySQL($strIn)
{
	//parses a datetime and makes it acceptable for mysql
	$timestamp=strtotime($strIn);
	return date("Y-m-d H:i:s", $timestamp);
}

function Alternate($strOptionOne, $strOptionTwo, $strOptionNow)
{
	//swap between two strings 
	if ($strOptionOne== $strOptionNow)
	{
		return $strOptionTwo;
	}
	return $strOptionOne;

} 
function deMultiple($strIn, $chrIn)
//remove multiple side-by-side instances of $chrIn - works best for things like spaces and chr(13)
	{
		$strOut=$strIn;
		while(strpos($strOut, $chrIn . $chrIn))
		{
			$strOut = str_replace( $chrIn . $chrIn, $chrIn, $strOut);
		}
		return($strOut);
	}
	
function RemoveLastCharacterIfMatch($strIn, $chrIn)
	{
		$out=$strIn;
		if (substr($strIn,  strlen($strIn)-1, 1) ==$chrIn)
		{
			$out= substr($strIn, 0, strlen($strIn)-1);
		}
		return $out;
	}
	
function RemoveFirstCharacterIfMatch($strIn, $chrIn)
	{
		$out=$strIn;
		//echo substr($strIn,   0, 1) . "<br>";
		if (substr($strIn,   0, 1) ==$chrIn)
		{
			$out= substr($strIn, 1);
		}
		return $out;
	}
	
function RemoveEndCharactersIfMatch($strIn, $chrIn)
	{
		$out= RemoveFirstCharacterIfMatch($strIn, $chrIn);
	 	$out= RemoveLastCharacterIfMatch($out, $chrIn);
		return $out;
	}

function GenericForm($arrFieldNames,  $arrLabels, $arrDefaults, $arrSizes, $arrHiddenMask, $strPHP)
{
	$strLineClass="bgclassline";
	$strClassFirst="bgclassfirst";
	$strClassSecond="bgclasssecond";
	$strOtherBgClass="bgclassother";
	$strOtherLineClass="bgclassline";
	$intDefaultSize=20;
	$out= "<table border=\"0\" cellspacing=\"1\" cellpadding=\"2\" class=\"" .$strLineClass  . "\" width=\"450\">\n";
	$out.= "<form method=\"post\" name=\"BForm\" action=\"" .  $strPHP . "\">\n";
	for($i=0; $i<count($arrFieldNames); $i++)
	{
		$strThisBgClass=Alternate($strClassFirst, $strClassSecond, $strThisBgClass);
		if ($arrHiddenMask[$i]=="1")
		{
			$out.=HiddenInputs(Array($arrFieldNames[$i]=>$arrDefaults[$i]), $pre="","", "") . "\n";
		}
		else
		{
			$out.=htmlrow($strThisBgClass, gracefuldecay($arrLabels[$i], $arrFieldNames[$i]), TextInput($arrFieldNames[$i], $arrDefaults[$i], gracefuldecay($arrSizes[$i], $intDefaultSize), "",  "", ""));
	}
		}
	$out.=htmlrow($strOtherLineClass, "&nbsp;", GenericInput("x_save", "Configure"));
	$out.= "</form>\n";
	$out.= "</table>\n";
	return $out;
}
	
function genericdata($strIn,$intTypeIn, $intTypeOut, $strTranslate, $rowdelimiter, $fielddelimiter, $bwlRow=false)
	//form of 'data' that allows you to pass in your own delimiters
	//if $bwlRow=true than return the whole row as an array
	{
		$arrTranslate=explode($rowdelimiter, $strTranslate);
		$strOut="";
		$bwlDone=1;
		$strIn=$strIn;
		$bwlDone=0;
		for ($i=0;  $i < count($arrTranslate) and $bwlDone==0; $i++)
			{
				$arrThis=explode($fielddelimiter,$arrTranslate[$i]);
				if ($intTypeIn<count($arrThis) and $intTypeOut<count($arrThis))
					{
						if ($intTypeIn==-1) 
							{
								if ($strIn==$i+'')
								{
									if ($bwlRow)
									{
										$strOut=$arrThis;
									}
									else
									{
										$strOut=$arrThis[$intTypeOut];
									}
									$bwlDone=1;
								}
								
							}
						else
							{
								if ($arrThis[$intTypeIn]==$strIn)
									{
										if ($bwlRow)
										{
											$strOut=$arrThis;
										}
										else
										{
											$strOut=$arrThis[$intTypeOut];
										}
										$bwlDone=1;
									}
							}
					}
			}
		return($strOut);
	}

function inList($strList, $item) 
//look to see if item is in the space-delimited strList (similar to my ASP version)
	{
		$arrThis=explode(' ', $strList);
		for ($t=0; $t<count($arrThis); $t++)
		{
			if ($arrThis[$t]==$item)
			{
				return true;
			}
		}
		return false;
	}
	
function pluralize($strIn)
{
	//pluralize an english word, getting it right most of the time
	//i had a bug in the original version that i fix here with the global pluralizationmethod
	$intLen=strlen($strIn);
	$endletter=substr(strtolower($strIn), $intLen-1, 1);
	$endtwoletter=substr(strtolower($strIn), $intLen-2, 2);
	$strESletters="s z c x";
	if (pluralizationmethod=="new")
	{
		$strESletters="s z x";
		if (inList("ay ey iy oy uy",$endtwoletter))
		{
			$out=$strIn. "s";
		}
		else if ($endletter=="y" )
		{
			$out=substr($strIn, 0, strlen($strIn)-1). "ies";
		}
	}
	else if ($endletter=="y" )
	{
		$out=substr($strIn, 0, strlen($strIn)-1). "ies";
	}
	elseif (inList("sh ch",$endtwoletter))
	{
		$out=$strIn. "es";
	}

	elseif (inList($strESletters, $endletter))
	{
		$out=$strIn. "es";
	}
	else
	{
		$out=$strIn. "s";
	}
	if ($strIn=="child")
	{
		$out="children";
	}
	if ($strIn=="woman")
	{
		$out="women";
	}
	if ($strIn=="man")
	{
		$out="men";
	}
	if ($strIn=="ox")
	{
		$out="oxen";
	}
	if ($strIn=="mouse")
	{
		$out="mice";
	}
	if (inList("deer moose sheep keyart", $strIn))
	{
		$out=$strIn;
	}
	return $out;
}

function PluralizeIfNecessary($subject, $number)
{
	if ($number!=1)
	{
		return pluralize($subject);
	}
	return $subject;
} 

function singlequoteescape($strIn)
//escapes '
{
			if (strlen($strIn)>0)
			{
				return str_replace("'", "\'", $strIn);
			}
}

function doublequoteescape($strIn)
//escapes '
{
			if (strlen($strIn)>0)
			{
				return str_replace('"', '&#34;', $strIn);
			}
}

function escapeslash($strIn)
//escapes \
{
			if (strlen($strIn)>0)
			{
				return str_replace("\\", "\\" . "\\", $strIn);
			}
}

function htmlcodify($strIn)
//changes ' to &#34;
//and parentheses to &...
{
	$out="";
			if (strlen($strIn)>0)
			{
				$out= str_replace("'",  "&#39;", $strIn);
				$out=  str_replace("(",  "&#40;", $out);
				$out= str_replace(")",  "&#41;", $out);
				return $out;
			}
}

function forinputform($strIn)
//changes ' to &#34;
{
			if (strlen($strIn)>0)
			{
				return str_replace(chr(34),  "&#34;", $strIn);
			}
}

function deescape($strIn)
//deescapes \'
{
			if (strlen($strIn)>0)
			{
				$strIn=str_replace("\'", "'", $strIn);
				$strIn=str_replace("\'", "'", $strIn);
				$strIn=str_replace("\\&#39;", "&#39;", $strIn);
				$strIn=str_replace("\\" . chr(34), chr(34), $strIn);
				$strIn=str_replace("\\'", "&#39;", $strIn);
				return $strIn;
			}
}


function radicaldeescapenourl($strIn)
//deescapes \'
{
	if (strlen($strIn)>0)
	{
		$strIn=deescape($strIn);
  			$strIn=str_replace("&#40;", "(", $strIn);
  			$strIn=str_replace("&#41;", ")", $strIn);
		$strIn=str_replace("&#39;", "'", $strIn);
		$strIn=str_replace("&#34;", "\"", $strIn);
		return $strIn;
	}
}

function radicaldeescape($strIn)
//deescapes \'
{
	if (strlen($strIn)>0)
	{
		$strIn=deescape($strIn);
  			$strIn=str_replace("&#40;", "(", $strIn);
  			$strIn=str_replace("&#41;", ")", $strIn);
		$strIn=str_replace("&#39;", "'", $strIn);
		$strIn=str_replace("&#34;", "\"", $strIn);
		$strIn=str_replace("'", "%27", $strIn);
		return $strIn;
	}
}

function deendquote($strIn)
//removes end quotes
{
	if (substr($strIn, 0, 1)=="'")
	{
		$strIn=substr($strIn, 1, strlen($strIn));
	
	}
	if (substr($strIn, strlen($strIn)-1, 1)=="'")
	{
		$strIn=substr($strIn, 0, strlen($strIn)-1);
	
	}
	return $strIn;
}

function parsehyperlink($strIn, $intTruncNumber)
{
	$strHref="";
	$olderrorr=error_reporting(0);
	$intBegin=strpos(strtolower($strIn), "http://");
	$intEnd1=strpos(strtolower($strIn), " ", $intBegin+7);
	$intEnd2=strpos(strtolower($strIn), chr(34), $intBegin+7);
	$intEnd=getMin($intEnd1, $intEnd2);
	if ($intBegin==0 && $intEnd=="")
	{
		$intEnd=strlen($strIn);
	}
	//echo $intBegin;
	if ( strlen($intBegin)>0)//total hack for the maddening php "beginning of string strpos enigma"
	{
		$strHref=substr($strIn, $intBegin, $intEnd-$intBegin);
		if ($strHref!="")
		{
			$out="<a href=\"". $strHref . "\" target=\"new\">" .  truncate($strIn, $intTruncNumber) . "</a>";
		}
		else
		{
			$out=  truncate($strIn, $intTruncNumber) ; 
		}
	}
	else
	{
	
		$out=  truncate($strIn, $intTruncNumber) ; 
	}
	error_reporting($olderrorr);
	return $out;
}

function striplfcr($strIn)
{
	$strIn=str_replace(chr(13), "", $strIn);
	$strIn=str_replace(chr(10), "", $strIn);
	return $strIn;
}

function simplelinkbody($strIn)
{
	$strIn=str_replace("'", "", $strIn);
	$strIn=str_replace("\"", "", $strIn);
	$strIn=str_replace("&#39;", "", $strIn);
	$strIn=str_replace("&#34;", "", $strIn);
	$strIn=htmlcodify(truncate(strip_tags(striplfcr($strIn)),25));
	return $strIn;
}


function killBetweenTags($oldString,  $taglist, $maxLength=9500, $begin="<", $end=">") 
{
//federico frankenstein Jan 2 2007
//gets rid of XML tags from $oldString if they are present in the space-delimited list $taglist.  also gets rid of the </XX> closer.
//this function doesn't consider whether or not content inside a node should be removed.  it just removes matching tags
//i made this function mostly to target DIVs and SPANs i didn't want in my truncated synopses.
	$newString = "";
	$inUnapprovedTag = false;
	$inApprovedTag=false;
   	for($i = 0; $i < strlen($oldString); $i++) 
	{
        if(substr($oldString,$i,strlen($begin)) == $begin  || ($end==""  && $inUnapprovedTag ==true) ) 
		{
			$strProspectiveTag=substr($oldString, $i + 1,getMin(strpos($oldString, " ",$i+1), strpos($oldString, ">",$i+1))-($i+1));
			//echo $strProspectiveTag . "<br>\n";
			//echo hexdump($strProspectiveTag)  . "<br>\n";
			if(inList($taglist, $strProspectiveTag) || inList($taglist, RemoveFirstCharacterIfMatch($strProspectiveTag, "/")))
			{
				$inUnapprovedTag = true;
			}
			else
			{
				$inApprovedTag=true;
			}
		}
		if(!$inUnapprovedTag)
		{ 
			$newString.= substr($oldString,$i,1);
		}
        if( substr($oldString,$i,strlen($end)) == $end  && $inUnapprovedTag ==true  && !($end==""  && $inUnapprovedTag ==true)) 
		{
			$inUnapprovedTag = false;
			//$i++;
		}
		if( substr($oldString,$i,strlen($end)) == $end  && $inApprovedTag ==true  && !($end==""  && $inApprovedTag ==true)) 
		{
			$inApprovedTag = false;
			//$i++;
		}
		//i want to bail at $maxLength, but not if we're still in a good tag
		if (strlen($newString)>$maxLength  && !$inApprovedTag)
		{
			break 1;
		}
	}
 	return $newString;
  }


function truncate($strIn, $intNumber)
//truncates $strIn to $intNumber (more or less) at the nearest space less than $intNumber and adds ...
//i've added some code to make sure an image tag early in $strIn is shown in full, but shrunk to a thumbnail
{
	$taglist="div span DIV SPAN p br P BR strong b STRONG B i I h3 h2 h1 H1 H2 H3";
	$strIn= killBetweenTags($strIn,  $taglist, $intNumber + 10);
	//echo "+" . $strIn . "\n";
	$strLen=strlen($strIn);
	$bwlSkipElipsis=false;
	if ($strLen<$intNumber+2)
	{	
		return $strIn;
	}
	//parsehyperlink($strIn, 55);
	$intStart=$intNumber;
	for ($i=$intStart; $i>1; $i--)
	{
		if (substr($strIn, $i, 1)==" ")
		{
			$out= substr($strIn, 0, $i);
			$lespos=strrpos($out,"<");
			$grepos=strrpos($out,">");
			if (($grepos<$lespos  || $grepos === false)  && $lespos<$intNumber   &&  !($lespos === false))
			{
				$grepos=strpos($strIn,">", $lespos)+1;
				$out = substr($strIn, 0, $grepos);
				$out=str_replace("<img ", "<img align=\"center\" width=\"100\" height=\"80\" ", $out);
				$bwlSkipElipsis=true;
			}
			
			if(!$bwlSkipElipsis)
			{
				$out.="...";
			}
			break;
		
		}
		else if ($i<$intNumber-12)
		{
			
			$out = substr($strIn, 0, 30);
			$lespos=strrpos($out,"<");
			$grepos=strrpos($out,">");
			//echo $grepos . " " . $lespos . "<br>";
			if (($grepos<$lespos  || $grepos=="")  && $lespos<$intNumber  &&  !($lespos === false))
			{
				$grepos=strpos($strIn,">", $lespos)+1;
				$out = substr($strIn, 0, $grepos);
				$out=str_replace("<img ", "<img align=\"center\" width=\"100\" height=\"80\" ", $out);
			}
			else
			{
				$out = forinputform($out);
			}
			break;
		}
	}
	return $out;
}

function trunchandler($strIn, $intNumber)
{
	if (strpos(ltrim(rtrim($strIn)), " ")>0)
	{
		return truncate($strIn, $intNumber);
	
	}
	else
	{
		return parsehyperlink($strIn, $intNumber);
	
	}
}

	
function htmlrow($strClass)
{

	$out="\n<tr";
	$bwlHideAllButLast=false;
	$intArgs =func_num_args();
	$strPreFed="";
	//a hack allowing the dynamic pre-hiding of a row
	if (contains($strClass, "hideallbutlast"))
	{
		//$out.=" \"" . $strClass . "\"";
		$bwlHideAllButLast=true;
		$strPreFed="<td   id=\"killmeonexpand\" colspan=\"" . intval($intArgs-2) . "\"></td>";
	}
	elseif ($strClass!="")
	{
		$out.=" class=\"" . $strClass . "\"";
	}
	$out.=">\n";
	
	$out.=$strPreFed;
		
	for($i=1; $i<$intArgs; $i++)
	{
		$content=func_get_arg($i);
		if ($bwlHideAllButLast  && $i<$intArgs-1)
		{
			$out.="<td valign=\"top\" style=\"display:none\">\n";
		
		}
		else
		{
			$out.="<td valign=\"top\">\n";
		}
 
		if ($content!="")
		{
			$out.=$content;
		}
		else
		{
			$out.="&nbsp;";
		}
		$out.="</td>\n";
	}
	
	$out.="</tr>\n";
 
	return $out;
}
 
 
function replaceMultipleQueryVariables()
{
	//probably won't use this as much as linkme, since it just generates the link, not the HTML
	$strPHP=$_SERVER['PHP_SELF'];
	$intArgs =func_num_args();
	$out="";
	$arrOut=$_REQUEST;
	for($i=0; $i<$intArgs; $i=$i+2)
	{
		$var=func_get_arg($i);
		$val=func_get_arg($i+1);
		$strOut=replaceSpecificQueryVariable($var, $val, $arrOut);
		$arrOut=QuerystringToAssociativeArray($strOut);
	}
	$out=$strPHP . "?" . $strOut; 
	return $out;
}
	
function QuerystringToAssociativeArray($strIn)
//convert a querystring directly into an associative array without ever having it be an actual querystring
{
	$arrOut=array();
	$arr=explode("&", $strIn);
	foreach($arr as $a)
	{
		$arrSub=explode("=", $a);
		$arrOut[$arrSub[0]]=urldecode($arrSub[1]);
	}
	return $arrOut;
}

function linkme($strIn, $target)
//creates a hyperlink labeled with $strIn, replacing any query variables passed in additionally
{
	$strPHP=$_SERVER['PHP_SELF'];
	$intArgs =func_num_args();
	$out="";
	$arr=array();
	for($i=2; $i<$intArgs; $i=$i+2)
	{
		$var=func_get_arg($i);
		$val=func_get_arg($i+1);
		$str= replaceSpecificQueryVariable($var, $val, $arr);
		$arr =QuerystringToAssociativeArray($str);
	}
	$out=$strPHP . "?" . $str; 
	$targethtml="";
	if ($target!="")
	{
		$targethtml=" target=\"" . $target . "\"";
	}
	$out="<a" . $targethtml . " href=\"" . $out . "\">" .  $strIn . "</a>";
	return $out;
}

function replaceSpecificQueryVariable($strVariable, $strValue, $arr="")
//replaces specific associative element in an array, usually the Query String, though it can be a passed-in array of the Post array.
{
	$out="";
	$intOut=0;
	$strCharacterGlue="";
	$bwlFoundOurVariable=false;
	if (is_array($arr) && count($arr)>0)
	{
		$arrToScan=$arr;
	}
	else
	{
		if (count($_GET)==0 && count($_POST)>0)
		{
			$arrToScan=$_POST;
		}
		else
		{
			$arrToScan=$_GET;
		}
	}


	foreach ($arrToScan as $k=>$v)
	{
		if (strlen($v)<100)//keep the query string to a reasonable size in some cases
		{
			if ($intOut!=0)
			{
				$strCharacterGlue="&";
			}
			if ($k==$strVariable)
				{
					$out.= $strCharacterGlue . $k. "=" . urlencode($strValue);
					$bwlFoundOurVariable=true;
				}
			else
				{
					if(is_string($v))
					{
						$out.=$strCharacterGlue . $k. "=" . urlencode($v);
					}
					
				}
		}
		$intOut++;
	
	}
	if ($out=="")
	{
		$out=$strVariable. "=" . urlencode($strValue);
	
	}
	elseif (!$bwlFoundOurVariable)
	{
		$out.="&" . $strVariable. "=" . urlencode($strValue);
	
	}
	//echo "--" . $out;
	return $out;
}

function ZeroIfEmpty($in)
{			
	if ($in=="")
	{
		return 0;
	}
	return $in;
}

function IfAThenB($a,$b)
{			
	if ($a!="")
	{
		return $b;
	}
}

function CountSQLRecords($strSQLQuery)
{	
	if (strpos(strtolower($strSQLQuery), "count(")<1)
	{
		$strSQLQuery=str_replace("*", "count(*) as 'countage'", $strSQLQuery);
	}
	$sql=conDB();
	$countrecords = $sql->query($strSQLQuery);
	$countrecord=$countrecords[0];
	$intCount=$countrecord["countage"];
	//echo "<font color=ffffff> " . $intCount;
	return $intCount;
}

function RequestCompoundDate($pre)
{
	$day=$_REQUEST[$pre . "|day"   ];
	$month=$_REQUEST[$pre . "|month" ];
	$year=$_REQUEST[$pre. "|year" ];
	$strTime=ReasonableStringDate($month, $day, $year);
	//echo $strTime . "<br>";
	$v=$strTime; //just turning the value into a PHP timestamp
	$k=$strPossibleDateName;  //just turning the key back to a conventional key for the next section
	return $v;
}

function GVFF($spacedelimitednamelist, $arrAdditional="",  $type="post" )

//returns an array of requests with values
{
	
	$arrIn=explode(" ", $spacedelimitednamelist);
	$arrOut=Array();
	foreach($arrIn as $k)
	{
		if ($type=="request")
		{
			$v=$_REQUEST[$k];
		}
		else if ($type=="post")
		{
			$v=$_POST[$k];
		}
		else if ($type=="get")
		{
			$v=$_GET[$k];
		}
		$arrOut[$k]=$v;
	}
	if (is_array($arrAdditional))
	{
		//echo "$$";
		foreach($arrAdditional as $k=>$v)
		{
			//echo $k . "--<br>";
			$arrOut[$k]=$v;
		}
	
	}
	return $arrOut;
}

function UpdateOrInsert($strDatabase, $strTable, $arrDescribedValuePairs, $arrAlteredValuePairs)
{
//does an insert or an update depending on whether or not the described record exists.  
 
	$sql=conDB();
	$strSQL="SELECT * FROM " . $strDatabase . "." .  $strTable . " WHERE ";
	$strAlterSQL="";
	$strUpdateSQL="";
	$strAlterSetSQL="";
	foreach($arrDescribedValuePairs as $k=>$v)
	{
 
		if(!array_key_exists($k, $arrAlteredValuePairs))
		{
			$strSQL.= " " . $k . "='" . singlequoteescape($v) . "' AND";
			$strUpdateSQL.= $k . "='" . singlequoteescape($v) . "',";
			$strAlterWhereSQL.=" " . $k . "='" . singlequoteescape($v) . "' AND";
		}
	
	}
	foreach($arrAlteredValuePairs as $k=>$v)
	{
		if ($k!="")
		{
			$strAlterSetSQL.= $k . "='" . singlequoteescape($v) . "',";
		}
	
	}
	$strSQL= substr($strSQL, "0", strlen($strSQL)-4); 
	$strAlterWhereSQL= substr($strAlterWhereSQL, "0", strlen($strAlterWhereSQL)-4); 
	$strUpdateSQL= RemoveLastCharacterIfMatch($strUpdateSQL, ",");
	$strAlterSetSQL= RemoveLastCharacterIfMatch($strAlterSetSQL, ",");
	//echo $strSQL . "<br>";
	$records=$sql->query($strSQL);
	if (count($records)>0 && count($arrDescribedValuePairs)>0 )
	{
		//need an update
		$strSQL="UPDATE " . $strDatabase . "." .  $strTable . " SET ". $strAlterSetSQL . " WHERE " . $strAlterWhereSQL;
	}
	else
	{
		//need an insert
		$strSQL="INSERT INTO " . $strDatabase . "." .  $strTable . " SET ". $strAlterSetSQL . ", " . $strUpdateSQL ;
	}
	$strSQL= RemoveLastCharacterIfMatch($strSQL, " ");
	$strSQL= RemoveLastCharacterIfMatch($strSQL, ",");
	//echo $strSQL;
	$records=$sql->query($strSQL);
	return mysql_error();
}

function paginatelinks($intRecCount, $intRecordsPerPage, $intStartRecord, $strPHP, $strThisQVar)
//$records is the total record set, unpaginated
{
	$out="";
 	if ($intStartRecord=="")
	{
		$intStartRecord=0;
	}
	$intPages=intval(($intRecCount-1)/$intRecordsPerPage);
	//echo $intRecCount . " " . $intRecordsPerPage;
	if ($intPages>0)
	{
		for ($i=0; $i<=$intPages; $i++)
		{
			$url=$strPHP . "?" . replaceSpecificQueryVariable($strThisQVar, $i * $intRecordsPerPage);
			//echo intval($intStartRecord) . " " . intval($i * $intRecordsPerPage) . "<br>";
			if (intval($intStartRecord)!= intval($i * $intRecordsPerPage) )
			{
				$out.="<a href=\"" . $url . "\">" .intval($i +1) . "</a>";
			}
			else
			{
				 
				$out.=    "<b>" . intval($i +1) . "</b>";
			}
		 //echo (($i+1)* $intRecordsPerPage) . " " . $intRecCount . "<br>";
			if (($i+1)* $intRecordsPerPage<$intRecCount)
			{
				$out.= " | ";
			}
		}	
		return "Go to Page: " . $out;
	}
}

function NumToMon($intNum)
{
	$strMons="|January|February|March|April|May|June|July|August|September|October|November|December";
	$arrMons=explode("|", $strMons);
	return $arrMons[$intNum];
}

function getMax($intOne, $intTwo)
//returns the larger of two numbers
	{
		if ($intOne>$intTwo)
			{
				$intBigger=$intOne;
			}
		else
			{
				$intBigger=$intTwo;
			}
	return $intBigger;
	}
	
function getMin($intOne, $intTwo)
//returns the smaller of two numbers
	{
		if ($intOne<$intTwo)
			{
				$intSmaller=$intOne;
			}
		else
			{
				$intSmaller=$intTwo;
			}
	return $intSmaller;
	}
	
////specifically DB-related functions

function deMoronizeDB($strDB)
//fixes idiotic dbs that contain dashes in their names
{
	if (contains($strDB, "-")  && !contains($strDB, "`"))
	{
		$strDB="`" . $strDB . "`";
	}
	return $strDB;
}

function DuplicatesInThisField($arrIn, $strFieldName, $strValue)
{
	//scans through a mysql recordset looking to see id there are duplicates of  $strValue in a field named $strFieldName
	$found=0;
	foreach($arrIn as $row)
	{
		if ($row[$strFieldName]==$strValue)
			{
				$found++;
				if ($found>1)
					{
						return true;
					}
			}
	}
	return false;
}

function numericpulldown($intstart,$intend,$intdefault,$strName)
	{
	//gives me a select with numbers running from $intstart to $intend, with $intdefault selected, and names it $strName
	  $strOut="<select  id=\"id" . $strName . "\" name=".chr(34).$strName.chr(34).">"."\n";
	  $strOut=$strOut."<option value=".chr(34).chr(34).">none"."\n";
	  for ($intNumber=$intstart; $intNumber<=$intend; $intNumber++)
			{
				$strSel="";
				if ($intNumber==$intdefault)
					{
						$strSel=" selected=\"true\" ";
					} 
				$strOut=$strOut."<option value=\"". $intNumber. "\" " . $strSel .  ">".$intNumber."\n";
			
			} 
	  $strOut=$strOut."</select>"."\n";
	  $function_ret=$strOut;
	  return $function_ret;
	} 

function datepulldowns($strNamePre,$dtmDefault)
//provides a set of pulldowns to select a date
	{
		if (!is_numeric($dtmDefault)  && $dtmDefault!="")
		{	
			$dtmDefault=strtotime($dtmDefault);
		}
		 
		$strSuperPre=qpre;
		$strOut="";
		if (is_numeric($dtmDefault))
			  {
		    	$intMonth=strftime("%m",$dtmDefault);
		    	$intYear=strftime("%Y",$dtmDefault);
				$intDay=strftime("%d",$dtmDefault);
			  }
		else
			  {
				$intDay="";
			    $intMonth="";
			    $intYear="";
			  } 
		//echo $intMonth . " - " . $intDay . " - " . $intYear;
		$yearlow=gracefuldecaynumeric(numrange_low,0);
		$yearhi=gracefuldecaynumeric(numrange_hi,99);
		if (strlen($yearlow)==4)
		 	{
			  //  $intYear=intval(substr($intYear,strlen($intYear)-(2)));
				$intYear=intval($intYear);
		  	}
		else
		 	{
				$intYear=intval(substr($intYear,strlen($intYear)-(2)));
		  	}
		if (substr($intYear,0,1)=="0")
			{
				$intYear=intval(substr($intYear,strlen($intYear)-(1)));
			} 
	 	//echo $intYear;
	  	$strOut.= "\n".numericpulldown(1,12,$intMonth,$strSuperPre  . $strNamePre."|month")."\n"." / ";
		$strOut.="\n".numericpulldown(0,31,$intDay,$strSuperPre  . $strNamePre."|day")."\n" . " / ";
	   	$strOut.="\n".numericpulldown($yearlow,$yearhi,$intYear,$strSuperPre  . $strNamePre."|year")."\n";
	  	$function_ret=$strOut;
	  return $function_ret;
	} 

function gracefuldecaynumeric()
{
	//go through the parameters and return the first that isn't empty
		$intArgs =func_num_args();
		for($i=0; $i<$intArgs; $i++)
		{
			$option=func_get_arg($i);
			if (is_numeric($option))
			{
				return $option;
			}
		}
}

function boolcheck($strName,$strDefault, $bwlFriendly=false, $bwlNoForm=false,$strStyle="")
	//shows a set of radio buttons for setting a boolean db value
	{
		$strTrue="true";
		$strFalse="false";
		if ($bwlFriendly)
		{
			$strTrue="yes";
			$strFalse="no";
		}
		if ($bwlNoForm)
		{
			if (intval($strDefault)==1)
			{
				return $strTrue;
			}
			return $strFalse;
		}
		else
		{
			if (intval($strDefault)==1)
			{
				$out= "<input type=\"radio\" checked name=\"" . $strName . "\" value=\"1\"> "  . $strTrue ;
				$out.= "<input type=\"radio\"  name=\"" . $strName . "\" value=\"0\"> "  . $strFalse ;
			}
			else if (!($strDefault==="")  && !is_null($strDefault))
			{
				$out= "<input type=\"radio\"  name=\"" . $strName . "\" value=\"1\"> "  . $strTrue ;
				$out.= "<input type=\"radio\"  checked name=\"" . $strName . "\" value=\"0\"> "  . $strFalse ;
			}
			else
			{
				$out= "<input type=\"radio\" name=\"" . $strName . "\" value=\"1\"> "  . $strTrue ;
				$out.= "<input type=\"radio\"  name=\"" . $strName . "\" value=\"0\"> "  . $strFalse ;
			}
	
		}
		if ($strStyle!="")
		{
			$out= "<span style=\"" . $strStyle. "\">" . $out . "</span>";
		}
		return $out;
	}

function LabelForID($strDatabase, $strTable, $strIDField, $intID)
{
	$strNameField=firstnonidcolumname($strDatabase, $strTable);
	if ( $intID!="")
	{
		$strSQL="SELECT " . $strNameField . " FROM " . $strDatabase . "." . $strTable . " WHERE " .  $strIDField . " = " . $intID;
		//echo $strSQL;
		$sql=conDB();
		$records = $sql->query($strSQL);
		if ($records)
		{
			//echo"@";
			$record=$records[0];
			return $record[$strNameField];
		}
	}
}
	
	
function foreigntablepulldown($strDatabase, $strTable, $strIDField, $intDefault, $strLabelField="", &$namereturn, $bwlHiddenReturn=false, $strPreferredNameField="")
	{
		//gives me a select named $strIDField of ids with rows from $strTable, defaulted to $intDefault
		//$namereturn, passed by reference, allows me to hand back the selected string label of the pulldown, which is won at considerable
		//computative effort
		//bwlHiddenReturn allows me to pass the actual string value of the dropdown in a specially-labeled hidden field.
		$sql=conDB();
		$strHiddenExtra="";
		$strNameField2="";
		$strNameField="";
		if ($strLabelField=="")
		{
			$strLabelField= $strIDField;
		}
		$strOut="<select name=".chr(34).$strLabelField.chr(34);
		if ($bwlHiddenReturn)
		{
		
			$strOut.=" onchange=\"document.BForm." . qpre . "multi.value=document.BForm." .  $strLabelField . "[document.BForm." .  $strLabelField . ".selectedIndex].text\"";
		
		}
		$strOut.= ">"."\n";
		$strOut.="<option value=".chr(34).chr(34).">none"."\n";
		if ($strPreferredNameField=="")
		{
			$strNameField=firstnonidcolumname($strDatabase, $strTable);
			$strNameField2 = NthNonIDColumName($strDatabase, $strTable, 2);
		}
		else
		{
			$strNameField = $strPreferredNameField;

		}
		$strSQL="SELECT * FROM " . $strDatabase . "." . $strTable;
		if ($strNameField!="")
		{
			$strSQL.=" ORDER BY " . $strNameField;
		
		}
		if ($strNameField2!="")
		{
			$strSQL.=", " . $strNameField2;
		
		}
		//echo $strSQL;
		$records = $sql->query($strSQL);
		if ($records)
		{
			$strOldLabel="";
			//some code to handle the sorting of the records, because orderby is fuct
			$arrOut=array();
			foreach($records as $k)
			{
				//some complicated code to handle the situation where name fields are not very unique
				 $strLabel1 = $k[$strNameField];
				 $strLabel2 = $k[$strNameField2];
				 $strLabel= $strLabel1;
				 if ((strlen($strLabel1)<15 && $strLabel2!="" && !(strlen($strLabel2)>15))   && ($strNameField2!="password")   )
				 {
				 
				 	$strLabel=$strLabel1  . " : " . $strLabel2;
				 }
				 $strOldLabel=$strLabel1;
				 $strSel="";
				 if ($k[$strIDField]==$intDefault)
				 {
				   $strSel=" selected=\"true\" ";
				   $namereturn=$strLabel;
				   if ($bwlHiddenReturn)
				   {
				   	$strHiddenExtra="<input type=\"hidden\" name=\"" .$strFieldNamePrefix  . qpre . "multi\"   value=\"".  $strLabel . "\">\n";
				   
				   }
				 } 
				 
				 $strSel="";
				//echo $k . "<br>";
				 if ($k[$strIDField]==$intDefault)
				 {
				 	$strSel=" selected=\"true\" ";
				 } 
				$strOut=$strOut."<option value=\"". $k[$strIDField] . "\" " . $strSel .  ">". truncate($strLabel, 35) ."\n";
				
				// $arrOut[$strLabel]=$k[$strIDField];
			} 
			if ($strHiddenExtra=="" && $bwlHiddenReturn)
			{
				$strHiddenExtra="<input type=\"hidden\" name=\"" .$strFieldNamePrefix  . qpre . "multi\"   value=\"\">\n";
			}
		
			
		}
		$strOut=$strOut."</select>"."\n";
		$function_ret=$strOut . $strHiddenExtra;
		return $function_ret;
	}

function countrecords($strDatabase , $strTable )
{
		$sql=conDB();
		$countrecs = $sql->query("SELECT COUNT(*) FROM " . $strDatabase . "." . $strTable ); 
		$countrec=$countrecs[0];
		$count=$countrec["COUNT(*)"];
		return $count;
}

function FleshedOutFKSelect($strDatabase, $strTable, $additionalClauses, &$arrDesc)
{
//delivers the SQL to do a select from a table with the necessary joins so that instead of foreign key ids we get
//fields populated with readable strings
//ALSO: returns an array by reference containing types, because this is essential info for a lot of what this SQL is used to do
//Federico Frankenstein 2007-2-1
	$sql=conDB();
	//first get all the text fields for all the foreign keys
	$strSQL="SELECT * FROM " . $strDatabase . "." . tfpre . "relation WHERE relation_type_id=0 AND table_name='" . $strTable . "'";
	//echo $strSQL;
	$records = $sql->query($strSQL);
	$strJoinSQL="";
	$strPreJoinSQL="";
	$strSkipFieldList="";
	$arrDesc=Array();
	$count=0;
	foreach($records as $record)
	{
		$strJoinSQL.=" LEFT JOIN " . $strDatabase . "." . $record["f_table_name"] . " x" . $count. " ON t." . $record["column_name"] . "=x" . $count. "." . $record["f_column_name"] . " " ;
		$nameColumn=firstnonidcolumname($strDatabase, $record["f_table_name"]);
		$strNameAdditional="";
		//in some cases the foreign table's field name isn't specific enough in the join to be a proper label
		//so in those cases i append the tablen name to the front of the fieldname to make it into a proper label
		if($nameColumn=="name")
		{
			$strNameAdditional=" as `" . $record["f_table_name"] . " " . $nameColumn . "`";
		}
		$arrDesc[$nameColumn]= GetFieldType($strDatabase, $record["f_table_name"], $nameColumn);
		$strPreJoinSQL.=" x".$count . "." . $nameColumn .$strNameAdditional. ","   ;
		$strSkipFieldList.=" " .  $record["column_name"];
		$count++;
	}
	//now throw away the FK fields themselves, since they just gum up the works
	$records = $sql->query("EXPLAIN " . $strDatabase . "." . $strTable);
	$intFindCount=1;
	$goodFieldList="";
	foreach ($records as $k => $info )
	{
		if(!inList($strSkipFieldList, $info["Field"]))
		{
			$goodFieldList.="t." . $info["Field"] . ",";
			$arrDesc[$info["Field"]]= GetFieldType($strDatabase, $strTable, $info["Field"]);
		}
	}
	$goodFieldList=RemoveEndCharactersIfMatch($goodFieldList, ",");
	$strPreJoinSQL=RemoveEndCharactersIfMatch($strPreJoinSQL, ",");
	$out="SELECT " . $goodFieldList .  IFAthenB(($strPreJoinSQL  && $goodFieldList),", ") . $strPreJoinSQL  ." FROM " .  $strTable . " t " . $strJoinSQL . " " . $additionalClauses;
	if (count($arrDesc)<1)
	{
		$arrDesc=GetFieldTypeArray($strDatabase, $strTable);
	}
	return $out;
}

function firstnonidcolumname($strDatabase, $strTable)
	{
		//in which i make a reasonable guess of how to best provide a user-friendly label for a row of data
		//i basically look through the fields until i find one that isn't  type int or named password
		return NthNonIDColumName($strDatabase, $strTable, 1);
	}

function NthNonIDColumName($strDatabase, $strTable, $n)
	{
		//in which i make a reasonable guess of how to best provide a user-friendly label for a row of data
		//i basically look through the fields until i find one that isn't type int or named password
		$sql=conDB();
		$records = $sql->query("EXPLAIN " . $strDatabase . "." . $strTable);
		$intFindCount=1;
		foreach ($records as $k => $info )
		{
			$olderror=error_reporting(0);
			//echo TypeParse($info["Type"],0) . "==<br>";
			//if (!contains(TypeParse($info["Type"],0),"int")  && (!contains($info["Field"], "password")    & !contains($info["Field"], "image") & !contains($info["Field"], "filename") & !contains($info["Field"], "date") & !contains($info["Field"], "price")))
			if (!contains(TypeParse($info["Type"],0),"int")  && (!contains($info["Field"], "password") ))
			{
				//echo $k . "<br>";
				if ($intFindCount==$n)
				{
					//echo $info["Field"] . "**<br>";
					return $info["Field"];
				}
				$intFindCount++;
			}
			error_reporting($olderror);
		}
	}
	
function foreignKeyLookup($strDatabase, $strTable, $strColumn)
//looks up the foreign key table and column given a column
{
		$sql=conDB();
		$records = $sql->query("SELECT column_name, f_table_name, f_column_name FROM " . $strDatabase . "." . tfpre . "relation WHERE table_name='" . $strTable . "' AND column_name='" . $strColumn . "'  AND relation_type_id=0");
		$count=0;
		foreach ($records as $record)
		{
			return array(  $record["f_table_name"],  $record["f_column_name"]) ;
			$count++;
		}
}

function PKLookup($strDatabase, $strTable)
//looks up the pkfor atable
 
	{
		//i want the max autocount id for a table
		$sql=conDB();
		$records = $sql->query("EXPLAIN " . $strDatabase . "." . $strTable);
		foreach ($records as $k => $v )
		{
			if ($v["Key"]=="PRI")
			{
				return $v["Field"];
				
			}
		}
	}


function RelationLookup($strDatabase, $strTable, $strColumn, $intType=0)
//looks up the multi-table info given a column
{
		$sql=conDB();
		$records = $sql->query("SELECT column_name, f_table_name, f_column_name FROM " . $strDatabase . "." . tfpre . "relation WHERE table_name='" . $strTable . "' AND column_name='" . $strColumn . "'  AND relation_type_id=" . $intType);
		$count=0;
		foreach ($records as $record)
		{
		 
				//echo $k . "->" . $v .  "<br>";
			return array( $record["f_table_name"],  $record["f_column_name"]) ;
			$count++;
		}
}
	
function firstforeignkeycolumn($strDatabase, $strTable, $strMappedTableToAvoid)
	{
		//in which i make a reasonable guess of where a mapping table maps to
		//returns a three-member array, with [0]the field name and [1] the mapped table and [2] the mapped column
		//i pass in $strMappedTableToAvoid to avoid mapping off to the table I'm starting from
		//modified for MySQL 2-7-06
		return  Nthforeignkeycolumn($strDatabase, $strTable, $strMappedTableToAvoid, 1);
	}
	

	
function Nthforeignkeycolumn($strDatabase, $strTable, $strMappedTableToAvoid, $n)
	{
		//in which i make a reasonable guess of where a mapping table maps to
		//returns a three-member array, with [0]the field name and [1] the mapped table and [2] the mapped column
		//i pass in $strMappedTableToAvoid to avoid mapping off to the table I'm starting from
		//modified for MySQL 2-7-06
		$sql=conDB();
		$records = $sql->query("SELECT column_name, f_table_name, f_column_name FROM " . $strDatabase . "." . tfpre . "relation WHERE table_name='" . $strTable . "'  AND relation_type_id=0");
		$count=0;
		$right=0;
		foreach ($records as $record)
		{
			if ( $record["f_table"] != strMappedTableToAvoid  )
			{
				//echo $k . "->" . $v .  "<br>";
				$right++;
				if ($n==$right)
				{
					return array(  $record["column_name"], $record["f_table_name"],  $record["f_column_name"]) ;
				}
				
			}
			$count++;
		}
	}
	
function highestprimarykey($strDatabase, $strTable)
{
	//i want the max autocount id for a table
	$sql=conDB();
	$records = $sql->query("EXPLAIN " . $strDatabase . "." . $strTable);
	foreach ($records as $k => $v )
	{
		if ($v["Key"]=="PRI")
		{
			$strSQL="SELECT MAX(" . $v["Field"]. ") FROM " . $strDatabase . "." .  $strTable;
			$orecords=$sql->query($strSQL);
			$orecord =$orecords[0];
			return $orecord["MAX(" . $v["Field"]. ")"];
			
		}
	}
}
	
function GetFieldType($strDatabase, $strTable, $strFieldName)
{
		//give me the type of a column
	$sql=conDB();
	$records = $sql->query("EXPLAIN " . $strDatabase . "." . $strTable);
	foreach ($records as $k => $v )
	{
		if ( $v["Field"]==$strFieldName)
		{
			return  $v["Type"];
		}
	}
}

function GetFieldTypeArray($strDatabase, $strTable)
{
	//give me the types of a columns for a table as an array
	$sql=conDB();
	$arrOut=Array();
	$records = $sql->query("EXPLAIN " . $strDatabase . "." . $strTable);
	foreach ($records as $k => $v )
	{
			$arrOut[$v["Field"]]= $v["Type"];
	}
	return $arrOut;
}

function generateFieldTypeArray($strDatabase, $strTable)
{
	//returns an associative array keyed to the names of columns containing types
	//nov 2006
	$sql=conDB();
	
	$arrFieldType=array();
	$strSQL="EXPLAIN " . $strDatabase . "." . $strTable;
	$descr = $sql->query($strSQL);
	foreach ($descr as $nom=>$info)
	{
		$strName=$info["Field"];
		$strType=TypeParse($info["Type"], 0);
		$arrFieldType[$strName]=$strType;
		
	}
	return $arrFieldType;
}

function countforeignkeycolumns($strDatabase, $strTable, $strMappedTableToAvoid)
	{
		//for counting all the foreign keys except to the one to avoid
		//useful for seeing whether it's best to not treat a mapping table as such
		$sql=conDB();
		$strSQL="SELECT COUNT(*) as 'table_count' FROM " .  $strDatabase . "." . tfpre . "relation  WHERE table_name  = '" .  $strTable . "' AND relation_type_id=0";
		//echo $strSQL. "<br>";
		$records = $sql->query($strSQL);
	 	$record=$records[0];
		//echo "recorcont: " .  $record["table_count"] . "<br>";
		return $record["table_count"];
	}
	
function idcolumname($strDatabase, $strTable)
	{
		//in which i make a reasonable guess of a table's primary key, looking at auto_increment
		$sql=conDB();
		$records = $sql->query("EXPLAIN " . $strDatabase . "." . $strTable);
		$count=0;
		foreach ($records as $k => $v )
		{
			if ($v["Key"]=="PRI")
			{
				//echo $v["Field"]. "<br>";
				return $v["Field"];
			}
			$count++;
		}
	}
	
function hasautocount($strDatabase, $strTable)
	{
		//in which i make a reasonable guess of a table's primary key, looking at auto_increment
		$sql=conDB();
		$records = $sql->query("EXPLAIN " . $strDatabase . "." . $strTable);
		$count=0;
		foreach ($records as $k => $v )
		{
			if ($v["Extra"]=="auto_increment") 
			{
				//echo $v["Field"]. "<br>";
				return true;
			}
		}
		return false;
	}
	
function  TypeParse($strIn, $intPart)
//parse mysql types into the basic type ($intPart=0) and whatever descriptive numerics follow ($intPart=1)
{
	$strIn=str_replace(" ","", $strIn);
	$strIn=str_replace("(","|", $strIn);
	$strIn=str_replace(")","|", $strIn);
	$arrIn=explode("|", $strIn);
	return $arrIn[$intPart];
}

function ReturnNonIDPartOfName($strIn)
{
	if (contains($strIn, "_"))
	{
		$arrIn=explode("_", $strIn);
		if (count($arrIn)>1 && count($arrIn)<3  && $arrIn[1]=="id")
		{
		
			$out=$arrIn[0];
		}
		else
		{
			$out=implode(" ",$arrIn);
		
		}
	}
	else
	{
		$out=$strIn;
	}
	$out=str_replace("id", "", strtolower($out));
	return $out;
}

function ClearNumeric($strIn)
{
	return ClearRange($strIn,48, 57);
}

function ClearRange($strIn, $strLow, $strHigh)
{
	$intLen=strlen($strIn);
	$strOut="";
	for ($i=0; $i<$intLen; $i++)
	{
		$chr=substr($strIn, $i, 1);
		$ord=ord($chr);
		if ($ord>$strLow-1 && $ord<$strHigh+1)
		{
			$strOut.=$chr;
		}
	}
	return $strOut;
}

function data($strIn,$intTypeIn, $intTypeOut, $strTranslate)
	//using a double-delimited list $strTranslate of the form field1a|field2a|field3a-field1b|field2b|field3b-field1c...
	//you can retrieve the field number $intTypeOut in the record containing the first match of $strIn to the field specified by
	//$intTypeIn. if $intTypeIn is -1 then it returns a field from the record number specified by $strIn
	//this serves as very nice bare-bones database retrieval system
	{
		$strOut=genericdata($strIn,$intTypeIn, $intTypeOut, $strTranslate, "-", "|");
		return($strOut);
	}	
	
function GenericTablePulldown($strDatabase, $strTable, $strIDField, $strNameField, $strQueryVariableName, $strDefault, $strPHP, $strFormName, $strConnector, $bwlAcceptWild=true)
{
//from a table, generate a dropdown
//$bwlAcceptWild allows it to add items at the bottom found in the wild but not in the config string
	$intTop=-1;
	$strOut="";
 	$sql=conDB();
	$strSQL="SELECT * FROM " . $strDatabase . "." . $strTable . " ORDER BY " . $strNameField . " ASC";
	$records = $sql->query($strSQL);
	if (($strPHP!="") and ($strFormName!="")) 
	{
		$strOut="\n<select id=\"id" . $strQueryVariableName . "\" name=\"" . $strQueryVariableName . "\" onChange=\"window.document.location.href='" . $strPHP . $strConnector . $strQueryVariableName . "=' + document." . $strFormName . "." . $strQueryVariableName . "[document." . $strFormName . "." . $strQueryVariableName . ".selectedIndex].value\">\n";
}
	else
	{
		$strOut="\n<select id=\"id" . $strQueryVariableName . "\"  name=\"" . $strQueryVariableName . "\">\n";
	}
	$strOut.= "<option value=\"\" >-none-\n" ;
 	$bwlFoundOne=false;
	foreach ($records as $record)
	{
		$strSel="";
		$strThisIdentifier = $record[$strIDField];
		$strLabel=$record[$strNameField];;
 		
		if ($strLabel!="")
		{
		 
			if  ($strDefault.""==$strThisIdentifier."")
			{
				$strSel="selected=\"true\"";
				$bwlFoundOne=true;
			}
			$strOut.=  "<option value=\"" . $strThisIdentifier. "\" " . $strSel . ">" . $strLabel . "\n";
		}
	}
	if (!$bwlFoundOne  && $bwlAcceptWild  )
	{
		$strOut.=  "<option selected=\"true\" value=\"" . $strDefault. "\">" . $strDefault . "\n";
	}
	$strOut.= "</select>\n";
 
	return($strOut);
}

function GenericDataPulldown($strConfig, $intIDField, $intLabelField, $strQueryVariableName, $strDefault, $strPHP, $strFormName, $strConnector, $bwlAcceptWild=true)
{
//from a double-delimited -| string, generate a dropdown
//$bwlAcceptWild allows it to add items at the bottom found in the wild but not in the config string
	$intTop=-1;
	$strOut="";
	if ($strConfig!="")
	{
		if (strpos($strConfig, "-") >0)
		{
			$intTop=count(split("-",$strConfig));
		}
	}
	if (($strPHP!="") and ($strFormName!="")) 
	{
		$strOut= "\n<select id=\"id" . $strQueryVariableName . "\" name=\"" . $strQueryVariableName . "\" onChange=\"window.document.location.href='" . $strPHP . $strConnector . $strQueryVariableName . "=' + document." . $strFormName . "." . $strQueryVariableName . "[document." . $strFormName . "." . $strQueryVariableName . ".selectedIndex].value\">\n";
}
	else
	{
		$strOut="\n<select id=\"id" . $strQueryVariableName . "\"  name=\"" . $strQueryVariableName . "\">\n";
	}
	$strOut.= "<option value=\"\" >-none-\n" ;
 	$bwlFoundOne=false;
	for ($t=0; $t<$intTop; $t++)
	{
		$strSel="";
		$strThisIdentifier = data($t,-1,$intIDField,$strConfig);
		$strLabel=data($t,-1,$intLabelField,$strConfig);
 		
		if ($strLabel!="")
		{
		 
			if  ($strDefault.""==$strThisIdentifier."")
			{
				$strSel="selected=\"true\"";
				$bwlFoundOne=true;
			}
			$strOut.=  "<option value=\"" . $strThisIdentifier. "\" " . $strSel . ">" . $strLabel . "\n";
		}
	}
	if (!$bwlFoundOne  && $bwlAcceptWild  )
	{
		$strOut.=  "<option selected=\"true\" value=\"" . $strDefault. "\">" . $strDefault . "\n";
	
	}
	$strOut.= "</select>\n";
 
	return($strOut);
}

function ReasonableStringDate($m, $d, $y)
{
	$y=intval($y);
	if (strlen($y+ " ")<4)
	{
		if ($y<50)
		{
			$y=2000+$y;
		}
		else
		{
			$y=1900+$y;
		}
	}
	return     $y . "/" . $m . "/" . $d;

}

function flipyear($strDate)
{
//for taking m/d/y and making it y/m/d
	$datearray=getdate(strtotime($strDate));
		$month=$datearray["mon"];
		$year=$datearray["year"];
		$day=$datearray["mday"];
	return $year . "/" . $month . "/" . $day;
}

function passworddisplay($strIn)
{
	$count=strlen($strIn);
	if ($count>0)
	{
		$strOut= str_pad("*", $count, "*");
	}
	return $strOut;
}

function TableExists($strDatabase, $strTable)
{
	$sql=conDB();
    $strSQL="show tables from "  . $strDatabase . " like '" .  $strTable . "'";
	$rs= $sql->query($strSQL);
	if (count($rs)<1)
    {
		return(false);
    }
	else 
	{
		return(true);
	}
}

function FieldDropdown($strDatabase, $strTable, $strFieldFormName, $strDefault)
{
		$sql=conDB();
		$records = $sql->query("EXPLAIN " . $strDatabase . "." . $strTable);
		$fields=  "<option value=\"\">none</option>";
		foreach ($records as $k => $info )
		{
			if ($info["Field"]== $strDefault)
			{
				$fields.=  "<option selected>";
			}
			else
			{
				$fields.=  "<option>";
			}
			$fields.=$info["Field"] . "</option>\n";
	 	}
		$out="<select name=\"" .  $strFieldFormName . "\">\n" .$fields . "</select>" ;
		return $out;
}


function TableDropdown($strDatabase, $strDefaultTable, $strTableFormName, $strOurFormName='BForm', $strFieldFormName="")
{
	//contains the code to allow the selection of a table to immediately populate a dropdown list of fields
	$sql=conDB();
 
	$out="<select name=\"".   $strTableFormName . "\" ";
	if ($strFieldFormName!="")
	{
		$out.="onChange=\" field=document." . $strOurFormName . "." .  $strTableFormName . "[document." . $strOurFormName . "." .   $strTableFormName. ".selectedIndex].text; frames['ajax'].location.href='fielddump.php?" . qpre . "db=" . $strDatabase . "&" . qpre . "formname=" . $strOurFormName . "&" . qpre . "table=' + field + '&" . qpre . "fieldformname=" .   $strFieldFormName ."'\";"; 
	}
	$out.=">\n";
	$out.="<option value=''>none</option>\n";
	$tables = $sql->query("SHOW TABLES FROM " .  $strDatabase  ); 
	//echo "SHOW TABLES IN " .  $strDatabase ;
	$strFieldName="Tables_in_" . str_replace("`", "", $strDatabase);
	foreach ( $tables as  $k=>$v )
	{
	
	
		$tablename= $v["Tables_in_" . str_replace("`", "", $strDatabase)];
		$strSel="";
		if ($tablename==$strDefaultTable)
		{
			$strSel="selected";
		}
		$out.="<option " . $strSel . ">" . $tablename . "</option>\n";
	}
	$out.="</select>\n";
	return $out;
}

function LookupName($strDatabase, $strTable, $strIDField, $strID)
{
	//you basic lookup of a name given a table, idfield, and id
	 //NthNonIDColumName($strDatabase, $strTable, $n)
	$sql=conDB();
	$strSQL="SELECT * FROM " . $strDatabase . "." .  $strTable . " WHERE " .  $strIDField . " = " . $strID;
	//echo "<font color=0000000>" .  $strSQL . "<br>";
	if ($strTable !="")
	{
		$records = $sql->query($strSQL);
		$record=$records[0];
		$strNameField1=NthNonIDColumName($strDatabase, $strTable, 1);
		$strNameField2 = NthNonIDColumName($strDatabase, $strTable, 2);
		//echo $firstnonidcolumn  . "<br>";
	 
		//fancy code to get text from two fields when one isn't sufficient
		$strLabel1 = $record[$strNameField1];
		$strLabel2 = $record[$strNameField2];
	 	//echo $strLabel1 . " " . $strLabel2  . "<br>";
		
		if ((strlen($strLabel1)<16 && $strLabel2!="" && !(strlen($strLabel2)>14)))
			 {
			 	$strLabel=$strLabel1  . " : " . $strLabel2;
			 }
		else
			{
			 	$strLabel=$strLabel1 ;
			}
	}
	return $strLabel;
}

function GenericDBLookup($strDB, $strTable, $strIDFieldName, $strThisID, $strResultFieldName)
{
	$out="";
	$sql=conDB();
	$strSQL="SELECT " . $strResultFieldName . " FROM " . $strDB . "." . $strTable . " WHERE " . $strIDFieldName . " = '" . $strThisID . "'";
				//echo $strSQL;
	$records = $sql->query($strSQL);
	$record = $records[0];
	return $record[$strResultFieldName];
}
///////////////////////////////////////
/////////User functions///////////////
/////////////////////////////////////

function WhoIsLoggedIn()
{
	global $COOKIE_VARS;
	
	$strCookieVal= subtractletters( $_COOKIE["these"], encryptionkey);

	if ($strCookieVal!="")
	{
		return($strCookieVal);
	}
}

function IsLoginValid($strDatabase, $strUser, $strPassword)
{
	$out=false;
	$sql=conDB();
	//use the function data to do a query 
 	$strSQL="SELECT password from " . $strDatabase . "." . tfpre . "admin WHERE username = '" . $strUser . "'";
	$records = $sql->query($strSQL);
	$record=$records[0];
	if ($record["password"]==$strPassword and $strPassword!="")
		{
			$out=true;
		}
	return($out);
}

function TestAndSetLogin($strDatabase, $strUser, $Password)
{
	if (IsLoginValid($strDatabase, $strUser, $Password))
	{
		setLoggedIn($strUser);
		$out=$strUser;
	}
	else
	{
		$out="";
	}
	return($out);
}

function logSomething($line, $log)
{
	$strRoot="log";
   	if (!is_dir($strRoot))
	{
		mkdir($strRoot);
	}
    $url="log/" . $log . ".txt";
    $handle=fopen ($url, "a");
   	$content=fwrite($handle, $line . chr(10));
   	fclose($handle);
}


function setLoggedIn($strUser)
{

	//setcookie("these",$strUser, time()+9999, "/");
	if ( setcookie("these", addletters($strUser, encryptionkey), time()+1131536000, "/" ))
	{
		//echo "cookie set!";
	}
}

function logout()
{
	//echo "#";
 	//global $COOKIE_VARS;
	if (setcookie("these", "x", mktime(12,0,0,1, 1, 1990), "/" ))
	{
		//echo "cookie cleared!";
	}
}

function loginarrest($strPHP)
{
	$strUserNameFormItem= qpre . "username";
	$strPasswordFormItem=qpre . "password";
	$out="";
	$out.="<h2>Log in here:</h2>\n";
	$out.="<table >\n";
	$out.="<form target=\"_top\" action=\"" . $strPHP . "\" method=\"POST\">\n";
	$out.="\n";
	$out.="<tr><td>\n";
	$out.="Username:</td><td><input type=\"text\" name=\"" . $strUserNameFormItem . "\" value=\"\"></td></tr>\n";
	$out.="<tr><td>\n";
	$out.="Password:</td><td><input type=\"password\" name=\"" . $strPasswordFormItem . "\" value=\"\"></td></tr>\n";
	$out.="<tr><td colspan=\"2\" align=\"right\"><input type=\"Submit\" value=\"Login\"></td></tr>\n";
	$strAvoidList=$strUserNameFormItem . " " . $strPasswordFormItem;
	if ($_REQUEST[qpre . "mode"]=="logout")
	{
		$strAvoidList.= " " .  qpre .   "mode";
		$out.=HiddenInputs(Array( qpre .   "mode"=>""), "", "");
	}
	//echo  $strAvoidList;
	$out.=HiddenInputs($_REQUEST, "", $strAvoidList);
	$out.="</form>\n";
	$out.="</table >\n";
	return $out;
}

function LoginDecisions($strDatabase,  $strPHP,  &$strUser, $bwlSimpleOutput)
//returns $strUser as a "by reference" variable
{
	$strUser=$_REQUEST[qpre . "username"];
	$Password=$_REQUEST[qpre . "password"];
	$skiplogintest=false;
	$out="";
	if ($_REQUEST[ qpre . "mode"]=="logout")
		{
			logout();
			$out="You have been logged out.";
			
			$skiplogintest=true;
		}
	if (countrecords($strDatabase , tfpre . "admin" )<1)
		{
			$strUser="-no security-";
			$skiplogintest=true;
			$bwlSimpleOutput=true;
		}
	elseif ($strUser!="" && $Password!="")
		{
			$strUser=TestAndSetLogin($strDatabase, $strUser, $Password);
			
			if ($strUser=="")
			{
				$out="<span class=\"feedback\">The Username/Password combination you typed has failed.</span>";
			}
			else 
			{
				$skiplogintest=true;
			}
		}
 	if (!$skiplogintest)
		{
			//if ($_REQUEST[ qpre . "mode"]!="logout")
			{
				$strUser=WhoIsLoggedIn();
			}
		}	
	if (!$bwlSimpleOutput)
		{
			if ($strUser!="")
				{
					$strPHP = replaceMultipleQueryVariables(qpre ."username", "", qpre ."password",  "", qpre ."mode", "logout");
					$out="<div class=\"loginstring\">You are currently logged in as <b>" . $strUser . "</b>.  (<a href=\"" . $strPHP  . "\">Logout</a>)</div>\n";
				}
			if ($strUser=="" )
				{
					$out.=loginarrest($strPHP);
				}
		}
	elseif ($strUser=="")
		{
			$out="You do not have permissions to see this content.";
		}
	return $out;
}

function IsSuperuser($strDatabase, $strAdmin)
{
	if (TableExists($strDatabase, tfpre . "permission") && TableExists($strDatabase, tfpre . "admin")) //if no admin tables, everyone is an admin!
	{
		$sql=conDB();
		$strSQL="SELECT  is_superuser from  " . $strDatabase . "." . tfpre . "admin WHERE username = '" . $strAdmin . "'";
		$records = $sql->query($strSQL);
		$record=$records[0];
	 
	 	$out=false;
		if ($record["is_superuser"]==1)
		{
			$out=true;
		}
	}
	else
	{
		$out=true;
	}
	return $out;
}

function IsSuperAdmin($strDatabase, $strAdmin)
{
	 
	$sql=conDB();
	$strSQL="SELECT  is_superadmin from  " . $strDatabase . "." . tfpre . "admin WHERE is_superadmin = 1";
	$records = $sql->query($strSQL);
	if (count($records)>0)  //if there are no superadmins then everyone is a superadmin!
	{
		
		$strSQL="SELECT  is_superadmin from  " . $strDatabase . "." . tfpre . "admin WHERE username = '" . $strAdmin . "'";
		//echo $strSQL;
		$records = $sql->query($strSQL);
		$record=$records[0];
	 
	 	$out=false;
		if ($record["is_superadmin"]==1)
		{
			$out=true;
		}
	}
	else
	{
		$out=true;
	}
 	//echo $record["is_superuser"] . "<br>";
 
	return $out;
}

function AdminIDRangePermCalc($rangelow, $rangehigh, $thisid)
{
	$bwlOut=false;
	
	if ($thisid!="")
	{
		if (($rangelow<= $thisid  || $rangelow=="") && ($rangehigh>=$thisid || $rangehigh==""))
		{
			$bwlOut=true;
		}
	}
	{
		$bwlOut=true;
	}
	return $bwlOut;
}

function UserIDToSelectAddendum($strDatabase, $strTable, $pk, $UserID)
{
	//creates the SQL phrase added to the select in cases where 
	if ($UserID!="")
	{
		if ($pk=="")
		{
			 $pk=PKLookup($strDatabase, $strTable);
		}
		$sql=conDB();
		$strSQL="SELECT id_range_lowend, id_range_highend FROM " . $strDatabase . "." . tfpre . "permission WHERE admin_id = " . $UserID . " AND  table_name='" . $strTable . "'";
		//echo $strSQL;
		$rs = $sql->query($strSQL);
		$r=$rs[0];
		$lowpart="";
		$highpart="";
		if ($r["id_range_lowend"]!=""  )
		{
			$lowpart=$pk . ">=" . $r["id_range_lowend"];
		}
		if ($r["id_range_highend"]!="")
		{
		 	$highpart= $pk . "<=" . $r["id_range_highend"];
		}
		$out=$lowpart . IfAThenB($highpart," AND ") . $highpart;
	}
	return $out;
}


function AdministerType($strDatabase, $strTable, $strAdmin, $id="")
{
	$sql=conDB();
	$strSQL="SELECT permission_type_id as 'p', id_range_lowend, id_range_highend FROM  " . $strDatabase . "." . tfpre . "permission p LEFT JOIN " . $strDatabase . "." . tfpre . "admin a ON p.admin_id=a.admin_id WHERE a.username = '" . $strAdmin . "' AND p.table_name='" . $strTable . "'";
	//$strSQL="select member_id from " . $strDatabase . ".member";
	//echo $strSQL;
	if (TableExists($strDatabase, tfpre . "permission") && TableExists($strDatabase, tfpre . "admin"))
	{
		$rs = $sql->query($strSQL);
		//echo count($rs);
		$r=$rs[0];
		if ( AdminIDRangePermCalc($r["id_range_lowend"], $r["id_range_highend"], $id))
		{
			$out= $r["p"];
		}
	 	//echo $out . "$<br>";
		if (IsSuperuser($strDatabase, $strAdmin))
		{
			$out=2;
		}
	}
	else
	{
		$out=2;
	}
	//echo $out;
	return $out;
}

function GetAdminID($strDatabase, $strAdmin)
{
	$sql=conDB();
	$strSQL="SELECT admin_id FROM  " . $strDatabase . "." . tfpre . "admin  WHERE username = '" . $strAdmin . "'";
	//echo $strSQL;
	$records = $sql->query($strSQL);
	$record=$records[0];
	$out= $record["admin_id"];
	return $out;
}

//////////////////////////////////////////
//IMAGE AND FILE FUNCTIONS///////////////
////////////////////////////////////////

function isImageFileName($strName)
{
	$strTestPath=strtolower($strName);
	if (strpos($strTestPath, ".jpg")>1  || strpos($strTestPath, ".gif")>1 || strpos($strTestPath, ".swf")>1)
	{
		return true;
	}
	else
	{
		return false;
	}
}

function fieldNameToFolderPath($strIn, $strRoot)
{
 //this is totally a hack function that does a good job in this particular application
 //of determining the proper upload path based only on the field name
	$arrName=explode("_", $strIn);
	$strPossibleFolder=$arrName[0];
	//echo $strPossibleFolder . "&<br>";
	//echo $strPossibleFolder . "<br>";
	if ($strPossibleFolder!="flash")
	{
		$path= $strRoot . "/" . pluralize($strPossibleFolder) . "/";
	}
	else
	{
		//in this site, swfs are just loose in the top level
		$path= "";
	}
	return $path;
}

function PictureIfThere($strPath, $intWidth, $intHeight="", $border=" ", $url="")
{
	//echo $strPath . "<br>";
	$strTestPath=strtolower($strPath);
	if (file_exists($strPath))
	{
		if (isImageFileName($strPath))
		{

			if ($border!=" ")
			{
				$border=" border=\"" . $border . "\"";
			}
			if (strpos($strTestPath, ".swf")>1)
			{
				if ($intHeight=="") 
				{
					$intHeight= $intWidth * .5;
				
				}
				//echo ">>>>>--------------%%%%%%%%%%%%%%%%%%%%%%" & $intHeight;
				$out.= flash("cccc99",$intWidth, $intHeight, $strPath, $url) ;
			}

			else
			{
				if ($intHeight!="")
				{
					$intHeight=" height=\"" . $intHeight . "\"";
				}
				$out.=  "<img src=\"" . $strPath  ."\" width=\"" . $intWidth . "\"" . $intHeight . " border=\"0\">";
			}
		}
	}
	return $out;
}

function flash($bgcolor,$width, $height, $swffile, $url="")
//display a Flash object embed for both IE and Mozilla
	{
		//echo $width . "-------&&&&&&&------" . $height;
		$canflash=true;
		$out="";
		 
		if ($canflash==true)
		{
			if(isset($_SERVER['HTTP_USER_AGENT']) && preg_match("/MSIE/", $_SERVER['HTTP_USER_AGENT']))
			{
				$out= "<div style=\"z-index:4\" id=\"adlayer\"><a href=\"" . $url . "\">" . SpacerGif($width, $height) . "</a></div>";
			}
			$out.="<span style=\"z-index:0\" onclick=\"window.location.href='" . $url . "'\" ><object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\"".  chr(13); 
			$out.="codebase=\"http://active.macromedia.com/flash2/cabs/swflash.cab#version=4,0,0,0\"" .chr(13); 
			$out.= "ID=\"logo\"  width=\"".$width."\" height=\"".$height."\">" .chr(13);
			$out.="<param  name=\"movie\" VALUE=\"" . $swffile ."\"><param  name=\"wmode\" VALUE=\"transparent\"> <param name=\"quality\" value=\"high\">" .chr(13);
			$out.="<param name=\"bgcolor\" VALUE=\"".$bgcolor."\">";
			$out.="<embed wmode=\"transparent\" src=\"". $swffile . "\" quality=\"high\"" .chr(13);
			$out.= "bgcolor=\"".$bgcolor."\"  WIDTH=\"".$width."\" HEIGHT=\"".$height."\" TYPE=\"application/x-shockwave-flash\"" .chr(13);
			$out.= " PLUGINSPAGE=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_\"" .chr(13);
			$out.= "Version=\"ShockwaveFlash\"></embed>";
			$out.= "</object></span>" .chr(13);
		}
		else
		{
			$out="Can't load flash." . chr(13);
		}
		return($out);
	}

function SpacerGif($width, $height)
{
	$out="<img src=\"". imagepath . "/spacer.gif\" width=\"" . $width . "\" height=\"" . $height . "\" border=\"0\">";
	return $out;
}

function NeedsUpload($strFieldName)
{
	//looks at a field and determines whether or not it should get an upload file form item
	$strTextIndications="filename banner";
 	$arrIndic=explode(" ", $strTextIndications);
 
	for ($i=0; $i<count($arrIndic); $i++)
	{
		if (contains($strFieldName, $arrIndic[$i]))
		{
			return true;
		}
	}
	return false;
}

function BuildPathPiecesAsNecessary($strPath)
{
	//makes all the folders down to a location in a directory tree in case they do not exist
	$strPath = str_replace( "\\", "/", $strPath);
	$strPath= deMultiple($strPath, "/");
	$arrPath=explode("/", $strPath);
	$strPathOut="";
	$out=true;
	for ($i=0; $i<count($arrPath); $i++)
	{
		//echo $strPathOut . "*<br>";
		if ($i==0)
		{
			//dont use a beginning slash unless our string begins with one
			$strPathOut.=$arrPath[$i];
		}
		else
		{
			$strPathOut.="/" . $arrPath[$i];
		}
		if (!file_exists($strPathOut))
		{
			if ($strPathOut!="")
			{
				if (strpos("---" . $arrPath[$i], ".")>0)
				{
					 //don't add a file or folder if this item contains a "."
				}
				else
				{
					//echo $strPathOut . "-   <br>";
				
					if (!mkdir($strPathOut, 0777))
						{
							$out=false;
						}
				}
			}
		}
	}
	return $out;
}

//////////////////////////////////////////////
/////functions specific to tableform/////////
////////////////////////////////////////////

function SearchTypeToSQLPhrase($intSearchType, $strSearchField, $strSearchString)
{
	$strSQL="";
	if ($strSearchString!="" &&  $strSearchField!="")
	{
		if ($intSearchType==0)
		{
			$strSQL=" WHERE " . $strSearchField . " LIKE '" . $strSearchString . "%'";
		}
		elseif ($intSearchType==1)
		{
			$strSQL=" WHERE " . $strSearchField . " LIKE '%" . $strSearchString . "%'";
		}
		elseif ($intSearchType==2)
		{
			$strSQL=" WHERE " . $strSearchField . " LIKE '%" . $strSearchString . "'";
		}
		elseif ($intSearchType==3)
		{
			$strSQL=" WHERE " . $strSearchField . " = '" . $strSearchString . "'";
		}
	}
	return $strSQL;
}

function BrowseTypeSevenTool($strDatabase, $strTable)
{
	$strTFTable=tfpre . "browsescheme";
	if (TableExists($strDatabase, $strTFTable))
	{
		$sql=conDB();
		$strSQL="SELECT * FROM " . $strDatabase . "." . $strTFTable . " WHERE table_name='" . $strTable . "' AND browsetype_id=7";
		//echo $strSQL . "<br>";
		$records = $sql->query($strSQL); 
		$record=$records[0];
		//$url=$record["toolpage"];
		return $record;
	}
	return false;
}

function DisplayDataTable($strDatabase, $strTable, $strIDFieldName, $strSortColumn, $strPHP, $strDirection, $intRecord, $strSearchString, $strSearchField, $intSearchType,$intRecsPerPage=50, $strFieldConfig="", $intFieldLimitLo=1,$intFieldLimitHi=5, $bwlShowDelete=true, $bwlHandback=false, $bwlSuppressHeaderLinks=false, $launcherfield="", $displaytype="", $intThisFilterID, $UserID="")
//displays the entire contents of a given table.  $strIDFieldName allows for editing by primary key reference
//$strSortColumn allows for picking a column to sort by (ASC or DESC depending on $strDirection)
//i admit this function is becoming unmaintainable due to the many scenarios i have forced it to handle
{
 	//this loop is kind of awkward, but it allows me to pass a variable through to this function through the query string
	foreach($_GET as $k=>$v)
	{
		if (!beginswith($k, qpre))
		{
			$extraqsk=$k;
			$extraqsv=$v;
		}
	
	}
	$intTruncSize=30;
	$strBgClassFirst="bgclassfirst";
	$strBgClassSecond="bgclasssecond";
	$strBgClassOther="bgclassother";
	$strLineClass="bgclassline";
	$strActionStyle="font-size:9px";
	$strThisBgClass=$strBgClassFirst;
	$bwlShowEdit=true;
	$strGraphClassFirst="graph1";
	$strGraphClassSecond="graph2";
	$bwlBrowseMode=false;
	$strPHPForRows=$strPHP;
	$intSpacerColumns=2;
	$strOriginalTable=$strTable;
	$strWidthSpecialOther="";
	$sql=conDB();
	$ToolRecord=BrowseTypeSevenTool($strDatabase, $strTable);
	$descr = $sql->query("EXPLAIN "  .   $strDatabase. "." . $strTable);
	$whereadditional="";
	$strCountSearch="count(*)";
	$strNameColumn=firstnonidcolumname($strDatabase,  $strTable);
	$strAdminIDRangeAddendum=UserIDToSelectAddendum($strDatabase, $strTable, $strIDFieldName, $UserID);
	//$strSQL=" FROM  " .  $strDatabase . "." . $strTable ;
	//the following block of code is specific to a type of view called a graph.  i have to handle the specifics of its display in a non-generic way,
	//as i will have to do with every type of view
	
	//5-4-2006: actually, it is to any type of browser scheme, some of which will be graphs
	if ($displaytype!="")   //it's a graph
	{
		$strSQLThis="SELECT * FROM " . $strDatabase. "." . tfpre . "browsescheme WHERE table_name='" . $strTable . "'";
		$records = $sql->query( $strSQLThis);
		$record=$records[0];
		$strGivenLabelField=$record["label_field"];
		$strPHPForRows=gracefuldecay($record["toolpage"], $strPHP);
		$strGivenQuantityField_x=$record["quantity_field_x"];
		$strGivenFilterField=$record["filter_field"];
		$strSQLThis="SELECT MAX(" . $strGivenQuantityField_x . ") as MAX FROM " . $strDatabase. "." . $strTable . " WHERE " . $strGivenFilterField . " = " . $intThisFilterID;
		$strSQLThis=ProperlyAppendSQLWherePhrase($strSQLThis, $strAdminIDRangeAddendum);
		$records = $sql->query( $strSQLThis);
		$record=$records[0];
		$intMaxVal=$record["MAX"];
		$arrFKLookup=foreignKeyLookup($strDatabase, $strTable, $strGivenFilterField);
		$FKtable=$arrFKLookup[0];
		$FKIDField=$arrFKLookup[1];
		$strFieldConfig=$strTable . "|" . $strGivenLabelField . "|" . $strGivenQuantityField_x;
		$intFieldLimitLo=intval(-1);
		$intFieldLimitHi=4;
		$bwlShowDelete=false;
		$bwlShowEdit=false;
		$intSpacerColumns=0;
		if ($intThisFilterID!="")
		{
			$whereadditional=" WHERE " . $strGivenFilterField  . " = " . $intThisFilterID;
		}
		else
		{
			//if we don't have an id to filter on and there needs to be one, then we need to generate a conventional data browser for the filter id's table,
			//which is to be found in the table it is a foreign key for.
			
			$arrFKLookup=foreignKeyLookup($strDatabase, $strTable, $strGivenFilterField);
			$FKtable=$arrFKLookup[0];
			if ($FKtable!="")
			{
				//$strSQL=" FROM " .   $strDatabase. "." . $FKtable;
				$descr = $sql->query("EXPLAIN "  .   $strDatabase. "." . $FKtable);
				$strNameColumn=firstnonidcolumname($strDatabase,  $FKtable);
				$strTable=$FKtable;
			}
			//for now i'll just turn off fieldconfig in these special data browser situations
			$strFieldConfig="";
			$bwlBrowseMode=true;
		}
	}
	$strSQL.=SearchTypeToSQLPhrase($intSearchType, $strSearchField, $strSearchString);
	$strSQL=ProperlyAppendSQLWherePhrase($strSQL, $strAdminIDRangeAddendum);
	$strSQL.=$whereadditional;
	//added some code to default to sort by pk

	if ($strIDFieldName=="")
	{
		$strIDFieldName=PKLookup($strDatabase, $strTable);
	}
	if ($strSortColumn=="")
	{
		$strSortColumn=$strIDFieldName;
	}
	
	//echo "-" . $strSortColumn . "-<br>+" .  $strIDFieldName . "+<br>";
	if ($strSortColumn!="")
	{
		$strSQL.=" ORDER BY " . $strSortColumn . " " . $strDirection;
	}
	//echo "SELECT " . $strCountSearch . "  FROM " .   $strDatabase. "." . $strTable . $strSQL;
	$records = $sql->query("SELECT " . $strCountSearch . "  FROM " .   $strDatabase. "." . $strTable . $strSQL);
	$record=$records[0];
	$count=$record[$strCountSearch];
	//echo "<br>" . $count;
	//$strDoSQL=" FROM " .   $strDatabase. "." . $strTable;
	//$strDoSQL="SELECT * " . $strDoSQL . $strSQL;
	$strDoSQL.=" LIMIT " . $intRecord . "," . $intRecsPerPage;

	$strDoSQL=FleshedOutFKSelect($strDatabase, $strTable, $strSQL . " " .$strDoSQL, $arrDescr);
	$out="";
	//echo "<br>" . $strDoSQL;
	$records = $sql->query($strDoSQL);
	$out.= "\n<table border=\"0\" cellspacing=\"1\" cellpadding=\"2\" class=\"" .$strLineClass  . "\" width=\"100%\">\n";
	$out.=   TableColumnHeader($strDatabase,$strOriginalTable, $strPHP, $strDirection, $strLineClass, $strBgClassOther, $strSortColumn, $strSearchString, $strSearchField, $intSearchType,  $intFieldLimitHi, $intFieldLimitLo, $strFieldConfig, $bwlSuppressHeaderLinks, $launcherfield, $displaytype, addBwls($bwlShowEdit, $bwlShowDelete, $ToolRecord!=""), $intThisFilterID, $FKIDField, $FKtable, $bwlBrowseMode, $records[0]);
 	$strPHP=$strPHPForRows;
	foreach ($records as $key=>$value )
	{
		$strThisBgClass=Alternate($strBgClassFirst, $strBgClassSecond, $strThisBgClass);
		$out.= "<tr class=\"" . $strThisBgClass . "\">\n";
		$intFieldCount=0;
		foreach ( $value as $key1 => $value1 )
		{
			$type=$arrDescr[$columnname];
			if (GreaterFieldDisplayLogic($strTable, $strFieldConfig, $key1, $intFieldCount, $intFieldLimitLo, $intFieldLimitHi))
			{
				$strWidthSpecial=$strWidthSpecialOther; //a clever trick allowing a bars in graph mode to slam the other columns narrow
				switch ($type)
				{
					case "date":
					{
						if ($value1!="")
						{
							if (!is_numeric($value1)  && $value1!="")
								{	
									$value1=strtotime($value1);
								}
							$value1 = date('m/j/y', $value1);
						}
						else
						{
							$value1="";
						}
						break;
					}
					case "tinyint":
					{
						$value1=IntToSQLBoul($value1);
						break;
					}
				}
				if ($bwlBrowseMode && $strNameColumn== $key1)  //we're in browser mode and this is a name column, so time for a hyperlink
				{
					$strDataToDisplay="<a href=\"" . qbuild($strPHP, $strDatabase, $strOriginalTable , "view", $strIDFieldName, $value[$strIDFieldName]) . "&" . qpre . "displaytype=" . $displaytype . "&" . qpre . "filterid=" . $value[$strIDFieldName] . "\">" . trunchandler( $value1, $intTruncSize) . "</a>";
				
				}
				elseif ($key1==$strGivenQuantityField_x  && $displaytype==1)  //then this is a graphable quantity
				{
					//this block of code only makes sense with 2-d graphs!
					$graphwidth=400;
					$strThisGraphClass=Alternate($strGraphClassFirst, $strGraphClassSecond, $strThisGraphClass);
					$strDataToDisplay=GraphValue($value1, $intMaxVal, $graphwidth, 13, $strThisGraphClass, false);
					$strWidthSpecial=" width=\"" .  intval($graphwidth + 59). "\"";
					$strWidthSpecialOther=" width=\"50\"";
				}
				elseif ($key1=="password")
				{
					
					$strDataToDisplay=passworddisplay($value1);
				}
				else
				{
					$strDataToDisplay=trunchandler($value1, $intTruncSize);
				}
				$out.= "<td valign=\"top\"" . $strWidthSpecial . ">".   $strDataToDisplay  ."</td>\n";
				if ($strNameColumn==$key1)
				{
					$strPrettyName=trunchandler($value1, $intTruncSize);
				}
				$intFieldCount++;
			}
		}
		if ($bwlShowDelete)
			{
				$out.= "<td valign=\"top\">\n";
				$out.= "<a style=\"" . $strActionStyle . "\" onclick=\"javascript:return(confirm('Are you sure you want to delete " . $strTable . " number " . $value[$strIDFieldName] . "?'))\" href='" . qbuild($strPHP, $strDatabase, $strTable, "delete", $strIDFieldName, $value[$strIDFieldName]) . "&" . qpre . "displaytype=" . $displaytype  ."&" . qpre . "filterid=" . $intThisFilterID .  "&" . qpre . "column=" . $strSortColumn  . "&" . qpre . "direction=" . $strDirection . "&" . qpre . "rec=" . $intRecord . "'>Delete</a>";
				$out.= "</td>\n";
			}
 
		if ($bwlShowEdit)
		{
			$out.= "<td  valign=\"top\">\n";
			if ($bwlHandback)
			{
				$out.= "<a style=\"" . $strActionStyle . "\" href='javascript:handback(\"" .  $strTable . "\",\"" . $strIDFieldName . "\",\"" . $value[$strIDFieldName]  . "\",\"" .  $strPrettyName  . "\",\"" . $extraqsk . "\",\"" .  $extraqsv . "\")'>Select</a>";
			}
			else
			{
				$out.= "<a style=\"" . $strActionStyle . "\" href='" . qbuild($strPHP, $strDatabase, $strTable, "edit", $strIDFieldName, $value[$strIDFieldName])  . "&" . qpre . "displaytype=" . $displaytype  ."&" . qpre . "filterid=" . $intThisFilterID . "&" . qpre . "rec=" . $intRecord . "&" . qpre . "column=" . $strSortColumn  . "&" . qpre . "direction=" . $strDirection . "'>Edit</a>";
			}

			
			$out.= "</td>\n";
			
			if ($ToolRecord!="")
			{
				
				$out.= "<td>\n";
				$out.= "<a style=\"" . $strActionStyle . "\" href='" . qbuild(gracefuldecay($ToolRecord["toolpage"], $strPHP), $strDatabase, $strTable, "specificview", $strIDFieldName, $value[$strIDFieldName])  . "&" . qpre . "displaytype=" . $displaytype  . "&" . qpre . "rec=" . $intRecord . "'>" . gracefuldecay($ToolRecord["integration_label"], "More..."). "</a>";
				$out.= "</td>\n";
			
			}
	 	}
		$out.= "</tr>\n";
	}
	$out.= "</table>\n";
	
	if ($count>$intRecsPerPage)
	{
		$out.= "<table border=\"0\" cellspacing=\"1\" cellpadding=\"2\" class=\"" .$strLineClass  . "\" width=\"100%\">\n";
		$out.= "<tr>\n";
		$out.= "<td>\n";
		$out.=paginatelinks($count, $intRecsPerPage, $intRecord, $strPHP, qpre . "rec");
		$out.= "</td>\n";
		$out.= "</tr>\n";
		$out.= "</table>\n";
	}
	return $out;
}

function TableColumnHeader($strDatabase, $strTable, $strPHP, $strDirection, $strHeaderStyle,$strNewStyle, $strSortColumn, $strSearchString, $strSearchField, $intSearchType,  $intFieldLimitHi, $intFieldLimitLo, $strFieldConfig, $bwlSuppressHeaderLinks, $launcherfield="", $displaytype="", $intSpacerColumns=2, $intThisFilterID="",   $strFilterIDField, $strFilterTable, $bwlBrowseMode=false, $samplerecord)
//provides a set of clickable headers for a display of table data. those clicks determine the sort order
//breaking this out into a separate function probably wasn't the wisest idea, but i had to get stuff out of DisplayDataTable
{
	$first=true;
	$out= "<form name=\"searchform\" action=\"" .  $strPHP . "\"><tr class=\"" . $strHeaderStyle . "\">\n";
	$strATag="a";
	$strATag2="x";
	$strOriginalTable= $strTable;//i have to store the original table so i have for later when i make the clickable column headings
	if ($intThisFilterID!="" )
	{
		$strTableLink = qbuild($strPHP, $strDatabase, $strTable, "view", $strIDFieldName, $value[$strIDFieldName])   . "&" . qpre . "displaytype=" . $displaytype;
	}

	$out.= adminbreadcrumb($bwlSuppressHeaderLinks,  $strDatabase, $strPHP . "?" . qpre . "db=" . $strDatabase,   $strTable,  $strTableLink);
	if ($displaytype!="")
	{
		$viewtypelabel=LookupName($strDatabase,tfpre . "browsetype","browsetype_id", $displaytype);
		$out.= "<span class=\"heading\">(" . $viewtypelabel . ")</span>";
	}
	if ($intThisFilterID!="")
	{
		$strFilterName = LookupName($strDatabase,$strFilterTable,$strFilterIDField, $intThisFilterID);
		$out.= " : <span class=\"heading\">" . $strFilterName . "</span>\n" ;
	}
	elseif ($displaytype!="")
	{
		$out.= " : <span class=\"heading\">select a " . $strFilterTable. "</span>" ;
	}
	$out2.= "</td>\n";
	$strSearch.= HiddenInputs(array("column"=>$strSortColumn, "table"=>$strTable,"table"=>$strTable,"db"=>$strDatabase,"filterid"=>$intThisFilterID,"direction"=>$strDirection,"displaytype"=>$displaytype,"mode"=>"view","launcherfield"=>$launcherfield));

	if ($strFilterTable!=""  && $intThisFilterID=="")//if we are in browser mode for a view, then from now on it's all about the picker table we passed in
	{
		$strTable=$strFilterTable;
	}
	$sql=conDB();
	
	//if there is no data in the table then we have to look at the table's description
	$arrDesc=$samplerecord;
	if(count($arrDesc)<1)
	{
		$arrDesc=GetFieldTypeArray($strDatabase, $strTable); //$sql->query("EXPLAIN " . $strDatabase . "." . $strTable);
	}

	$out3="";
	if (!$bwlSuppressHeaderLinks)
	{
		//$out3.= "<td width=\"40\" colspan=\"2\" width=\"0\" align=\"right\" class=\"" . $strLabelStyle . "\">\n";
		$out3.= "<a href='" . qbuild($strPHP, $strDatabase, $strTable, "new", "", "")  . "&" . qpre . "displaytype=" . $displaytype  . "&" . qpre . "filterid=" . $intThisFilterID . "'>New <b>" .  $strTable . "</b></a>";
		//$out3.= "</td>\n";
	}
	//$out2.= "</tr>\n</table>\n";
	$out2.= "\n<table border=\"0\" cellspacing=\"1\" cellpadding=\"2\" class=\"" .$strHeaderStyle  . "\" width=\"100%\">\n";
	$out2.="<tr>\n";
	$strDirection=ReverseDirectionSQL($strDirection);
	$strSearch.="&nbsp;&nbsp;&nbsp;&nbsp;Search for\n <input name=\"" . qpre . "searchstring\" size=\"10\" type=\"text\" value=\"" . $strSearchString . "\">\n";
	$strConfig="0|at the beginning of-1|within-2|at the end of-3|as";
	$strSearch.=  GenericDataPulldown($strConfig,0, 1, qpre . "searchtype", $intSearchType, "", "", "searchselect");
	$strSearch.=   " the ";
	$strSearch.="<select name=\"" . qpre . "searchfield\" class=\"searchselect\">\n";
	$intFieldCount=0;
	foreach ($arrDesc as $name=>$info)
		{
 
			//$name=$that;  
			if (GreaterFieldDisplayLogic($strTable, $strFieldConfig, $name, $intFieldCount, $intFieldLimitLo, $intFieldLimitHi))
			{
				$out2.="<td >\n";
				
				$strSel="";
				if ($name==$strSearchField)
				{
					$strSel=" selected";
				}
				$strSearch.="<option" . $strSel . ">" . $name . "</option>\n";
				$displayname=$name;
				//if the field is called simply "name" then the table is a more useful description
				//if ($name=="name")
				//{
					//$displayname=$strTable;
				//}
				$out2.="<a href=\"". qbuild($strPHP, $strDatabase, $strOriginalTable, "view", $strIDFieldName, $value[$strIDFieldName]) . "&" . qpre . "displaytype=" . $displaytype   . "&" . qpre . "filterid=" . $intThisFilterID . "&" . qpre . "launcherfield=" . $launcherfield . "&" . qpre . "direction=" . $strDirection . "&" . qpre . "column=" . $name . "\">" . $displayname . "</a>\n";
				$out2.="</td>\n";
				$intFieldCount++;
			}
		}
	$strSearch.="<\select>\n field\n <input class=\"btn\"
   onmouseover=\"this.className='btn btnhov'\" onmouseout=\"this.className='btn'\" name=\"" . qpre . "searchbutton\" value=\"search\" type=\"submit\">\n";

	//for ($i=$intSpacerColumns; $i<0; $i--)
	//{
		//$out2.="<td width=\"20\">&nbsp;</td>";
	//}
	$out2.="<td width=\"80\" colspan=\"" . $intSpacerColumns . "\" align=\"right\" class=\"" . $strNewStyle . "\">" . $out3 . "</td>";
	if ($intThisFilterID=="")
	{
		$out=$out.$strSearch . $out2;
	}
	else
	{
		$out=$out. $out2;
	}
	return($out);
}

function GraphValue($intVal, $intMax, $intFullWidth, $intHeight, $strClass, $bwlFormat="", $intTotal=1)
{
	//im going to assume the existence of a spacer gif called spacer.gif in the images directory
	$intVal=intval($intVal);
	$intRenderLength=intval(($intVal/$intMax) *$intFullWidth);
	$out.= "<table  border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  >\n";
	$out.= "<tr>\n";
	$out.= "<td width=\"54\" align=\"right\" class=\"graphlabel\">\n";
	if ($bwlFormat=="percent")
	{
		$out.= intval(100* ($intVal/$intTotal)) . "%";
	}
	else if ($bwlFormat=="")
	{
		$out.= $intVal;
	}
	$out.= "</td>\n";
	$out.= "<td  align=\"right\">\n";
	$out.= "&nbsp;";
	$out.= "</td>\n";
	$out.= "<td class=\"" . $strClass . "\">\n";
	$out.= SpacerGif($intRenderLength, $intHeight);
	$out.= "</td>\n";
	$out.= "</tr>\n";
	$out.= "</table>\n";
	return $out;
}

/////////////////
///encryption///
///////////////

function addletters($in, $key)
//converts numbers into a letter stream
{
	$out="";
	$in=$in."";
	while (strlen($key)<strlen($in))
	{
		$key.=$key;
	}
	for ($i=0; $i<strlen($in); $i++)
	{
		$intchrIn=ord(substr($in, $i, 1));
		$intchrKey=ord(substr($key, $i, 1));
		$out=$out. chr($intchrIn + $intchrKey);
	};
	return $out;
}

function subtractletters($in, $key)
//converts numbers into a letter stream
{
	$out="";
	while (strlen($key)<strlen($in))
	{
		$key.=$key;
	}
	for ($i=0; $i<strlen($in); $i++)
	{
		$intchrIn=ord(substr($in, $i, 1));
		$intchrKey=ord(substr($key, $i, 1));
		$out=$out. chr($intchrIn - $intchrKey);
	}
	return $out;
}


function wordencode($intNumber, $intDigits, $rndhelp)
{
	$out="";
	$that="";
	$strNumber=str_pad($intNumber, $intDigits, "0", STR_PAD_LEFT);
	for($i=0; $i<$intDigits; $i=$i+3)
	{
		$that=substr($strNumber, $i, 3);
		//echo $that;
		{
			$thisnumber=intval($that);
			if ($thisnumber==0)
			{
				srand((double)$rndhelp); 
				$thisnumber = rand(0,40)+1000; 
			}
			//echo $thisnumber . "-<br>";
			$word=GenericDBLookup(our_db,  "word_coding", "word_coding_id", $thisnumber, "word");
			//echo $word . "+<br>";
			$out.=$word . " ";
		}
	}
	$out=RemoveEndCharactersIfMatch($out, " ");
	return $out;
}


function worddecode($strPhrase)
{
	$strPhrase=strtolower($strPhrase);
	$strPhrase=str_replace("-", " ", $strPhrase);
	$strPhrase=str_replace("=", " ", $strPhrase);
	$strPhrase=str_replace(".", " ", $strPhrase);
	$strPhrase=str_replace(",", " ", $strPhrase);
	$strPhrase=str_replace(":", " ", $strPhrase);
	$strPhrase=str_replace(";", " ", $strPhrase);
	$arrPhrase=explode(" ", $strPhrase);
	$out="";
	$that="";
	$strNumber=str_pad($intNumber, $intDigits, "0", STR_PAD_LEFT);
 
	for($i=0; $i<count($arrPhrase); $i++)
	{
	
		$that=$arrPhrase[$i];
		if ($that!="")
		{
			//echo $thisnumber . "-<br>";
			$thisnumber=GenericDBLookup(our_db,  "word_coding", "word", $that, "word_coding_id");
			if ($thisnumber<1000)
			{
				$intDigits=str_pad($thisnumber,3, "0", STR_PAD_LEFT);
				$intDigits=intval($intDigits);
			}
			else
			{
				$intDigits="000";
			}
			//echo $word . "+<br>";
			$out.=$intDigits;
		}
	}
	return $out;
}



function DisplayDataForARow($strDatabase, $strTable, $strIDField, $strValDefault, $strPHP)
{
//a simple display-only dump of a row (derived from tableform)
//an improved method of doing this would take advantage of my FleshedOutFKSelect sql funtion
	$sql=conDB();
	$out="";
	$length=50;
	$strClassFirst="bgclassfirst";
	$strClassSecond="bgclasssecond";
	$strOtherBgClass="bgclassother";
	$strThisBgClass=$strClassFirst;
	$intNestTable=0;
	$strNest=""; 
	if  ($strIDField=="")
	{
		$strIDField= idcolumname($strDatabase, $strTable);
	}
	
	$out.="<table class=\"" . $strOtherBgClass . "\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n";


	$descr = $sql->query("EXPLAIN " . $strDatabase . "." . $strTable);
 
	$out.= "<tr class=\"" . $strOtherBgClass . "\">\n";
	$out.= "<td colspan=\"" . intval(count($descr))  . "\">";
	$intDefaultWide=50;
	
	if (!contains($strExtrajs, "noheader"))
	{
		if ($strExtrajs!="closeclickrecycle")
			{
				
				$intDefaultWide=90;
				$secondarytoollable=$strDatabase;
				$closebutton="";
				$disablelink=false;
			}
			else
			{
				$secondarytoollable="Secondary Editor";
				$closebutton="  [<a href=\"message.php\">close this tool</a>]";
				$disablelink=true;
			}

		$out.=adminbreadcrumb($disablelink,  $secondarytoollable, $strPHP . "?" . qpre . "db=" . $strDatabase,  $strTable, qbuild($strPHP, $strDatabase, $strTable, "view", "", "")) . $closebutton;
	}
	
	$out.= "</td>\n";
	$out.= "</tr>\n";
  
	$record="";
	if ($strValDefault!="")
	{
	
		$strSQL="SELECT * FROM " . $strDatabase . "." . $strTable . " WHERE " .  $strIDField . " = '" . $strValDefault . "'";
		//echo $strSQL;
		$records = $sql->query($strSQL);
		$record=$records[0];
		$strOtherButtonText="New " . $strTable;
		$strButtonText="Save " . $strTable;
		
		$strMode="save";
		
	}
	else
	{
		$strButtonText="Create " . $strTable;
		$strMode="create";
	}
 	if ($strExtrajs=="closeclickrecycle")
	{
		$strExtrajs.="complete";
		
	}
 	$futurelabel="";
	$strFromMulti="";
	foreach ($descr as $nom=>$info)
		{
 				$strThisBgClass=Alternate($strClassFirst, $strClassSecond, $strThisBgClass);
				$strPickerLink="";
				$skip=false;
				$fieldlabel=$info["Field"];
				$name=$fieldlabel;
				
				$strDefault="";
				//$strType=$info["Type"];
				//echo $info["Type"] . "<br>";
				$strType=TypeParse($info["Type"], 0);
				$intLen=intval(TypeParse($info["Type"], 1));
				$length=$intLen;
				$bwlInvisible=false;
				$strPseudo="";
				//echo $strTable;
				$strMSQL="select * from " . $strDatabase . "." .  tfpre . "column_info WHERE table_name='" . $strTable . "' AND column_name='" . $name . "'"; 
				//echo $strMSQL. "<br>";
				$mrecords = $sql->query($strMSQL);
				//echo count($mrecords) . "<br>";
				if (count($mrecords)>0)
				{
					$mrecord=$mrecords[0];
					$fieldlabel=gracefuldecay($mrecord["label"], $fieldlabel);
					//echo $mrecord["invisible"]. " " . $mrecord["column_info_id"] . "<br>";
					if ($mrecord["invisible"]==1)
					{
						$bwlInvisible=true;
						 
					//echo "!" . "<br>";
					}
					if ($mrecord["data_from_multitable_relation"]==1)
					{
						 $strDefault="[multi-placeholder]";
						//echo $strFromMulti . "-";
					//echo "!" . "<br>";
					}
				}
				if (!$bwlInvisible)
				{
					$arrPseudo=RelationLookup($strDatabase, $strTable, $name, 3);
					//a pseudo-field is a "field" that is actually a formula in a field belonging to a parent table
					//it is found at this point only so it knows to display it after this field is displayed in another way
					if (count($arrPseudo)>0)
					{
						
						$strRTable=$arrPseudo[0];
						$strRField=$arrPseudo[1];
						$strIDFieldName = PKLookup($strDatabase, $strRTable);
						//in a pseudotable, what you get is a formula
						$strFormula=GenericDBLookup($strDatabase, $strRTable, $strIDFieldName, $arrRelationTemp[$strRTable], $strRField);
						if ($strFormula!="")
						{
							
							//a sample formula:
							//wordencode($strValDefault, 6, time());
							//echo  $strFormula;
							//echo $futureid . "*" .  $strValDefault;
							//$idtouse=gracefuldecay($futureid,  $strValDefault);
							$idtouse=$strValDefault;
							if ($idtouse>0)
							{
								$strThisBgClass=Alternate($strClassFirst, $strClassSecond, $strThisBgClass);
								$strFormula = str_replace("\$id", $idtouse, $strFormula);
								//echo $strFormula . "<br>";
								//echo wordencode(1, 6, 1);
								$strPseudoContent=   eval("return " .  $strFormula);
								//$strPseudoContent = wordencode($strValDefault, 6, time());
								//echo $futurelabel;
								$strPseudoLabel=gracefuldecay($futurelabel, $strTable) . " " . $strRField;
								
								$strPseudo.="<tr class=\"" .  $strThisBgClass . "\">\n";
								$strPseudo.="<td valign=\"top\">\n";
								$strPseudo.=$strPseudoLabel . "\n";
								$strPseudo.="</td>\n";
								$strPseudo.="<td class=\"heading\">\n";
								$strPseudo.=$strPseudoContent; 
								$strPseudo.="</td>\n";
								$strPseudo.="</tr>\n";
								$strThisBgClass=Alternate($strClassFirst, $strClassSecond, $strThisBgClass);
							}
						}
					
					}
					if (is_array($record))
					{
						//echo $record[0];
						//echo "!" . $info["Field"];
						$strDefault=$record[$info["Field"]];
						
						$strDefault=substr($strDefault, 0, strlen($strDefault));
						
						//i have a real problem with single quotes!!!
						$strDefault=deendquote($strDefault);
					
					}
					
					if ($strDefault=="")
					{
						if (array_key_exists($name, $_GET))
						{
							//echo "#" . $name . " " . $_GET[$name];
							$strDefault=$_GET[$name];
						}
					}
					$bwlHypLabel=false;
					
	
					
					if ($strType=="int")
					{
						$length=5;
						//echo $info["Key"];
	
						
						$arrMK=RelationLookup($strDatabase, $strTable, $name, 1);
						if (count($arrMK)>0)
						{
							$bwlHypLabel=true;
							//if we are dealing with a multi-table lookup, then things get really weird at that point.  
							//suddenly the row we're looking at becomes just the husk for a field in a totally different table
							//but first we need to know what that table is and what field it is.  we don't find that table directly;
							//we have to look it up using the arrFK we just retrieved
							//right all we now is that the primary key for that field in that other table is the integer in this field
							//and that the table and field containing the name of the distant table was just retrieved.
							
							//first:  that table
							$strRTable=$arrMK[0];
							$strRField=$arrMK[1];
							
							//get the primary key of the $strRTable that applies to this specific row
							//it actually will have probably been determined earlier (to put one of the dropdowns in the right spot)
							//at this point i assume that the pk of $strRTable is what we need
							$strIDFieldName = PKLookup($strDatabase, $strRTable);
							$strDistantTable=GenericDBLookup($strDatabase, $strRTable, $strIDFieldName, $arrRelationTemp[$strRTable], $strRField);
							$intDistantPK = PKLookup($strDatabase, $strDistantTable);
							$intNestTable++;
							$strNest.="|" . $intNestTable;
							//just for shits im gonna get all recursive right now...
							//$out.= TableForm($strDatabase,$strDistantTable,$intDistantPK,  $strDefault, $strPHP,  "noheader noextra noform", "zzz|" . $intNestTable / . "|");
							//ok i chickened out
							$skip=true;
							$fieldlabel=$strDistantTable;
							//if i have a multi-table relation, chances are i'll want to use the name of the wild table and its pk somewhere later in the tool.
							$futurelabel=$strDistantTable;
							$futureid=$strDefault;
							//$fieldform=foreigntablepulldown($strDatabase,$strDistantTable, $intDistantPK, $strDefault, $strFieldNamePrefix .$name, $strFromMulti, true);
							$fieldform=LookupName($strDatabase, $strDistantTable, $intDistantPK, $strDefault);
							$strFieldLabelLink=qbuild($strPHP, $strDatabase, $strDistantTable, "edit", $intDistantPK, $strDefault). "&" . qpre . "extrajs=closeclickrecycle";
						}
						$arrFK=RelationLookup($strDatabase, $strTable, $name,0);
						//echo $arrFK[0] . " " . $arrFK[1] . " " .  $name .  "<br>";
						if (count($arrFK)>0)
						{
							$bwlHypLabel=true;
								//i capture this info in case i need it later for a MultiTable lookup
						 		$arrRelationTemp[$arrFK[0]]=$strDefault;
								$skip=true;
								//echo $strDefault;
								$count = countrecords($strDatabase,$arrFK[0]);
								//if $count <101 do a dropdown for a foreign key.  otherwise slap down a link to a searchable picker
								//because i'm all cool like that
				 
								if ($count<101)
								{
									$fieldlabel=ReturnNonIDPartOfName($fieldlabel);
									$fieldform=LookupName($strDatabase, $arrFK[0], $arrFK[1], $strDefault);
									//$fieldform=foreigntablepulldown($strDatabase,$arrFK[0], $arrFK[1], $strDefault, $strFieldNamePrefix .$name);
							 
								}
								else
								{
									$skip=false;
									$length =5;
									//$strPrettyLabelField=firstnonidcolumname($strDatabase, $arrFK[0]);
									$strPickerLabel=LabelForID($strDatabase, $arrFK[0], $arrFK[1], $strDefault);
									$strPickerLink= "<input style=\"font-size:9px; border:0px;\" class=\"" . $strThisBgClass . "\" type=\"text\" name=\"" . $strFieldNamePrefix .  qpre . "a|" .  $name . "\" size=\"20\" value=\"" . deescape($strPickerLabel)  . "\">\n";
									$strPickerLink.=" [<a href=\"#\" onclick=\"pickerwindow('". $strDatabase . "','" . $arrFK[0] . "','".  $strFieldNamePrefix . $name ."')\">browse</a>]\n";
									
								}
								//$fieldlabel=$info["foreign"]; //for foreign keys with dropdowns, label them with table name
								//add a link to an editor for the foreign key label because i'm all cool like that
								
								$strFieldLabelLink= qbuild($strPHP, $strDatabase, $arrFK[0], "edit", $arrFK[1], $strDefault) . "&" . qpre . "extrajs=closeclickrecycle";

						}
						if ($bwlHypLabel==true)
						{
							if (!contains($strExtrajs,"complete"))
							{
								$fieldlabel="<a target=\"secondarytool\" href=\"". $strFieldLabelLink . "\">" . $fieldlabel . "</a>\n";
							}
							else
							{
								$fieldlabel="<a onclick=\"javascript:return(popdetachedwindow('" . $strFieldLabelLink . "','300','500'))\">" . $fieldlabel . "</a>\n";
							}
						}
					}


				elseif  ($strType=="tinyint" || $strType=="bit" )
				{
					$skip=true;
					$fieldform=boolcheck($strFieldNamePrefix . $name, $strDefault, "", true);
				}
				else 
				{
					$length=intval($length * ($intDefaultWide/90));
				}
				//($v["Extra"]=="auto_increment")
				if ($info["Extra"]!="auto_increment"  && !$skip)
				//if ($info["Key"]=="PRI" && !$skip)
				{
					$strFormType="text";
					
					if ($name=="password")
					{
						$fieldform=passworddisplay($strDefault);
					}
		 
					else
					{
						$fieldform="";
						$strAboveForm="";
						$strValString=forinputform($strDefault)  ;
						//i determine whether or not we make this form item an upload based entirely on its field name, not its type,
						//as in, does the field name contain either the string "filename" or "banner" 
						//(alter the NeedsUpload function to change this behavior)
						if (NeedsUpload($name))
						{	
							$path=fieldNameToFolderPath($strFieldNamePrefix . $name, imagepath) . $strDefault;
							$ahtml="";
							$slasha="";
							if (file_exists($path))
							{
								$ahtml="<a href=\"#\" onclick=\"popwindow('" . $path . "', '" . 200 . "', '" . 500 . "','picwindow'); \">";
								$slasha="</a>";
							}
							$fieldform=   PictureIfThere($path, "100") . "\n";
							$length=intval($length*.5);
				 
					 		$strAboveForm="&nbsp;&nbsp;&nbsp;" . $ahtml . $strDefault . $slasha . "<br>";
							$name=$strFieldNamePrefix . qpre . "u|" . $name;
							$strValString="";
						}
						$fieldform=$strAboveForm  . " " . deescape($strValString)   . $fieldform . $strPickerLink;
					}
				}
			
				elseif ($info["Extra"]=="auto_increment"  && $strValDefault=="")
				{
					$fieldform="&nbsp;&nbsp;&nbsp;<strong>autoincrement:</strong> \n";
				}
				elseif ($info["Extra"]=="auto_increment" && $strValDefault!="")
				{
					$fieldform="&nbsp;&nbsp;&nbsp;<strong>" .  $strValDefault. "</strong> \n";
				}
				
				$out.="<tr class=\"" .  $strThisBgClass . "\">\n";
				$out.="<td valign=\"top\">\n";
				$out.=$fieldlabel . "\n";
				$out.="</td>\n";
				$out.="<td>\n";
				$out.=$fieldform ; 
				$out.="</td>\n";
				$out.="</tr>\n";
				$out.=$strPseudo;
				if ($strPseudo!="")
				{
					$strThisBgClass=Alternate($strClassFirst, $strClassSecond, $strThisBgClass);
				}
			 
			}
	}
	$out.="<tr>\n<td colspan=2 align=\"right\">\n";
	$out.="</td>\n</tr>\n";
	$out.="</table>\n<p>";
	$out.="<a target=\"_new\" href=\"" . qbuild($strPHP, $strDatabase, $strTable, "edit", $strIDField, $strValDefault) . "\">Edit this " . $strTable . " and <em>its</em> Associated Items</a> starting in a new window.</a>";
	return $out;
}

//////////////////////////////////////////////
/////xml functions //////////////////////////
////////////////////////////////////////////

function XMLselect($strDatabase, $strTable, $strWhereClause, $bwlWrapTopLevel=true)
{
	//does a select call to the db and returns XML-wrapped data, naming entities using their names from the DB
	//cannot handle joins!
	$sql=conDB();
	$arrParameter=array();
	$out="";
	$arrFieldType=generateFieldTypeArray($strDatabase, $strTable);
	$strSQL="SELECT * FROM " . $strDatabase . "." . $strTable  ;
	if ( $strWhereClause!="")
	{
		$strSQL.=" WHERE " . $strWhereClause;
	}
	$rs = $sql->query($strSQL);

 	//echo count($rs);
	for($i=0; $i<count($rs); $i++)
	{
		$arrRS=$rs[$i];
		$out.=XMLDBitem($strTable, $arrRS, $arrFieldType);
	}
	if ($bwlWrapTopLevel)
	{
		$out=makeXMLNode(pluralize($strTable), "", $out) . "\n";
	}
	return $out;
}

function XMLDBitem($strTable, $arrRS, $arrFieldType, $strAdditionalSubContent="")
{
//returns a single XML-wrapped row of data, wrapping columns of type TEXT in their own sub-tags
//$arrRS is an associative array of the data from a single row 
//$arrFieldType is an associative array with the columns' names as keys and their types as values
	$strSubContent="";
	foreach ($arrRS as $key => $value )
	{
		
		$strpreparedcontent=doublequoteescape($value);
		if ($quotecontent)
		{
			$strpreparedcontent='"' . $strpreparedcontent . '"';
		}
		//echo $arrFieldType[$key] . "-<br>";
		if ($arrFieldType[$key]=="text")
		{
			 //$strSubContent.=makeXMLNode($key, "", "<![CDATA[" . $value . "]]>") . "\n";
			 $strSubContent.=makeXMLNode($key, "",  $value) . "\n";
		}
		else
		{
			$arrParameter[$key]=$strpreparedcontent;
		}
	}
	$strSubContent = $strSubContent . "\n" . $strAdditionalSubContent;
	$out=makeXMLNode($strTable, $arrParameter, $strSubContent) . "\n";
	return $out;
}

function makeXMLNode($name, $arrParameters, $content, $bwlSuppresCR=false)
{
	$out="<" . $name;
	if (is_array($arrParameters))
	{
		foreach($arrParameters as $k=>$v)
		{
			if ($v!="")
			{
				$out.=" " . $k . "=\"" . deescape(htmlcodify(fixAmp($v))) . "\"";
			}
		}
	}
	if ($content=="")
	{
		$out.="/>";
	}
	else
	{
		$out.=">";
		if (!$bwlSuppresCR)
		{
			$out.="\n";
		}
		if (!$bwlSuppresCR)
		{
			$out.="\t";
		}
		$out.= fixUnbalancedTags(deescape(fixAmp($content)));
		if (!$bwlSuppresCR)
		{
			$out.="\n";
		}
		$out.="</" . $name . ">";
		if (!$bwlSuppresCR)
		{
			$out.="\n";
		}
	}
	return $out;
}

function fixUnbalancedTags($strIn)
{
	$strIn=str_replace("<br>", "<br/>", $strIn);
	$strIn=str_replace("<BR>", "<br/>", $strIn);
	
	return $strIn;
}	

function fixAmp($strIn)
{
	$strIn=str_replace("& ", "&amp; ", $strIn);
 	//fix at
	$strIn=str_replace("@", "&#64;", $strIn);
	//$strIn=str_replace("&", "&amp;", $strIn);
	//$strIn=str_replace("\"", "&34;", $strIn);
	//$strIn=str_replace("'", "&39;", $strIn);
	//$strIn=str_replace("&34;", "&38;34;", $strIn);
	//$strIn=str_replace("&39;", "&38;39;", $strIn);
	return $strIn;
}	

function decode_entities($text) 
{
   $text= html_entity_decode($text,ENT_QUOTES,"ISO-8859-1"); #NOTE: UTF-8 does not work!
   $text= preg_replace('/&#(\d+);/me',"chr(\\1)",$text); #decimal notation
   $text= preg_replace('/&#x([a-f0-9]+);/mei',"chr(0x\\1)",$text);  #hex notation
   return $text;
}
 
function HexDump($strIn)
{
	$out="";
	for($i=0; $i<strlen($strIn); $i++)
	{
		$out.=ord(substr($strIn, $i, 1)) . " ";
	}
	return $out;
}

if (extrainclude!="extrainclude")
{
	$arrExtrainclude=explode("|",extrainclude);
	for($i=0; $i<count($arrExtrainclude);$i++)
	{
		include $arrExtrainclude[$i]; 
	}
}
include "test.php"; 
?>