<? 
//gus mueller, nov 26 2006
//tools for a tableform mysql db


function  GenerateDataSQL($strDatabase, $strTable)
{
	//creates a SQL-based dump of a table's data
	//federico frankenstein, jan 9 2007
	$sql=conDB();
	$out="";
	$strSQL="SELECT * FROM " . $strDatabase . "." .  $strTable;
	$records =  $sql->query($strSQL);
	$rowcount=0;
	$out.="\n";
	foreach($records as $record)
	{
		$out.="INSERT INTO " . $strDatabase . "." .  $strTable . " VALUES(";
 		$insertdata="";
		foreach($record as $field)
		{
			$insertdata.= "'" . $field . "',";
			$rowcount++;
		}
		$insertdata=RemoveEndCharactersIfMatch($insertdata, ",");
		$out.=$insertdata . ");\n";
	}
	$out.="\n";
	return $out;
}


function  GenerateStructureSQL($strDatabase, $strTable)
{
	//creates a SQL-based dump of a table's structure
	//federico frankenstein, jan 9 2007
	$sql=conDB();
	$out="";
	$strSQL="SHOW CREATE TABLE " . $strDatabase . "." .  $strTable;
	//echo $strSQL;
	$records =  $sql->query($strSQL);
	$record=$records[0];
	$out="\n\n" . $record["Create Table"] . ";\n\n";
	return $out;
}

function  BackupSQLSafe($strDatabase)
{
	//creates a SQL-based dump of a db's data and structure
	//this will work when mysqldump is failing
	//federico frankenstein, jan 9 2007
	$sql=conDB();
	$out="";
	$strSQL="\nSHOW TABLES FROM " .  $strDatabase ; 
	$strFieldName="Tables_in_" . str_replace("`", "", $strDatabase);
	$tables = $sql->query($strSQL);
	foreach ( $tables as  $k=>$v )
	{
		
		$tablename=$v[$strFieldName];
		$out.=GenerateStructureSQL($strDatabase, $tablename);
		$out.=GenerateDataSQL($strDatabase, $tablename);
	}
	return $out . "\n";
}

function backupDBtoSQL($strDatabase)
{
	//Creating a backup of MySQL DB using PHP.
	//All of the hard work is done using built-in MySQL utility called mysqldump.
	//Step 1 (backup): Create backup & D/L to local PC
	$host = con_server_web;
	$dbuser = con_user_web;
	$dbpword = con_pwd_web;
	$dbname = $strDatabase;
	$bwlSafeMethod=false;
	$len="";
	$backupFile = date("Y-m-d") . '.sql';
	# Use system functions: MySQLdump & GZIP to generate compressed backup file
	$command = "mysqldump -f -h$host -u$dbuser -p$dbpword $dbname > $backupFile";
	system($command);
	# Start the download process
	$errorlevel=error_reporting(0);
	$len = filesize($backupFile);
	if($len<1 )
	{
		$bwlSafeMethod=true;
		$out= BackupSQLSafe($strDatabase);
	}
	error_reporting($errorlevel);
	header("Pragma: public");
	header("Expires: 0");
	header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	header("Cache-Control: public"); 
	header("Content-Description: File Transfer");
	header("Content-Type: application/gzip");
	header("Content-Disposition: attachment; filename=$backupFile;");
	header("Content-Transfer-Encoding: binary");
	if ($len!="")
	{
		header("Content-Length: ".$len);
	}
	if ($bwlSafeMethod)
	{
		echo $out;
	}
	else
	{
		@readfile($backupFile);
		unlink($backupFile);
		# Delete the temporary backup file from server
	}
	
	
}


function downloadData($data, $mimetype, $name)
{
	$status = 0;
	if ($data != "") 
	{
		if(isset($_SERVER['HTTP_USER_AGENT']) && preg_match("/MSIE/", $_SERVER['HTTP_USER_AGENT']))
		{
		// IE Bug in download name workaround
			ini_set( 'zlib.output_compression','Off' );
		}
		header ('Content-type: ' . $mimetype);
		header ('Content-Disposition: attachment; filename="'.$name.'"');
		header ('Expires: '.gmdate("D, d M Y H:i:s", mktime(date("H")+2, date("i"), date("s"), date("m"), date("d"), date("Y"))).' GMT');
		header ('Accept-Ranges: bytes');
		// Use Cache-control: private not following:
		// header ('Cache-control: no-cache, must-revalidate');
		header('Cache-control: no-cache, must-revalidate');                 
		header ('Pragma: private');
		$size=strlen($data);
		if(isset($_SERVER['HTTP_RANGE'])) 
		{
			list($a, $range) = explode("=",$_SERVER['HTTP_RANGE']);
			//if yes, download missing part
			str_replace($range, "-", $range);
			$size2 = $size-1;
			$new_length = $size2-$range;
			header("HTTP/1.1 206 Partial Content");
			header("Content-Length: $new_length");
			header("Content-Range: bytes $range$size2/$size");
		}
		else
		{
			$size2=$size-1;
			header("Content-Range: bytes 0-$size2/$size");
			header("Content-Length: ".$size);
		}
		print $data;
	
	}
	return($status);
}
?>
