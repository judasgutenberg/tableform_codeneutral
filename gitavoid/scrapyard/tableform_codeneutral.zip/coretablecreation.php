<?
function MakeColumnInfoTables($strDatabase)
{
	$sql=conDB();
	$strSQL="
	CREATE TABLE " . $strDatabase . "." .  tfpre . "column_info (
	`column_info_id` int(4) NOT NULL auto_increment,
	`table_name` varchar(50) default NULL,
	`column_name` varchar(80) default NULL,
	`width` int(4) default NULL,
	`height` int(4) default NULL,
	`invisible` tinyint(3) default NULL,
	`data_from_multitable_relation` tinyint(3) default NULL,
	`label` varchar(50) default NULL,
	`help_text` text,
  	validation_type_id int(4) default NULL,
  	validation_pattern_id int(4) default NULL,
	fileupload tinyint default NULL,
	password tinyint default NULL,
  	browsetype_id int(4) default NULL,
	PRIMARY KEY  (`column_info_id`)
	);
	";
	$tables = $sql->query($strSQL);
	$out= mysql_error();
	
	$strSQL="
	CREATE TABLE " . $strDatabase . "." .  tfpre . "validation_pattern (
	  validation_pattern_id int(4) NOT NULL auto_increment,
	  name varchar(20) default NULL,
	  pattern varchar(255) default NULL,
	  PRIMARY KEY  (validation_pattern_id)
	);";
	$tables = $sql->query($strSQL);
	$out.= mysql_error();
	//a set of useful validation regular expressions
	//for some reason i need eight backslashes to end up with just one in the final javascript expression
	$strSQL="
	INSERT INTO " . $strDatabase . "." .  tfpre . "validation_pattern VALUES (1,'email','^.+@[^\\\\\\\\.].*\\\\\\\\.[a-z]{2,}$');
		";
	$tables = $sql->query($strSQL);
	$out= mysql_error();
	
	$strSQL="
	INSERT INTO " . $strDatabase . "." .  tfpre . "validation_pattern VALUES (2,'American phone','^(?:\\\\\\\\([2-9]\\\\\\\\d{2}\\\\\\\\)\\\\\\\\ ?|[2-9]\\\\\\\\d{2}(?:\\\\\\\\-?|\\\\\\\\ ?))[2-9]\\\\\\\\d{2}[- ]?\\\\\\\\d{4}$');
		";
	$tables = $sql->query($strSQL);
	$out= mysql_error();
	
	$strSQL="
	INSERT INTO " . $strDatabase . "." .  tfpre . "validation_pattern VALUES (3,'American postal code','^\\\\\\\\d{5}-\\\\\\\\d{4}|\\\\\\\\d{5}|[A-Z]\\\\\\\\d[A-Z] \\\\\\\\d[A-Z]\\\\\\\\d$');
		";
	$tables = $sql->query($strSQL);
	$out= mysql_error();
	
	$strSQL="
	INSERT INTO " . $strDatabase . "." .  tfpre . "validation_pattern VALUES (4,'five digit zipcode','^\\\\\\\\d{5}$');
		";
	$tables = $sql->query($strSQL);
	$out= mysql_error();
	
	$strSQL="
	INSERT INTO " . $strDatabase . "." .  tfpre . "validation_pattern VALUES (5,'zip+4 zipcode','^\\\\\\\\d{5}-\\\\\\\\d{4}$');
		";
	$tables = $sql->query($strSQL);
	$out= mysql_error();
	
	$strSQL="
	INSERT INTO " . $strDatabase . "." .  tfpre . "validation_pattern VALUES (6,'URL','^&#40;ht|f&#41;tp&#40;&#40;?<=http&#41;s&#41;?://&#40;&#40;?<=http://&#41;www|&#40;?<=https://&#41;www|&#40;?<=ftp://&#41;ftp&#41;\\\\\\\\.&#40;&#40;[a-z][0-9]&#41;|&#40;[0-9][a-z]&#41;|&#40;[a-z0-9][a-z0-9\\\\\\\\-]{1,2}[a-z0-9]&#41;|&#40;[a-z0-9][a-z0-9\\\\\\\\-]&#40;&#4');
		";
	$tables = $sql->query($strSQL);
	$out= mysql_error();
	 
	
	
	$strSQL="
	CREATE TABLE " . $strDatabase . "." .  tfpre . "validation_type (
	  validation_type_id int(4) NOT NULL auto_increment,
	  type_name varchar(45) default NULL,
	  PRIMARY KEY  (validation_type_id)
	);";
	$tables = $sql->query($strSQL);
	$out.= mysql_error();
	$strSQL="
	INSERT INTO " . $strDatabase . "." .  tfpre . "validation_type VALUES (1,'no validation');";
	$tables = $sql->query($strSQL);
	$out.= mysql_error();
	$strSQL="
	INSERT INTO " . $strDatabase . "." .  tfpre . "validation_type VALUES (2,'must fit pattern if field not empty');";
	$tables = $sql->query($strSQL);
	$out.= mysql_error();
	$strSQL="
	INSERT INTO " . $strDatabase . "." .  tfpre . "validation_type VALUES (3,'must always fit pattern');";
	$tables = $sql->query($strSQL);
	$out.= mysql_error();
	$strSQL="
	INSERT INTO " . $strDatabase . "." .  tfpre . "validation_type VALUES (4,'must never fit pattern');";
	$tables = $sql->query($strSQL);
	$out.= mysql_error();
	$strSQL="
	INSERT INTO " . $strDatabase . "." .  tfpre . "validation_type VALUES (5,'must never fit pattern if field not empty');";
	$tables = $sql->query($strSQL);
	$out.= mysql_error();
	
	$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (100,'" . tfpre . "column_info','validation_type_id','" . tfpre . "validation_type','validation_type_id',0);";
	$tables = $sql->query($strSQL);
	$out.= mysql_error();
	$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (101,'" . tfpre . "column_info','validation_pattern_id','" . tfpre . "validation_pattern','validation_pattern_id',0);";
	$tables = $sql->query($strSQL);
	$out.= mysql_error();
		
	return $out;
}
		
function MakeCalendarTables($strDatabase)
{
	$sql=conDB();
	$strSQL="
		CREATE TABLE " . $strDatabase . ".`calendar` (
		`calendar_id` int(4) NOT NULL auto_increment,
		`calendar_name` varchar(50) default NULL,
		`description` text,
		`foreign_table_name` varchar(30) default NULL,
		`calendar_range_id` int(4) default NULL,
		`code` varchar(80) default NULL,
		PRIMARY KEY  (`calendar_id`)
		) ;
		";
		$tables = $sql->query($strSQL);
		$out= mysql_error();
		$strSQL="
		CREATE TABLE " . $strDatabase . ".`calendar_event` (
		`calendar_event_id` int(4) NOT NULL auto_increment,
		`calendar_id` int(4) default NULL,
		`notes` text,
		`start` datetime default NULL,
		`end` datetime default NULL,
		`foreign_id` int(4) default NULL,
		`calendar_event_type_id` int(4) default NULL,
		`calendar_event_characteristic_id` int(4) default NULL,
		`event_name` varchar(60) default NULL,
		PRIMARY KEY  (`calendar_event_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="
		CREATE TABLE " . $strDatabase . ".`calendar_event_characteristic` (
		`calendar_event_characteristic_id` int(4) NOT NULL auto_increment,
		`name` varchar(40) default NULL,
		PRIMARY KEY  (`calendar_event_characteristic_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="
		CREATE TABLE " . $strDatabase . ".`calendar_event_type` (
		`calendar_event_type_id` int(4) NOT NULL auto_increment,
		`event_type_name` int(4) default NULL,
		PRIMARY KEY  (`calendar_event_type_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="
		CREATE TABLE " . $strDatabase . ".`calendar_range` (
		`calendar_range_id` int(4) NOT NULL auto_increment,
		`name` varchar(50) default NULL,
		`description` text,
		`size_in_seconds` int(4) default NULL,
		`size_php_code` varchar(1) default NULL,
		`granules` int(4) default NULL,
		`granule_php_code` varchar(1) default NULL,
		PRIMARY KEY  (`calendar_range_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="
		CREATE TABLE " . $strDatabase . ".`calendar_set` (
		`calendar_set_id` int(4) NOT NULL auto_increment,
		`name` varchar(50) default NULL,
		`range_in_seconds` int(4) default NULL,
		PRIMARY KEY  (`calendar_set_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="
		CREATE TABLE " . $strDatabase . ".`calendar_set_map` (
		`calendar_set_map_id` int(4) NOT NULL auto_increment,
		`calendar_set_id` int(4) default NULL,
		`calendar_id` int(4) default NULL,
		`map_order` int(4) default NULL,
		PRIMARY KEY  (`calendar_set_map_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (57,'calendar','calendar_range_id','calendar_range','calendar_range_id',0);";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (58,'calendar_event','calendar_id','calendar','calendar_id',0);";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (59,'calendar_event','calendar_event_type_id','calendar_event_type','calendar_event_type_id',0);";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (60,'calendar_event','calendar_event_characteristic_id','calendar_event_characteristic','calendar_event_characteristic_id',0);";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (61,'calendar_event','foreign_id','calendar','foreign_table_name',1);";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (63,'calendar_set_map','calendar_set_id','calendar_set','calendar_set_id',0);";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (64,'calendar_set_map','calendar_id','calendar','calendar_id',0);";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
	return $out;
}
	
	
	
function MakeStatsTables($strDatabase)
{
	$sql=conDB();
	$strSQL="
		CREATE TABLE " . $strDatabase . ".`website_hitday` (
		`website_hitday_id` int(4) NOT NULL auto_increment,
		`date` date default NULL,
		`count` int(4) default NULL,
		`page_id` int(4) default NULL,
		PRIMARY KEY  (`website_hitday_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out= mysql_error();
		$strSQL="
		CREATE TABLE " . $strDatabase . ".`website_hithour` (
		`website_hithour_id` int(4) NOT NULL auto_increment,
		`datetime` datetime default NULL,
		`count` int(4) default NULL,
		`page_id` int(4) default NULL,
		PRIMARY KEY  (`website_hithour_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="
		CREATE TABLE " . $strDatabase . ".`website_referal` (
		`website_referal_id` int(4) NOT NULL auto_increment,
		`referal_url` varchar(99) default NULL,
		`count` int(4) default NULL,
		`page_id` int(4) default NULL,
		`datetime_created` datetime default NULL,
		PRIMARY KEY  (`website_referal_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (52,'website_referal','page_id','page','page_id',0)";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (53,'website_hitday','page_id','page','page_id',0)";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (53,'website_hithour','page_id','page','page_id',0)";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
	return $out;
}
		
function MakeAdTables($strDatabase)
{
	$sql=conDB();
	$strSQL="
		CREATE TABLE " . $strDatabase . ".`ad` (
		`ad_id` int(4) NOT NULL auto_increment,
		`media_filename` varchar(88) default NULL,
		`ad_type` int(10) default NULL,
		`url` varchar(144) default NULL,
		`release_date` date default NULL,
		`expire_date` date default NULL,
		`hitcount` int(4) default NULL,
		PRIMARY KEY  (`ad_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out= mysql_error();
		$strSQL="
		CREATE TABLE " . $strDatabase . ".`ad_hit` (
		`ad_hit_id` int(4) NOT NULL auto_increment,
		`ad_id` int(4) default NULL,
		`referal_url` varchar(88) default NULL,
		`time` datetime default NULL,
		`hitcount` int(4) default NULL,
		PRIMARY KEY  (`ad_hit_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="
		CREATE TABLE " . $strDatabase . ".`ad_location` (
		`ad_location_id` int(4) NOT NULL auto_increment,
		`name` varchar(33) default NULL,
		PRIMARY KEY  (`ad_location_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="
		CREATE TABLE `ad_placement` (
		`ad_placement_id` int(4) NOT NULL auto_increment,
		`ad_id` int(4) default NULL,
		`ad_location_id` int(4) default NULL,
		PRIMARY KEY  (`ad_placement_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="
		CREATE TABLE " . $strDatabase . ".`ad_type` (
		`ad_type_id` int(4) NOT NULL auto_increment,
		`type_name` varchar(88) default NULL,
		`width` int(4) default NULL,
		`height` int(4) default NULL,
		PRIMARY KEY  (`ad_type_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (25,'ad_hit','ad_id','ad','ad_id',0);";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (26,'ad_placement','ad_id','ad','ad_id',0);";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (27,'ad_placement','ad_location_id','ad_location','ad_location_id',0);";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (28,'ad','ad_type','ad_type','ad_type_id',0);";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
	return $out;
}
	
function MakePageTable($strDatabase)
{
	$sql=conDB();
	$strSQL="
		CREATE TABLE " . $strDatabase . ".`page` (
		`page_id` int(4) NOT NULL auto_increment,
		`page_name` varchar(50) default NULL,
		`text` text,
		`querystring` varchar(200) default NULL,
		PRIMARY KEY  (`page_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out= mysql_error();
	return $out;
}

function MakeAdminTable($strDatabase)
{
	$sql=conDB();
	$strSQL="
		CREATE TABLE " . $strDatabase . "." .  tfpre . "admin (
		`admin_id` int(4) NOT NULL auto_increment,
		`username` varchar(44) default NULL,
		`password` varchar(44) default NULL,
		`is_superuser` tinyint(1) default NULL,
		`is_superadmin` tinyint(1) default NULL,
		`phone` varchar(44) default NULL,
		`email` varchar(30) default NULL,
		PRIMARY KEY  (`admin_id`)
		) 
		";
		$tables = $sql->query($strSQL);
		$out= mysql_error();
	return $out;
}


function MakePermissionTables($strDatabase)
{
	$sql=conDB();
	$strSQL="
		CREATE TABLE " . $strDatabase . "." .  tfpre . "permission (
		`permission_id` int(4) NOT NULL auto_increment,
		`table_name` varchar(40) default NULL,
		`admin_id` int(4) default NULL,
		`permission_type_id` int(4) default NULL,
		`id_range_lowend` int(4) default NULL,
		`id_range_highend` int(4) default NULL,
		PRIMARY KEY  (`permission_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out= mysql_error();
		$strSQL="
		CREATE TABLE " . $strDatabase . "." .  tfpre . "permission_type (
		`permission_type_id` int(4) NOT NULL auto_increment,
		`name` varchar(40) default NULL,
		PRIMARY KEY  (`permission_type_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (32,'" .  tfpre . "permission','admin_id','" .  tfpre . "admin','admin_id',0);";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (33,'" .  tfpre . "permission','permission_type_id','" .  tfpre . "permission_type','permission_type_id',0);";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (55,'" .  tfpre . "permission','admin_id','" .  tfpre . "admin','admin_id',0);";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "permission_type (`permission_type_id`,`name`) VALUES (1,'read');";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "permission_type (`permission_type_id`,`name`) VALUES (2,'read/write');";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
	return $out;
}

function MakeRelationTables($strDatabase)
{
	$sql=conDB();
	$strSQL="
		CREATE TABLE " . $strDatabase . "." .  tfpre . "relation (
		`relation_id` int(4) NOT NULL auto_increment,
		`table_name` varchar(44) default NULL,
		`column_name` varchar(44) default NULL,
		`f_table_name` varchar(44) default NULL,
		`f_column_name` varchar(44) default NULL,
		`relation_type_id` int(4) default NULL,
		PRIMARY KEY  (`relation_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out= mysql_error();
		$strSQL="
		CREATE TABLE " . $strDatabase . "." .  tfpre . "relation_type (
		  `relation_type_id` int(4) NOT NULL default '0',
		  `name` varchar(40) default NULL,
		  PRIMARY KEY  (`relation_type_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (62,'" .  tfpre . "relation','relation_type_id','" .  tfpre . "relation_type','relation_type_id',0);";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation_type (`relation_type_id`,`name`) VALUES (0,'foreign-key relation');";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation_type (`relation_type_id`,`name`) VALUES (1,'multi-table relation');";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO   " . $strDatabase . "." .  tfpre . "relation_type (`relation_type_id`,`name`) VALUES (2,'default relation');";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation_type (`relation_type_id`,`name`) VALUES (3,'pseudo-field relation');";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
	return $out;
}

function MakeBrowseSchemeTable($strDatabase)
{
	$sql=conDB();
	$strSQL="
		CREATE TABLE " . $strDatabase . "." .  tfpre . "browsescheme (
		`browsescheme_id` int(4) NOT NULL auto_increment,
		`table_name` varchar(50) default NULL,
		`browsetype_id` int(4) default NULL,
		`label_field` varchar(50) default NULL,
		`quantity_field_x` varchar(50) default NULL,
		`quantity_field_y` varchar(50) default NULL,
		`quantity_field_z` varchar(50) default NULL,
		`filter_field` varchar(50) default NULL,
		`graphic_field` varchar(50) default NULL,
		`toolpage` varchar(20) default NULL,
		`integration_label` varchar(30) default NULL,
		PRIMARY KEY  (`browsescheme_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out= mysql_error();
		$strSQL="
		CREATE TABLE " . $strDatabase . "." .  tfpre . "browsetype (
		`browsetype_id` int(4) NOT NULL auto_increment,
		`name` varchar(77) default NULL,
		PRIMARY KEY  (`browsetype_id`)
		);
		";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
		$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation VALUES (72,'" .  tfpre . "column_info','browsetype_id','browsetype','browsetype_id',0)";
		$tables = $sql->query($strSQL);
		$out.= mysql_error();
	return $out;
}

?>