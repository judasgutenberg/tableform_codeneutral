<? 
//gus mueller, nov 26 2006
//tools for a tableform mysql db

include('admin_functions.php');
include('backup_functions.php');
include('coretablecreation.php');

echo main();

function main()
	{
		$mode=$_REQUEST[qpre . "mode"];
		//for some reason single quotes are escaped when coming in off the $_REQUEST collection
		$actsql=deescape($_REQUEST[qpre . "actsql"]);
		$truncate=deescape($_REQUEST[qpre . "truncate"]);
		$strTable=$_REQUEST[qpre . "table"];
		$strDatabase=deMoronizeDB(gracefuldecay($_REQUEST[qpre . "db"],our_db));
		$strPHP=$_SERVER['PHP_SELF'];
		$feedbackspanstag="<span class=\"feedback\">";
		$out="";
		//echo $id . " " .$idfield ;
		if($mode!="backup")
		{
			$out=LoginDecisions($strDatabase,  $strPHP, $strUser, false);
		}
		else
		{
			//i have to do this to backup
			$strUser=WhoIsLoggedIn();
			if (IsSuperAdmin($strDatabase, $strUser))
			{
				backupDBtoSQL($strDatabase);
				die();
			}
		}
		if (IsSuperAdmin($strDatabase, $strUser))
		{
		
			$intAdminType= AdministerType($strDatabase, $strTable, $strUser);
			if ($deletefields!="")
			{
				//echo "##". $deletefields;
				deletefields($strDatabase, $strTable, $deletefields);
			}
			if ($intAdminType>1)
				{
				 	if ($mode=="drop")
					{
					
						$out.=  $feedbackspanstag .  dropTable($strDatabase, $strTable). "</span><br/>";
					}
			 
	 				if ($mode=="empty")
					{
					
						$out.=   $feedbackspanstag . emptyTable($strDatabase, $strTable) . "</span><br/>";
					}
					if ($mode=="create")
					{
						$out.=   $feedbackspanstag . createAuxillaryTable($strDatabase, $strTable) . "</span><br/>";
					}
					
					//handle the creation of auxillary tables
					if(is_array($_REQUEST[qpre . "auxtables"]))
					{
						//read each auxillary table package checkoff and add them to the database
						foreach($_REQUEST[qpre . "auxtables"] as $auxtable)
						{
							//echo $auxtable . "<br>";
							$out.=   $feedbackspanstag . createAuxillaryTable($strDatabase,$auxtable) . "</span><br/>";
						}
					}
					$messages="";
					if(is_array($_REQUEST[qpre . "acceptrelation"]))
					{
						//echo "$$";
						if(!TableExists($strDatabase, tfpre . "relation"))
						{
							MakeRelationTables($strDatabase);
						}
						$sql=conDB();
						//read each accepted relation from relation scanner and add it to the relation table
						foreach($_REQUEST[qpre . "acceptrelation"] as $accept)
						{
							//echo $accept . "<br>";
							$arrAccept=explode("|", $accept);
							$strSQL="SELECT table_name FROM " . $strDatabase . "." .  tfpre . "relation WHERE table_name='" . $arrAccept[0] . "' AND column_name='" . $arrAccept[1] . "' AND f_table_name='" . $arrAccept[2] . "' AND f_column_name='" . $arrAccept[3] . "' AND relation_type_id=0";
							$rs = $sql->query($strSQL);
							if (count($rs)<1)
							{
								$strSQL="INSERT INTO " . $strDatabase . "." .  tfpre . "relation (table_name, column_name, f_table_name, f_column_name,relation_type_id) VALUES ('" . $arrAccept[0] . "','" . $arrAccept[1] . "','" . $arrAccept[2] . "','" . $arrAccept[3] . "'," . "0);";

								//echo $strSQL . "<br>";
								//echo mysql_error();
								$tables = $sql->query($strSQL);
								$messages.=   $feedbackspanstag . "A relationship was created between the " . $arrAccept[1] . " column in " . $arrAccept[0] . " and the " . $arrAccept[3] . " column in " . $arrAccept[2] . "table.</span><br/>";
							}
						}
					
					}
					$out.= $messages;
					if ($mode=="entersql")
					{
					
						$out.= EnterSQL($strDatabase, $strPHP, $actsql);
					}
					else if ($mode=="fkscan")
					{
					
						$out.= FKscan($strDatabase, $strPHP);
					}
					else
					{
						$out.= AdminTableBrowser($strDatabase, $strPHP);
						$out.= "<p/>";
						$out.= AuxillaryTablePicker($strDatabase, $strPHP);
						
					}
					if ($actsql!="")
					{
						$out.= ActSQL($strDatabase, $strPHP, $actsql, $truncate);
					
					}
					$out.= "<p/>";
					$out.= OtherTools($strDatabase, $strPHP);
				}
		}
		else
		{
		
			$out.=  "You do not have permissions to see this content.";
		}
		$out =  PageHeader($strDatabase . " : DB Tools", $strExtrajs) . $out . PageFooter();
		
		return $out;
	}


	
	
	
	
function AdminTableBrowser($strDatabase, $strPHP)
//shows all the tables in $strDatabase and allows an admin to drop and clear all data
{
	$strClassFirst="bgclassfirst";
	$strClassSecond="bgclasssecond";
	$strOtherBgClass="bgclassother";
	$strLineClass="bgclassline";
	$strThisBgClass=$strClassFirst;
	$sql=conDB();
	//$tables = $sql->showtables(array("db" => $strDatabase)); 
	$strSQL="SHOW TABLES FROM " .  $strDatabase ; 
	//echo $strSQL;
	$tables = $sql->query($strSQL);
	$out= "<table border=\"0\" cellspacing=\"1\" cellpadding=\"2\" class=\"" .$strLineClass  . "\" width=\"500\">\n";
	$out.= "<tr class=\"" . $strOtherBgClass . "\"><td colspan=\"7\">\n";
	$out.= adminbreadcrumb(false,  $strDatabase,"tableform.php",  "DB Tools", "") ;
	$out.=LinkIfFile("tablemaker.php", qpre . "db=" . $strDatabase, "create new table", " [", "]") ;
	$out.=LinkIfFile("tableform.php", qpre . "db=" . $strDatabase, "back to editor", " [", "]") ;
	$out.= "</td></tr>\n";
	$out.=htmlrow("bgclassline", "table", "records", "&nbsp;", "&nbsp;", "&nbsp;" , "&nbsp;", "&nbsp;");
	$strFieldName="Tables_in_" . str_replace("`", "", $strDatabase);
	foreach ( $tables as  $k=>$v )
	{
		$tablename=$v[$strFieldName];
		$strThisBgClass=Alternate($strClassFirst, $strClassSecond, $strThisBgClass);
		$out.= "<tr  class=\"" . $strThisBgClass . "\">\n";
		$out.= "<td><a href=\"" . qbuild("tableform.php", $strDatabase, $tablename , "view", "", "") . "\">" . $tablename . "</a></td>\n";
		$count = countrecords($strDatabase , $tablename );
		$out.= "<td>" .  $count . "</td>\n";
		$out.= "<td>";
		$out.= "[<a href=\"" . qbuild("tablemaker.php", $strDatabase, $tablename , "", "", "") . "\">edit def.</a>]";
		$out.= "</td>\n";
		$out.= "<td>";
		$out.= "[<a onclick=\"return(tableconfirm('drop', '" .  $tablename . "'))\" href=\"" . qbuild($strPHP, $strDatabase, $tablename , "drop", "", "") . "\">drop</a>]";
		$out.= "</td>\n";
		$out.= "<td>";
		$out.= "[<a onclick=\"return(tableconfirm('empty', '" .  $tablename . "'))\" href=\"" . qbuild($strPHP, $strDatabase, $tablename , "empty", "", "") . "\">empty</a>]";
		$out.= "</td>\n";
		$out.= "<td>";
		$out.= "[<a target=\"_new\" href=\"" . qbuild("tablexml.php", $strDatabase, $tablename , "view", "", "") . "\">view as XML</a>]";
		$out.= "</td>\n";
		$out.= "<td>[<a href=\"" . qbuild("dump.php", $strDatabase, $tablename , "", "", "") . "\">export</a>]</td>\n";
		$out.= "</tr>\n";
	}
	 $out.="</table>"; 
	return $out;
}

	
function AuxillaryTablePicker($strDatabase, $strPHP)
//allows an admin to pick and pre-build certain important tables in a tableform mysql db.
{
	$strClassFirst="bgclassfirst";
	$strClassSecond="bgclasssecond";
	$strOtherBgClass="bgclassother";
	$strLineClass="bgclassline";
	$strThisBgClass=$strClassFirst;
	$strConfig="admin|Allows the creation of user rights and superusers.-relation|Allows crosstable browsing and editing.-permission|Allows users to be given specific tables to control.-column_info|Allows column help, aliasing, and hiding.-browsescheme|Allows special and customizable views/editors of data.-page|A prerequisite for stats and ad.-calendar|A parallel calendaring system.-stats|A web stats system.-ad|An advertisement placement and logging system.";
	$arrConfig=explode("-", $strConfig);
	$out= "<form method=\"post\" name=\"BForm\" action=\"" .  $strPHP . "\">\n";
	$out.= "<table border=\"0\" cellspacing=\"1\" cellpadding=\"2\" class=\"" .$strLineClass  . "\" width=\"500\">\n";
	$out.="<tr>\n";
	$out.="<td colspan=\"3\">\n";
	$out.="<span class=\"heading\">Add a Table Package</span>";
	$out.="</td>\n";
	$out.="</tr>\n";
	$out.=htmlrow($strLineClass, "table system", "info", "add");
	for($i=0; $i<count($arrConfig); $i++)
	{
		$arrThisTable=explode("|", $arrConfig[$i]);
		$strThisTable=$arrThisTable[0];
		$strAbout=$arrThisTable[1];
		$strThisBgClass=Alternate($strClassFirst, $strClassSecond, $strThisBgClass);
		$strTableToLookup=$strThisTable;
		$bwlChecked=false;
		if ($strThisTable=="stats")
		{
			$strTableToLookup="website_hithour";
		}
		else if  (!inList("ad calendar page", $strThisTable))
		{
			$strTableToLookup=tfpre . $strThisTable;
		
		}
		if (TableExists($strDatabase, $strTableToLookup))
		{
			$bwlChecked=true;
		}
		$out.=htmlrow($strThisBgClass, $strThisTable, $strAbout, CheckboxInput(qpre . "auxtables[]", $strThisTable, $bwlChecked, "", "", ""));
	} 
	$out.="<tr>\n";
	$out.="<td colspan=\"2\">\n";
	$out.="Clicking 'Add' will add the checked table packages to the database.\n<br>\n";
	$out.="<a href=\"javascript:alldumpcheckboxes('auxtables[]', true)\">select all</a> | <a href=\"javascript:alldumpcheckboxes('auxtables[]', false)\">select none</a>";
	$out.="</td>\n";
	$out.="<td>\n";
	$out.="<input type=\"Submit\" class=\"btn\" onmouseover=\"this.className='btn btnhov'\" onmouseout=\"this.className='btn'\" value=\"Add\">";
	$out.="</td>\n";
	$out.="</tr>\n";
	$out.="</table>";
	$out.="</form>";
	return $out;
}
	
function dropTable($strDatabase, $strTable)
{
//removes a table completely from the db
	$sql=conDB();
	$strSQL= "DROP TABLE " . $strDatabase . "." . $strTable;
	$tables = $sql->query($strSQL);
	$out =  $strTable . " has been dropped.";
	return $out;
}

function emptyTable($strDatabase, $strTable)
{
//clears all data from a table
	$sql=conDB();
	$strSQL= "TRUNCATE TABLE " . $strDatabase . "." . $strTable;
	$tables = $sql->query($strSQL);
	$out =  "All data in " . $strTable . " has been removed.";
	return $out;
}


function createAuxillaryTable($strDatabase, $strTable)
{
//pre-build certain important tables in a tableform mysql db.
//lots of embedded sql here!
	//creates the calendar set
	if ($strTable=="calendar")
	{
		$error=MakeCalendarTables($strDatabase);
	}
	if ($strTable== "admin")
	{
		$error=MakeAdminTable($strDatabase);

	}
	if ($strTable=="relation")
	{
		$error=MakeRelationTables($strDatabase);
	}
	if ($strTable=="column_info")
	{
		$error=MakeColumnInfoTables($strDatabase);
	}
	if ($strTable=="permission")
	{
		$error=MakePermissionTables($strDatabase);
	}
	if ($strTable=="browsescheme")
	{
		$error=MakeBrowseSchemeTable($strDatabase);
	}
	if ($strTable=="page")
	{
		$error=MakePageTable($strDatabase);
	}
	if ($strTable=="stats")
	{
 		$error=MakeStatsTables($strDatabase);
	}
	if ($strTable=="ad")
	{
		$error=MakeAdTables($strDatabase);
	}
	//echo $error;
	return "The auxillary tables set named " . $strTable . " was created.";

}

function FKscan($strDatabase, $strPHP)
{
	//inside a particular database, scan through all the field names and propose possible relations based on them
	$out="";
	$strLineClass="bgclassline";
	$strClassFirst="bgclassfirst";
	$strClassSecond="bgclasssecond";
	$strOtherBgClass="bgclassother";
	$strOtherLineClass="bgclassline";
	$strThisBgClass=$strClassFirst;
	$strIntList="int bigint smallint mediumint";
	$sql=conDB();
	$strSQL="SHOW TABLES FROM " .  $strDatabase ; 
	$tables = $sql->query($strSQL);
	$out= "<form method=\"post\" name=\"BForm\" action=\"" .  $strPHP . "\">\n";
	$out.= HiddenInputs(array("mode"=>"fkscan"));
	$out.= "<table border=\"0\" cellspacing=\"1\" cellpadding=\"2\" class=\"" .$strLineClass  . "\" width=\"450\">\n";
	$out.= "<tr class=\"" . $strOtherBgClass . "\"><td colspan=\"6\">\n";
	$out.= adminbreadcrumb(false,  $strDatabase, "tableform.php",  "DB Tools", $strPHP, "Relation Scan", "") ;
	$out.= "</td></tr>\n";
	$out.=htmlrow("bgclassline", "table", "column", "foreign table", "foreign PK", "accept");
	//echo "-" . count($tables) . "-" ;
	$strFieldName="Tables_in_" . str_replace("`", "", $strDatabase);
	foreach ($tables as  $k=>$v)
	{
		$ReferenceTable=$v[$strFieldName];
		$strSQL="EXPLAIN " . $strDatabase . "." . $ReferenceTable;
		$descr = $sql->query($strSQL);
		foreach ($descr as $nom=>$info)
		{
			$strReferenceFieldName=$info["Field"];
			$strReferenceType=TypeParse($info["Type"], 0);
			
			if (inList($strIntList,$strReferenceType))
			{
				$strSQL="SHOW TABLES FROM " .  $strDatabase ; 
				$fktables = $sql->query($strSQL);
				foreach ($fktables as  $fkk=>$fkv)
				{
					$FKTable=$fkv[$strFieldName];
					//echo $ReferenceTable . " " . $FKTable . "<br>";
					if ($ReferenceTable!= $FKTable)
					{
						$strSQL="EXPLAIN " . $strDatabase . "." . $FKTable;
						$fkdescr = $sql->query($strSQL);
						foreach ($fkdescr as $fknom=>$fkinfo)
						{
							if ($fkinfo["Key"]=="PRI")
							{
								$strPKFieldName=$fkinfo["Field"];
								$strPKType=TypeParse($fkinfo["Type"], 0);
								if (inList($strIntList,$strPKType) &&  $strReferenceFieldName==$strPKFieldName )
								{
									$strThisBgClass=Alternate($strClassFirst, $strClassSecond, $strThisBgClass);
									$bwlChecked=false;
									$strSQL="SELECT table_name FROM " . $strDatabase . "." .  tfpre . "relation WHERE table_name='" . $ReferenceTable . "' AND column_name='" .  $strReferenceFieldName . "' AND f_table_name='" .  $FKTable . "' AND f_column_name='" . $strPKFieldName . "' AND relation_type_id=0";
									//echo $strSQL . "<br>";
									$rstest = $sql->query($strSQL);
									if (count($rstest)>0)
									{
										$bwlChecked=true;
									}
									
									$strValueString=$ReferenceTable  . "|" . $strReferenceFieldName . "|" . $FKTable . "|".  $strPKFieldName;
									$strCB=CheckboxInput(qpre . "acceptrelation[]", $strValueString, $bwlChecked, "", "", "");
									$out.=htmlrow($strThisBgClass, $ReferenceTable, $strReferenceFieldName, $FKTable, $strPKFieldName , $strCB);
								}
							}
						}
					}
				}
			}
		}
	}
	$out.="<tr>\n";
	$out.="<td colspan=\"4\">\n";
	$out.="Clicking 'Accept' will add the checked relations to the <strong>relation</strong> table.\n";
	$out.="<br><a href=\"javascript:alldumpcheckboxes('acceptrelation[]', true)\">select all</a> | <a href=\"javascript:alldumpcheckboxes('acceptrelation[]', false)\">select none</a>";
	$out.="</td>\n";
	$out.="<td>\n";
	$out.="<input type=\"Submit\" class=\"btn\" onmouseover=\"this.className='btn btnhov'\" onmouseout=\"this.className='btn'\" value=\"Accept\">";
	$out.="</td>\n";
	$out.="</tr>\n";
	$out.="</table>";
	$out.="</form>";
	return $out;
}


function EnterSQL($strDatabase, $strPHP, $strSQL)
{
	//a form for entering free-form SQL.  defaults to last command run
	//gus mueller, nov 26 2006
	$strClassFirst="bgclassfirst";
	$strLineClass="bgclassline";
	$strOtherBgClass="bgclassother";
	$out= "<form method=\"post\" name=\"BForm\" action=\"" .  $strPHP . "\">\n";
	$out.= "<table border=\"0\" cellspacing=\"1\" cellpadding=\"2\" class=\"" .$strLineClass  . "\"  >\n";
	$out.= "<tr class=\"" . $strOtherBgClass . "\"><td >\n";
	$out.= adminbreadcrumb(false,  $strDatabase, "tableform.php",  "DB Tools", $strPHP, "Enter Raw SQL", "") ;
	$out.= "</td></tr>\n";
	$out.= HiddenInputs(array("mode"=>"entersql"));
	$out.="<tr>\n";
	$out.="<td class=\"" . $strClassFirst . "\">\n";
	$out.="<textarea name=\"" . qpre . "actsql\" cols=\"80\" rows=\"20\"  >" .  $strSQL . "</textarea>\n";
	$out.="</td>\n";
	$out.="</tr>\n";
	$out.="<tr>\n";
	$out.="<td align=\"right\">\n";
 	$out.=CheckboxInput(qpre . "truncate", "1", "true", "", "", "") . "truncate fields";
	$out.="<input type=\"Submit\" class=\"btn\" onmouseover=\"this.className='btn btnhov'\" onmouseout=\"this.className='btn'\" value=\"Execute\">";
	$out.="</td>\n";
	$out.="</tr>\n";
	$out.="</table>";
	$out.="</form>";
	return $out;
}

function ParseStringToArraySkippingQuotedRegions($strIn, $quote="'", $delimiter=";", $escapecharacter="\\") 
{
//federico frankenstein Jan 4 2007
//go through, say, SQL and find the commands and put them in an array
//carefully overlooking semicolons inside quotes
	$newString = "";
	$inQuotes = false;
	$arrOut=Array();
	$intLastDelimiterPos=0;
	$outCount=0;
	$strLen=strlen($strIn);
   	for($i = 0; $i < strlen($strIn)+1; $i++) 
	{
        if(substr($strIn,$i,strlen($quote)) == $quote  &&  substr($strIn,$i-1,strlen($escapecharacter)) != $escapecharacter) 
		{
			$inQuotes =!$inQuotes;
		}
		if(!$inQuotes)
		{ 
			if(substr($strIn,$i,strlen($delimiter)) == $delimiter  || $i==$strLen)
			{
				$strThisCommand=RemoveEndCharactersIfMatch(substr($strIn, $intLastDelimiterPos, ($i-$intLastDelimiterPos)), $delimiter);
				$intLastDelimiterPos=$i;
				$arrOut[$outCount]=$strThisCommand;
				$outCount++;
			}
		}
	}
 	return $arrOut;
}

//$arr= ParseSQLToCommandArray("a;b;c;'d;e';f;ghi\\'poo;p\';bleh");
//for ($i=0; $i<count($arr); $i++)
//{
	//echo $arr[$i] . "<br>";

//}


function  ActSQL($strDatabase, $strPHP, $strSQL, $truncate)
{
	//runs $strSQL and displays results in a labeled HTML table
	//also shows errors if there is a problem
	//gus mueller, nov 26 2006
	$sql=conDB();
	mysql_select_db($strDatabase);
	$strLineClass="bgclassline";
	$strClassFirst="bgclassfirst";
	$strClassSecond="bgclasssecond";
	$strOtherBgClass="bgclassother";
	$strOtherLineClass="bgclassline";
	$strThisBgClass=$strLineClass;
	//echo $strSQL;
	$arrSQL =ParseStringToArraySkippingQuotedRegions($strSQL);
	$out="";
	for($i=0; $i<count($arrSQL); $i++) 
	{
		$strSQL=$arrSQL[$i];
		if ($strSQL!="")
		{
			$rows =  $sql->query($strSQL);
			$rowcount=0;
			$strErrors=mysql_error();
			if ($strErrors=="")
			{
				$out.= "<table border=\"0\" cellspacing=\"1\" cellpadding=\"2\" class=\"" .$strLineClass  . "\"  >\n";
				$out.="<span class=\"heading\">Results of Query #" . intval($i+1) . "</span>";
				$out.= "</td></tr>\n";
				foreach ($rows as $record )
				{
					$out.= "<tr class=\"" . $strThisBgClass . "\">\n";
					if($rowcount==0)
						{
							foreach($record as $k=>$v)
							{
								$out.="<td valign=\"top\">";
								$out.=$k ;
								$out.="</td>";
							}
							$out.="</tr>\n";
							$strThisBgClass=Alternate($strClassFirst, $strClassSecond, $strThisBgClass);
							$out.= "<tr class=\"" . $strThisBgClass . "\">\n";
						}
					
					foreach($record as $k=>$v)
					{
						$out.="<td valign=\"top\">";
						if ($truncate==1)
						{
							$out.=simplelinkbody($v);
						}
						else
						{
							$out.=str_replace(chr(10), chr(10) . "<br/>" , $v);
						}
						$out.="</td>";
						$rowcount++;
					}
					$out.="</tr>\n";
					$strThisBgClass=Alternate($strClassFirst, $strClassSecond, $strThisBgClass);
				}
				$out.="</table>";
			}
			else
			{
				$out.= "<p><table border=\"0\" cellspacing=\"1\" cellpadding=\"2\" class=\"" .$strLineClass  . "\"  >\n";
				$out.= "<tr>\n";
				$out.="<td valign=\"top\" class=\"" .$strLineClass  . "\" >";
				$out.="<span class=\"heading\">Errors:</span>";
				$out.= "</td></tr>\n";
				$out.= "<tr class=\"" . $strClassFirst . "\">\n";
				$out.="<td valign=\"top\"  >";
				$out.=$strErrors;
				$out.= "</td></tr>\n";
				$out.="</table></p>";
			}
		}
	}
	return $out;
}

function OtherTools($strDatabase, $strPHP)
{
	$out="";
	$out.="<span class=\"heading\">Other Tools</span><br/>\n";
	$out.="<a href=\"" . $strPHP . "?" . qpre . "mode=fkscan\"> Scan database for possible relations based on field names.</a><br/>\n";
	$out.="<a href=\"" . $strPHP . "?" . qpre . "mode=backup\"> Backup database to a SQL file.</a><br/>\n";
	$out.="<a href=\"" . $strPHP . "?" . qpre . "mode=entersql\"> Type in raw SQL commands.</a><br/>\n";
	return $out;
}
?>

