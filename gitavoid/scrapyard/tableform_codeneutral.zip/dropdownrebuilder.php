<? 
//Gus Mueller January 2006
//provides a web front end admin tool for any mysql db
//i've modified txtsql to be aware of foreign keys so this tool can dynamically build complicated tools

include('admin_functions.php');

echo main();

function main()
	{
		$sql=conDB();
		$strBackfielddata=$_REQUEST[qpre . "backfielddata"];
		//echo  $strBackfielddata;
		//$strDatabase . "|" . $strTable . "|" . $idfield . "|" . $strBackfield . "|" . $strNameField . "|" . $strNameField2;
		$arrBFD=explode("|", $strBackfielddata);
		$strDatabase=deMoronizeDB(gracefuldecay($arrBFD[0],our_db));
		$strTable=$arrBFD[1];
		$idfield=$arrBFD[2];
		$strBackfield=$arrBFD[3];
		$strNameField=$arrBFD[4];
		$strNameField2=$arrBFD[5];
		$thisID=$arrBFD[6];
		$fieldDelimiter="=";
		$rowDelimiter="~";
		$strDelimiters=$fieldDelimiter . " " . $rowDelimiter;
		$out="<html><body>";
		$out.="<form name=\"BForm\" method=\"post\">\n";
		$strSQL="SELECT  * FROM " . $strDatabase . "." . $strTable . " ORDER BY "  . $strNameField . "," . $strNameField2 . " LIMIT 0,50";
		 //echo $strSQL;
		$records = $sql->query($strSQL);
		foreach ($records as $record )
		{
			//echo "#";
			$fields.=  $record[$idfield].  $fieldDelimiter .  KillDelimiters($record[$strNameField], $strDelimiters) . $fieldDelimiter . KillDelimiters($record[$strNameField2], $strDelimiters)  . $rowDelimiter;
	 	}
		$fields=RemoveEndCharactersIfMatch($fields,$rowDelimiter);
		//$out.="<input type=\"hidden\" name=\"fields\" value=\"" . $fields . "\">\n";
		//$out.="</form>";
		//ookay, once we've loaded the fields into that hidden field, time to build a dropdown in the launcher window
		$out.="<script>\n";
		$out.="ourfields='" . $fields . "'\n";
		$out.="arrFields=ourfields.split('" . $rowDelimiter . "');\n";
		//$out.="alert(parent.document.BForm." . $strFieldFormName . ".type)\n";
		$out.="ourreturnfield='" . $strBackfield . "'\n";
		$out.="ourreturnid='" . $thisID . "'\n";
		$out.="parent.document.BForm[ourreturnfield].length=0\n";
		$out.="if(parent.document.BForm[ourreturnfield].type=='text')\n";
		$out.="{\n";
		$out.="		parent.document.BForm[ourreturnfield].type='select';\n";
		$out.="}\n";
		$out.="for(j=0; j<arrFields.length; j++)\n";
		$out.="{\n";
		$out.="		thisreturnrow=arrFields[j]\n";
		$out.="		arrThisData=thisreturnrow.split('" . $fieldDelimiter . "');\n";
		$out.="		thisid=arrThisData[0]\n";
		$out.="		thisname=arrThisData[1]\n";
		$out.="		thisname2=arrThisData[2]\n";
		$out.="		if(!parent.document.BForm[ourreturnfield][j])\n";
		$out.="		{\n";
		$out.="			parent.document.BForm[ourreturnfield].length++;\n";
		$out.="		}\n";
		$out.="		parent.document.BForm[ourreturnfield][j].text=thisname + ' : ' + thisname2;\n";
		$out.="		parent.document.BForm[ourreturnfield][j].value=thisid;\n";
		$out.="		if(ourreturnid==thisid)\n";
		$out.="		{\n";
		$out.="			parent.document.BForm[ourreturnfield][j].selected=true;\n";
		//$out.="			parent.document.BForm[ourreturnfield][j].text+='#';\n";
		$out.="		}\n";
		$out.="		else \n";
		$out.="		{\n";
		$out.="			parent.document.BForm[ourreturnfield][j].selected='';\n";
		$out.="		}\n";
		$out.="}\n";
		$out.="</script>\n";
		$out.="</body></html>\n";
		return $out;
	}

	
function KillDelimiters($strIn, $strDelimiters)
{
	$out=$strIn;
	$arrDelimiters=explode(" ", $strDelimiters);
	foreach($arrDelimiters as $a)
	{
		$out=str_replace($a, "", $out);
	}
	return $out;
}
?>