<script>
window.close();

</script>