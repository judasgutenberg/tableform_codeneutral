<?php 
//Federico Frankenstein February 2007////////////////
//questionnaire functions 

function RenderQuestions($strPHP, $strDatabase, $intQuestionnaire_id, $intUserID)
{
//renders a questions for a questionnaire 
	$sql=conDB();
	$out="";
	$intOut=0;
	$intDefaultWidth=30;
	$strSQL="SELECT * FROM " . $strDatabase . ".questionnaire WHERE questionnaire_id=" . $intQuestionnaire_id;
	$records = $sql->query($strSQL);
	$record=$records[0];
	$accept_multiple=$record["accept_multiple"];
	$strSQL="SELECT  q.questionnaire_question_id, q.*, p.pattern, a.answer, a.user_id FROM " . $strDatabase . ".questionnaire_question q LEFT JOIN " . $strDatabase . "." . tfpre . "validation_pattern p on q.validation_pattern_id=p.validation_pattern_id LEFT JOIN " . $strDatabase . ".questionnaire_answer a ON q.questionnaire_question_id=a.questionnaire_question_id  WHERE q.questionnaire_id=" .$intQuestionnaire_id . " ORDER BY sort_order, q.questionnaire_question_id AND a.user_id=" . $intUserID . " ASC";
	//echo $strSQL;
	$records = $sql->query($strSQL);
	$out= "<form method=\"post\" name=\"BForm\" action=\"" .  $strPHP . "\">\n";
	$out.= "<table border=\"0\" cellspacing=\"1\" cellpadding=\"2\" class=\"" .$strLineClass  . "\" width=\"500\">\n";
	foreach($records as $record)
	{
	
		//get data about this particular question
		$strDefault=$record["answer"];
		
		$questionnaire_question_id=$record["questionnaire_question_id"];
		$strQVarName=qpre . "answer-" . $questionnaire_question_id;
		$question=$record["question"];
		$sort_order=$record["sort_order"];
		$questionnaire_id=$record["questionnaire_id"];
		$answer_tally=$record["answer_tally"];
		$suggested_table_name=$record["suggested_table_name"];
		$validation_type_id=$record["validation_type_id"];
		$validation_pattern_id=$record["validation_pattern_id"];
		$sql_data_type=$record["sql_data_type"];
		$pattern=$record["pattern"];
		$sql_data_type=$record["sql_data_type"];
		$width=gracefuldecay($record["answer_width"], $intDefaultWidth);
		$height=$record["answer_height"];
		//if we need a FK dropdown, let's generate that
		if( $sql_data_type=="text")
		{
			$height=gracefuldecay($height, 4);
			$width=gracefuldecay($width*12, 30);
		}
		if($suggested_table_name!="")
		{
			$strNameField=NthNonIDColumName($strDatabase, $suggested_table_name, 1);
			
			$idFieldToUse=$strNameField;
			if(contains(strtolower($sql_data_type), "int"))
			{
				//if we specify an int as the data we want to collect from a dropdown, then we should be setting the option values to PKs instead of names
				$idFieldToUse=PKLookup($strDatabase, $suggested_table_name);
			}
			$inputfield=GenericTablePulldown($strDatabase, $suggested_table_name, $strNameField, $strNameField, $strQVarName, $strDefault, "", "", "?", true);
		
		
		}
		elseif ($sql_data_type=="date")
		{
		
			$inputfield=datepulldowns("answer-" . $questionnaire_question_id . "_date_",$strDefault);
		
		}
		elseif ($height>1  || $sql_data_type=="text")
		{
			$inputfield="<textarea rows=\"" .$height . "\" cols=\"" .$width . "\" name=\"" . $strQVarName . "\" id=\"id" . $strQVarName . "\">" . $strDefault . "</textarea>";
		
		}
		else
		{
			$inputfield= TextInput($strQVarName, $strDefault, $width, "",  "", "");
		
		}
		$intOut++;
		$out.=htmlrow("", $question, $inputfield);
		
	}
	$out.=htmlrow("", "&nbsp;", GenericInput("submit", "Save"));
	$out.=HiddenInputs(Array("questionnaire_id"=>$intQuestionnaire_id), "");
	$out.="</table>";
	$out.="</form>";
	return $out;
}

function SaveQuestionnaireAnswers($strDatabase, $intUserID)
{
	$sql=conDB();
	foreach($_REQUEST as $k=>$v)
	{
		if(contains($k, qpre . "answer-"))
		{
			if(contains($k,   "_date_|"))
			{
				$bwlSkipSave=false;
				if(contains($k,   "month"))//for a three part date all we need is the month
				{
					$arrQ=explode("-", $k);
					$k=$arrQ[1];
					$arrQ=explode("_", $k);
					$intQuestionID=$arrQ[0];
					//echo qpre . "answer-" . $intQuestionID . "_date_<br>";
					$v=RequestCompoundDate(qpre . "answer-" . $intQuestionID . "_date_");
					$bwlSkipRead=false;
					//echo $v;
				}
				else
				{
					$bwlSkipSave=true;
				}

			}
			else
			{
				$arrQ=explode("-", $k);
				$intQuestionID=$arrQ[1];
			}

			//echo $k . "<br>";
			
			{
				if(!$bwlSkipSave)
				{
					//echo $intQuestionID . " --<br>";
					UpdateOrInsert($strDatabase, "questionnaire_answer", Array("user_id"=>$intUserID,"questionnaire_question_id"=>$intQuestionID), Array("answer"=>$v));
					//$strSQL="INSERT INTO " . our_db . ".questionnaire_answer (answer, questionnaire_question_id, user_id) VALUES ('" .singlequoteescape($v) . "'," , $intQuestionID, "," . $intUserID;
				}
			}
			 

		}
	}
}

function GetQuestionnaireList($strPHP, $intQuestionnaireTypeID, $intThisQuestionnaireID)
{
	$sql=conDB();
	$out="";
 
	$strSQL="SELECT * FROM " . $strDatabase . ".questionnaire   WHERE  questionnaire_type_id=" .$intQuestionnaireTypeID . " ORDER BY sort_order    ASC";
	//echo $strSQL;
	$records = $sql->query($strSQL);
	foreach($records as $record)
	{
		$strClass="leftnav";
		$htmltag="a";
		if ($intThisQuestionnaireID==$record["questionnaire_id"])
		{
		
			$strClass="leftnav_selected";
			$htmltag="span";
		}
		$out.="<p><" . $htmltag . " class=\"" . $strClass ."\" href=\"" . $strPHP . "?questionnaire_id=" . $record["questionnaire_id"] . "\">" .  $record["name"] . "</" . $htmltag . "></p>";
	}
	return $out;

}

function MultipleAnswerTable($intThisQuestionnaireID)
{




}
?>