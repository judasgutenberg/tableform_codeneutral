<?
function SaveForm($strDatabase, $strTable, $strPKField, &$strValDefault, $strExtrajs, $strUser="")
//saves a form in the database and table, assuming all the form items have the names of the fields.
//skips fields beginning with qpre so I can pass data through without attempting to stuff it in the db.
//however, if it begins with  qpre  and ends with |day, |month, or |year, then we need to do special things because it is a date
//also handles file uploads having names of the form " . qpre . "u|FILENAME for which FILENAME is the corresponding field
//in the database.  
{
 	$sql=conDB();
	$dataadded=0;
	$oldkey="";
	$strSuperPre=qpre;
	$arrUpdate=array();
	$strSQL="";
	$builtjs="";
	$bwlSuperAdmin=IsSuperAdmin($strDatabase, $strUser);
	$strExistsSQL="";
	foreach ($_POST as $k=>$v)
	{
		
		if (contains($strExtrajs, "updateopener"))
		{
			$builtjs.="\nif(opener.document.BForm['ret_" . $k . "'])
			\n{\nopener.document.BForm['ret_" . $k . "'].value='" . $v . "';\n}\n";
			

		}
		$isDate=false;
		//echo $k . " " . $v . "<br>\n";
		//looking to see if this item is perhaps a date
		if (strpos(" " . $k, qpre)==1)
		{
			//$arrPossibleDateName=explode( "|", $k);
			if (strpos($k, "|")>1) //then it might be a date input
			{
				//" . qpre . "a is for handback prettyname form inputs
				//" . qpre . "u is for $_FILES
				//we want to eliminate both of those
				$strPossibleDateName=parseBetween($k, qdelimiter, "|");
				if  (!inList("a u", $strPossibleDateName))
				{
			 ;
					$day=$_POST[$strSuperPre . $strPossibleDateName . "|day"   ];
					$month=$_POST[$strSuperPre . $strPossibleDateName . "|month" ];
					$year=$_POST[$strSuperPre . $strPossibleDateName . "|year" ];
					//echo "<br>#" . $strSuperPre  . $arrPossibleDateName[1] . "|year"; 
					//echo "<br>*".  $month . "-" . $day . "-" . $year . "*<br>";
		
		 			$strTime=ReasonableStringDate($month, $day, $year);
					//echo $strTime . "<br>";
					$v=$strTime; //just turning the value into a PHP timestamp
					$k=$strPossibleDateName;  //just turning the key back to a conventional key for the next section
					$isDate=true;  //i use this to make sure there are quotes around a date, which are necessary for some reason
				}
			}
			
		}
		if (strpos(" " . $k, qpre)<1  && strpos($k, "X_FILE_SIZE")<1 ) //here we're eliminating hidden variables i need to pass for bookkeeping
		{
		
			//handle any file uploads:
			//where i read in the files and copy them to their proper places if there are file uploads
				
			if ($_FILES[qpre . "u|" . $k]["name"]!="")
				{
					$destpath=fieldNameToFolderPath( $k, imagepath)  . $_FILES[qpre . "u|" . $k]['name'];
					//echo $destpath;
					if (!BuildPathPiecesAsNecessary($destpath))
					{
						$out.="The path " .$destpath . " could not be built.<br>";
					}
					if (move_uploaded_file($_FILES[ qpre . "u|" . $k]['tmp_name'], $destpath))
					{
						chmod($destpath, 0777);
						$out.="The file " . $destpath . " was uploaded successfully.<br/>";
						//if we have a successful upload that put the new name in the db
						$v=$_FILES[qpre . "u|" . $k]['name'];
					}
					else
					{
						$out.="The file " . $destpath . " failed to upload.<br/>";
					}
			 	}		
			//if ($v!="")  //this was causing "none"-selected dropdown things not to save
			{
			 
			 	if ($v=="[multi-placeholder]")
				{
					 $v = $_POST[qpre . "multi"];
				
				}
			 
				if ($k!=$strPKField && $k!=$oldkey)
				{
				//echo $k . "=" .  $v . "-<br>\n";
				$strType=TypeParse(GetFieldType($strDatabase, $strTable, $k),0);
				 
				if (strtolower($strType)=="decimal")
				{
					 $v=ClearNumeric($v);
				}
				elseif (strtolower($strType)=="date")
				{
				}
				elseif  (strtolower($strType)=="datetime")
				{
					$v = DateTimeForMySQL($v);
				}
				if (is_numeric($v)  && !$isDate)
				{
					$strRSQL= $k . "=" . $v;
					
				}
				else
				{
					//$arrUpdate[$k]=  "'".  htmlcodify($v) . "'" ;
					$strRSQL=  $k . "='" . htmlcodify($v) . "'";
					 //echo $arrUpdate[$k]. "<p>";
				}
				if ($strPKField!=$k  && !is_string($v)) //in this system with no compound PKs, the primary key is useless in establishing the existance of an identical row.  the is_string part is to disregard this logic in the few cases where the PK is a string.  such tables are not proper tf style tables but they exist and we want to be able to edit them with tf
				{
					$strExistsSQL.=$strRSQL . " AND " ;
				}
				$strSQL.=$strRSQL . ",";
				$dataadded++;
				$oldkey=$k;  //i do this to keep dates from trying to put the same field into the db three times
				//echo $k . " " . $v. "<br>";
				}
			}
		}
		
	}

	//remove last comma and " and "
	$strSQL=RemoveLastCharacterIfMatch($strSQL, ",");
	$strExistsSQL=substr($strExistsSQL, 0, strlen($strExistsSQL)-5);
	 
	$strExistsSQL="SELECT * FROM " . $strDatabase . "." .  $strTable . " WHERE " . 	$strExistsSQL;
	$rs=$sql->query($strExistsSQL);
	if (count($rs)<1)
	{
	
		$bwlBeginsWithTF=beginswith($strTable,  tfpre);
		if (($bwlBeginsWithTF &&  $bwlSuperAdmin) || !$bwlBeginsWithTF)
		{
				
			if  ($strValDefault=="") //insert
			{
		 		//echo "INSERT INTO " . $strDatabase . "." .  $strTable . " SET " . $strSQL;
				$strSQL="INSERT INTO " . $strDatabase . "." .  $strTable . " SET " . $strSQL;
				$strDescrOfAction="added to";
				
				if(!hasautocount($strDatabase, $strTable))
				{
					$strISQL="SELECT MAX(" . $strPKField . ") as 'MAX' from " . $strDatabase . "." .  $strTable;
					$rs=$sql->query($strISQL);
					$r=$rs[0];
					$max=intval($r["MAX"])+1;
					$strSQL =$strSQL . "," . $strPKField . "=" . $max;
				}
				
			}
			else	//update
			{
		
				//echo "UPDATE " . $strDatabase . "." .  $strTable . " SET " . $strSQL . " WHERE " . $strPKField . " = " . $strValDefault;
				$strSQL="UPDATE " . $strDatabase . "." .  $strTable . " SET " . $strSQL . " WHERE " . $strPKField . " = '" . $strValDefault . "'";
				$strDescrOfAction="altered in";
			}
			//echo $strSQL;
			$sql->query($strSQL);
			$out.=  "A row of data was " . $strDescrOfAction. " the " . $strTable . " table in the " . $strDatabase . " database.";
		}
		else
		{
			$out.="You do not have permissions to alter this table.<br/>";
		
		}
		//i passed this in by reference so now i get to set it for the outside world to know and love
		$strValDefault = highestprimarykey($strDatabase, $strTable);
		
		if (contains($strExtrajs, "updateopener"))
		{
			$builtjs.="\nopener.document.BForm['" . qpre . "idfrominsert'].value='" . $strValDefault . "';\n";
		}
			
		if ($builtjs!="")
		{
			$builtjs="\n<script>" . $builtjs . ";\n";
			
			$builtjs.="</script>\n";
		}
	//if ($strExtrajs=="closeclickrecyclecomplete")
	}
	else
	
	{
		  $out.="Identical records cannot be inserted.";
	}
	
	return $builtjs .  $out;
	
}
?>