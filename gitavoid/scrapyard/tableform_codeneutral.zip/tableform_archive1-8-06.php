<?php 
//Gus Mueller January 2006
//provides a web front end admin tool for any MySQL db
//depends on a table called tf_relation for foreign key info
//also needs admin table, permission table, and permission_type table

require('admin_functions.php');
require('saveform.php');

//this is in case we are doing wysiwygpro, though i don't want it to bomb if the files aren't there
$errorlevel=error_reporting(0);
	include("editor_files/config.php");
	include("editor_files/editor_class.php");
error_reporting($errorlevel);

echo main();
 
function main()
	{
		$out="";
		$strPHP=$_SERVER['PHP_SELF'];
		$olderror=error_reporting(0);
		$mode=$_REQUEST[qpre . "mode"];
		$displaytype=$_REQUEST[qpre . "displaytype"];
		$idfield=$_REQUEST[qpre . "idfield"];
		$id=$_REQUEST[$idfield];
		$clearid=$_REQUEST[qpre . "submit_clearid"];
		$intFilterID=$_REQUEST[qpre . "filterid"];
		$strTable=$_REQUEST[qpre . "table"];
		$strDatabase=deMoronizeDB(gracefuldecay($_REQUEST[qpre . "db"],our_db));
		$strColumn=$_REQUEST[qpre . "column"];
		$strDirection=$_REQUEST[qpre . "direction"];
		$strSearchField=$_REQUEST[qpre . "searchfield"];
		$strSearchString=$_REQUEST[qpre . "searchstring"];
		$intSearchType=$_REQUEST[qpre . "searchtype"];
		$strExtrajs=$_REQUEST[qpre . "extrajs"];
		$intRecord=$_REQUEST[qpre . "rec"];
		$feedbackspanstag="<span class=\"feedback\">";
		//error_reporting($olderror);
		$bwlSimplifyLogin=false;
	  	//if the table name begins with a "!" then we go directly to any tool written specifically for it
	  	if (beginswith($strTable,"!"))
		{
			//echo "$$";
			$strTable=substr($strTable, 1);
			$toolpage=GenericDBLookup($strDatabase, tfpre . "browsescheme", "table_name", $strTable, "toolpage");
			
			if ($toolpage!="")
			{
				//echo "#";
 				header("Location: " . qbuild( $toolpage , $strDatabase, $strTable, "view", "id", $strOurID) . "&displaytype=7");
			}
		}
	  
	  
	 	if ($mode=="")
		{
			$strTable="";
		}
		if (contains($strExtrajs,"closeclickrecycle"))
		{
			$bwlSimplifyLogin=true;
		}
		$out=LoginDecisions($strDatabase,  $strPHP, $strUser,$bwlSimplifyLogin);
		$intUserID=GenericDBLookup($strDatabase,  tfpre . "admin", "username", $strUser, "admin_id");
	 	if ($strUser!="")
		{
			$isSuperAdmin=IsSuperAdmin($strDatabase, $strUser);
			$intAdminType= AdministerType($strDatabase, $strTable, $strUser, $id);
			
			if ($intSearchType=="")
			{
				$intSearchType=0;
			}
			if ($intRecord=="")
			{
				$intRecord=0;
			}
	 
			if (default_table=="default_table")
			{
				if ($strTable=="")
				{
					
					$out.=tablebrowser($strDatabase, $strPHP, $strUser);
				}
			}
			else
			{
				if ($strTable==""  && !$isSuperAdmin)
				{
					$strTable=default_table;
					$mode="view";
					
				}
				else if ($isSuperAdmin  && $strTable=="")
				{
				
					$out.=tablebrowser($strDatabase, $strPHP, $strUser);
				}
			
			}
			if ($mode=="save"  || $mode=="create")
			{
			
				if ($intAdminType==2)
				{
					//i clear id if i'm doing a "save as" type operation
					if ($clearid!="")
					{
						$mode="create";
						$id="";
					}
					$out.=$feedbackspanstag .  SaveForm($strDatabase, $strTable,  $idfield, $id, $strExtrajs, $strUser). "</span><br>" ;
				}
				else
				{
					$out.="You don't have permissions to edit this table.";
				}
			}
			//echo $mode . "+" . $strExtrajs;
			if ( $mode=="edit" || ($mode=="create"  &&  !contains($strExtrajs,"complete")))
			{
				if ($intAdminType==2)
				{
					
					$out.=TableForm($strDatabase, $strTable,  $idfield, $id, $strPHP,  $strExtrajs, "", $strUser);
					
				}
				elseif ($intAdminType==1)
				{
					$out.=DisplayDataForARow($strDatabase, $strTable, $idfield, $id, $strPHP);
				}
				else
				{
					$out.="You don't have permissions to view or edit this table.";
				}
			}
			if ($mode=="delete")
			{
				if ($intAdminType==2)
				{
					$out.=$feedbackspanstag . rowdelete($strDatabase, $strTable,  $idfield, $id, $strUser) . "</span>"; 
				}
				else
				{
					$out.="You don't have permissions to edit this table.";
				}
				if (contains($strExtrajs,"closeclickrecycle"))
				{
					$strExtrajs.="complete";
				}
			}
		 
			if ( $mode=="new")
			{
				if ($intAdminType==2)
				{
					$out.=TableForm($strDatabase, $strTable,  "", "", $strPHP, $strExtrajs,"", $strUser);
				}
				else
				{
					$out.="You don't have permissions to edit this table.";
				}
				
			}
			
			if (($mode=="view"  || ($mode=="save" ) || $mode=="delete")    &&  !contains($strExtrajs,"complete"))
			{
				 
				if ($intAdminType>0)
				{
					$strFieldConfig="cust_order|customer_name*episode|episode_name|episode_datetime|show_id";
					$out.=DisplayDataTable($strDatabase, $strTable, "", $strColumn, $strPHP, $strDirection, $intRecord, $strSearchString, $strSearchField, $intSearchType, 50, $strFieldConfig, 1, 5, true, false, false, "", $displaytype, $intFilterID, $intUserID);
					//DisplayDataTable($strDatabase, $strTable, $strIDFieldName, $strSortColumn, $strPHP, $strDirection, $intRecord, $strSearchString, $strSearchField, $intSearchType,$intRecsPerPage=50, $strFieldConfig="", $intFieldLimitLo=1,$intFieldLimitHi=5, $bwlShowDelete=true, $bwlHandback=false, $bwlSuppressHeaderLinks=false, $launcherfield="", $displaytype="", $intThisFilterID, $UserID="")
				 
				}
				else
				{
					$out.="You don't have permissions to view this table.";
				}
			}
		}
		
 
 		if (function_exists(toolnav) && !$bwlSimplifyLogin )
		{
			if ($strUser!="")
			{
				$out=toolnav(!$isSuperAdmin) . $out;
			}
		}
		$out =PageHeader($strDatabase . " : Editor", $strExtrajs) . $out . PageFooter();
		return $out;
	}

function rowdelete($strDatabase, $strTable,  $idfield, $id, $strUser)
//deletes a row of data from $strTable in $strDatabase matching $idfield=$id
{
	$bwlSuperAdmin=IsSuperAdmin($strDatabase, $strUser);
	$bwlBeginsWithTF=beginswith($strTable,  tfpre );
	if (($bwlBeginsWithTF &&  $bwlSuperAdmin) || !$bwlBeginsWithTF)
	{
		$sql=conDB();
		$strSQL="DELETE FROM " . $strDatabase . "." . $strTable . " WHERE " .  $idfield . " = " . $id;
		$records = $sql->query($strSQL);
		$out= "A row was deleted from the " . $strTable . " table in the " . $strDatabase . " database whose " .  $idfield . " was equal to " . $id;
	}
	else
	{
		$out= "You do not have permission to delete from this table.";
	}
	return $out . "<br/>";
}

function tablebrowser($strDatabase, $strPHP, $strUser)
//shows all the tables in $strDatabase
{
	$strClassFirst="bgclassfirst";
	$strClassSecond="bgclasssecond";
	$strOtherBgClass="bgclassother";
	$strLineClass="bgclassline";
	$strThisBgClass=$strClassFirst;
	$bwlViewsPossible=  TableExists($strDatabase,  tfpre . "browsescheme");
	$sql=conDB();
	//$tables = $sql->showtables(array("db" => $strDatabase)); 
	$bwlSuperAdmin=IsSuperAdmin($strDatabase, $strUser);
	if (IsSuperuser($strDatabase,  $strUser))
	{
		$strSQL="SHOW TABLES FROM " .  $strDatabase ; 
	}
	else
	{
		$intAdminID=GetAdminID($strDatabase, $strUser);
		//echo "SELECT table_name AS " . "Tables_in_" . $strDatabase . " from " .  $strDatabase . ".permission  WHERE admin_id=" .  $intAdminID ;
		$strSQL="SELECT table_name AS " . "Tables_in_" . $strDatabase . " from " .  $strDatabase . "." . tfpre . "permission WHERE admin_id=" .  $intAdminID . " ORDER BY table_name ASC "; 
	
	}
	//echo $strSQL;
	$tables = $sql->query($strSQL);
	//echo mysql_error();
	//asort($tables);
	$out= "<table border=\"0\" cellspacing=\"1\" cellpadding=\"2\" class=\"" .$strLineClass  . "\" width=\"450\">\n";
	$out.= "<tr class=\"" . $strOtherBgClass . "\"><td colspan=\"5\">\n";
	$out.= adminbreadcrumb(false,  $strDatabase, "",  "Tables", "") ;
	if ($bwlSuperAdmin)
	{
		$out.=LinkIfFile("tablemaker.php", qpre . "db=" . $strDatabase, "create new table", " [", "]") ;
		$out.=LinkIfFile("dbtools.php", qpre . "db=" . $strDatabase, "db tools", " [", "]") ;
	}
	$out.= "</td></tr>\n";
	
	$out.=htmlrow("bgclassline", "table", "records", "other views", "&nbsp;", "&nbsp;" );

	//echo "-" . count($tables) . "-" ;
	$strFieldName="Tables_in_" . str_replace("`", "", $strDatabase);
	//echo $strFieldName;
	$bwlTableMakerExists=file_exists("tablemaker.php");
	foreach ( $tables as  $k=>$v )
	{
		
		$tablename=$v[$strFieldName];
		$bwlBeginsWithTF=beginswith($tablename,  tfpre );
		if (($bwlBeginsWithTF &&  $bwlSuperAdmin) || !$bwlBeginsWithTF)
		{
			//echo $k;
			$strThisBgClass=Alternate($strClassFirst, $strClassSecond, $strThisBgClass);
			$out.= "<tr  class=\"" . $strThisBgClass . "\">\n";
			$out.= "<td><a href=\"" . qbuild($strPHP, $strDatabase, $tablename , "view", "", "") . "\">" . $tablename . "</a></td>\n";
			$count = countrecords($strDatabase , $tablename );
			if ($bwlViewsPossible)
			{
				$otherviews=ListViews($strDatabase , $tablename, $strPHP);
			}
			$out.= "<td>" .  $count . "</td>\n";
			$out.= "<td>" . $otherviews . "</td>\n";
			
			
			$out.= "<td>";
			if ($bwlSuperAdmin  && $bwlTableMakerExists)
			{
				$out.= "[<a href=\"" . qbuild("tablemaker.php", $strDatabase, $tablename , "", "", "") . "\">edit def.</a>]";
			}
			else
			{
				$out.= "&nbsp;";
			}
			$out.= "<td>[<a href=\"" . qbuild("dump.php", $strDatabase, $tablename , "", "", "") . "\">export</a>]</td>\n";
			$out.= "</td>\n";
			$out.= "</tr>\n";
		}
		
	}
	 $out.="</table>"; 
	return $out;
}

function ListViews($strDatabase , $strTable, $strPHP)
{
	
	$sql=conDB();
	$strSQL="SELECT * FROM " . $strDatabase . "." .  tfpre . "browsescheme b JOIN " . $strDatabase . "." .  tfpre . "browsetype t ON b.browsetype_id=t.browsetype_id WHERE b.table_name='" . $strTable . "'";
	//echo $strSQL . "<br>";
	$records = $sql->query($strSQL); 
	foreach($records as $record)
	{
		$toolpage=$record["toolpage"];
		//echo $toolpage . "<br>";
		if ($record["browsetype_id"]==7 && $toolpage!=""  && file_exists($toolpage))
		{
			//if we have a browser of type 7 then just link directly to the tool with the params we know about
			$out.= " <a href=\"" . qbuild($toolpage, $strDatabase, $strTable , "view", "", "") . "&" . qpre . "displaytype=" . $record["browsetype_id"] . "\">" .  pluralize($strTable) . "</a>\n";
		}
		else
		{
			$out.= " <a href=\"" . qbuild($strPHP, $strDatabase, $strTable , "view", "", "") . "&" . qpre . "displaytype=" . $record["browsetype_id"] . "\">" . $record["name"] . "</a>\n";
		}
	
	}
	return $out;

}

function TableForm($strDatabase, $strTable, $strIDField, $strValDefault, $strPHP,  $strExtrajs, $strFieldNamePrefix="", $strUser="")
{
//a generic form generator that looks at the table's description in the db and then dynamically builds an editor form
	$sql=conDB();
	$out="";
	$strValidationJS="";
	$width=50;
	//the following two lines apply when there is integration with wysiwygpro
	$editorcount=0;
	$editor=Array();
	$strClassFirst="bgclassfirst";
	$strClassSecond="bgclasssecond";
	$strOtherBgClass="bgclassother";
	$strLineClass="bgclassline";
	$strThisBgClass=$strClassFirst;
	$noshowfields=$_REQUEST[qpre . "noshow"];
	//the following 3 lines are sort of a hack to enable the form to return to the right page in the pagination when finished
	$intRecord=$_GET[qpre . "rec"];
	$strSort=$_GET[qpre . "column"];
	$strDirection=$_GET[qpre . "direction"];
 	$arrHelpText=Array();
	$arrPrettyName=Array();
	$arrValidationType=Array();
	$arrValidationPattern=Array();
	$arrWidth=Array();
	$arrHeight=Array();
	$arrIsPassword=Array();
	$arrIsFileUpload=Array();
	$intNestTable=0;
	$strNest=""; 
	$bwlSuperAdmin=IsSuperAdmin($strDatabase, $strUser);
	if($bwlSuperAdmin)
	{
	//echo "!";
	}
	if  ($strIDField=="")
	{
		$strIDField= idcolumname($strDatabase, $strTable);
	}
	
	$out.="<table cellpadding=\"0\" cellspacing=\"1\" border=\"0\" width=\"100%\" class=\"" . $strLineClass ."\">\n";
	if (!contains($strExtrajs, "noform"))
	{
		$out.="<form enctype=\"multipart/form-data\" name=\"BForm\" method=\"post\" action=\"" . $strPHP . "\" onSubmit=\" return validate_form();\">\n";
	}
	$out.= "<input type=\"hidden\" name=\"" . $strFieldNamePrefix . "MAX_FILE_SIZE\" value=\"12000000\" />\n";
	
	$descr = $sql->query("EXPLAIN " . $strDatabase . "." . $strTable);
 
	$out.= "<tr class=\"" . $strOtherBgClass . "\">\n";
	$out.= "<td colspan=\"" . intval(count($descr))  . "\">";
	$intDefaultWide=50;
	
	if (!contains($strExtrajs, "noheader"))
	{
		if (!contains($strExtrajs,"closeclickrecycle"))
			{
				
				$intDefaultWide=90;
				$secondarytoollable=$strDatabase;
				$closebutton="";
				$disablelink=false;
			}
			else
			{
				$secondarytoollable="Secondary Editor";
				$closebutton="  [<a href=\"message.php\">close this tool</a>]";
				$disablelink=true;
			}

		$out.=adminbreadcrumb($disablelink,  $secondarytoollable, $strPHP . "?" . qpre . "db=" . $strDatabase,  $strTable, qbuild($strPHP, $strDatabase, $strTable, "view", "", "")) . $closebutton;
	}
	
	$out.= "</td>\n";
	$out.= "</tr>\n";
  
	$record="";
	if ($strValDefault!="")
	{
	
		$strSQL="SELECT * FROM " . $strDatabase . "." . $strTable . " WHERE " .  $strIDField . " = '" . $strValDefault . "'";
		//echo $strSQL;
		$records = $sql->query($strSQL);
		$record=$records[0];
		$strOtherButtonText="New " . $strTable;
		$strButtonText="Save " . $strTable;
		
		$strMode="save";
		
	}
	else
	{
		$strButtonText="Create " . $strTable;
		$strMode="create";
	}
 	if (contains($strExtrajs,"closeclickrecycle"))
	{
		$strExtrajs.="complete";
		
	}
 	$futurelabel="";
	$strFromMulti="";
	$strTableLookingOutWith="";
	foreach ($descr as $nom=>$info)
		{
			$strPickerLink="";
			$skip=false;
			$fieldlabel=$info["Field"];
			$name=$fieldlabel;
			$nameforhelp=$name;
			if(!inList($noshowfields, $name))
			{
			
				$strThisBgClass=Alternate($strClassFirst, $strClassSecond, $strThisBgClass);
				$strDefault="";
				$strType=TypeParse($info["Type"], 0);
				$intLen=intval(TypeParse($info["Type"], 1));
				$width=$intLen;
				$bwlInvisible=false;
				$strPseudo="";
				$strMSQL="select * from " . $strDatabase . "." .  tfpre . "column_info WHERE table_name='" . $strTable . "' AND column_name='" . $name . "'"; 
				$mrecords = $sql->query($strMSQL);
				if (count($mrecords)>0)
				{
					$mrecord=$mrecords[0];
					$fieldlabel=gracefuldecay($mrecord["label"], $fieldlabel);
					$helptext=$mrecord["help_text"];
					$arrValidationType[$nameforhelp]=$mrecord["validation_type_id"];
					
					$arrWidth[$nameforhelp]=$mrecord["width"];;
					$arrHeight[$nameforhelp]=$mrecord["height"];
					$arrIsPassword[$nameforhelp]=$mrecord["password"];
					$arrIsFileUpload[$nameforhelp]=$mrecord["fileupload"];
	
					$arrValidationPattern[$nameforhelp]=GenericDBLookup($strDatabase,  tfpre . "validation_pattern",  "validation_pattern_id",$mrecord["validation_pattern_id"], "pattern");
					$arrHelpText[$nameforhelp]=$helptext;
					$arrPrettyName[$nameforhelp]=$fieldlabel;
					if ($mrecord["invisible"]==1)
					{
						$bwlInvisible=true;
					}
					if ($mrecord["data_from_multitable_relation"]==1)
					{
						 $strDefault="[multi-placeholder]";
					}
				}
				if ($bwlInvisible)
				{
					$out.="<input type=\"hidden\" name=\"" .$strFieldNamePrefix . $name . "\"   value=\"".  $strDefault . "\">\n";
				}
				else
				{
					
					$arrPseudo=RelationLookup($strDatabase, $strTable, $name, 3);
					//a pseudo-field is a "field" that is actually a formula in a field belonging to a parent table
					//it is found at this point only so it knows to display it after this field is displayed in another way
					if (count($arrPseudo)>0)
					{
						
						$strRTable=$arrPseudo[0];
						$strRField=$arrPseudo[1];
						$strIDFieldName = PKLookup($strDatabase, $strRTable);
						//in a pseudotable, what you get is a formula
						$strFormula=GenericDBLookup($strDatabase, $strRTable, $strIDFieldName, $arrRelationTemp[$strRTable], $strRField);
						if ($strFormula!="")
						{
							
							//a sample formula:
							//wordencode($strValDefault, 6, time());
							//$idtouse=gracefuldecay($futureid,  $strValDefault);
							$idtouse=$strValDefault;
							if ($idtouse>0)
							{
								$strThisBgClass=Alternate($strClassFirst, $strClassSecond, $strThisBgClass);
								$strFormula = str_replace("\$id", $idtouse, $strFormula);
								$strPseudoContent=   eval("return " .  $strFormula);
								$strPseudoLabel=gracefuldecay($futurelabel, $strTable) . " " . $strRField;
								$strPseudo.="<tr class=\"" .  $strThisBgClass . "\">\n";
								$strPseudo.="<td valign=\"top\">\n";
								$strPseudo.=$strPseudoLabel . "\n";
								$strPseudo.="</td>\n";
								$strPseudo.="<td class=\"heading\">\n";
								$strPseudo.=$strPseudoContent; 
								$strPseudo.="</td>\n";
								$strPseudo.="</tr>\n";
								$strThisBgClass=Alternate($strClassFirst, $strClassSecond, $strThisBgClass);
							}
						}
					
					}
					if (is_array($record))
					{
						$strDefault=$record[$info["Field"]];
						
						$strDefault=substr($strDefault, 0, strlen($strDefault));
						
						//i have a real problem with single quotes!!!
						$strDefault=deendquote($strDefault);
					}
					$strDefault=gracefuldecay($_GET[$name], $strDefault);
					$bwlHypLabel=false;
					if ($strType=="int")
					{
						$width=5;
						$arrMK=RelationLookup($strDatabase, $strTable, $name, 1);
						if (count($arrMK)>0)
						{
							$bwlHypLabel=true;
							//if we are dealing with a multi-table lookup, then things get really weird at that point.  
							//suddenly the row we're looking at becomes just the husk for a field in a totally different table
							//but first we need to know what that table is and what field it is.  we don't find that table directly;
							//we have to look it up using the arrFK we just retrieved
							//right all we now is that the primary key for that field in that other table is the integer in this field
							//and that the table and field containing the name of the distant table was just retrieved.
							
							//first:  that table
							$strRTable=$arrMK[0];
							$strRField=$arrMK[1];
							
							//get the primary key of the $strRTable that applies to this specific row
							//it actually will have probably been determined earlier (to put one of the dropdowns in the right spot)

							//at this point i assume that the pk of $strRTable is what we need
							$strIDFieldName = PKLookup($strDatabase, $strRTable);
							
							$strDistantTable=GenericDBLookup($strDatabase, $strRTable, $strIDFieldName, $arrRelationTemp[$strRTable], $strRField);
							$intDistantPK = PKLookup($strDatabase, $strDistantTable);
							$intNestTable++;
							$strNest.="|" . $intNestTable;
							//just for shits im gonna get all recursive right now...
							//$out.= TableForm($strDatabase,$strDistantTable,$intDistantPK,  $strDefault, $strPHP,  "noheader noextra noform", "zzz|" . $intNestTable / . "|");
							//okay, so i chickened out!  but i could have
							$skip=true;
							$fieldlabel=gracefuldecay($strDistantTable, $fieldlabel);
							//if i have a multi-table relation, chances are i'll want to use the name of the wild table and its pk somewhere later in the tool.
							$futurelabel=$strDistantTable;
							$futureid=$strDefault;
							$fieldform=foreigntablepulldown($strDatabase,$strDistantTable, $intDistantPK, $strDefault, $strFieldNamePrefix .$name, $strFromMulti, true);
							$strFieldLabelLink=qbuild($strPHP, $strDatabase, $strDistantTable, "edit", $intDistantPK, $strDefault). "&" . qpre . "extrajs=closeclickrecycle";
						}
						$arrFK=RelationLookup($strDatabase, $strTable, $name,0);
						if (count($arrFK)>0)
						{
						
							$bwlHypLabel=true;
								//i capture this info in case i need it later for a MultiTable lookup
						 		$arrRelationTemp[$arrFK[0]]=$strDefault;
								$skip=true;
								$count = countrecords($strDatabase,$arrFK[0]);
								//if $count <101 do a dropdown for a foreign key.  otherwise slap down a link to a searchable picker
								//because i'm all cool like that
				 
								if ($count<101)
								{
									$fieldlabel=ReturnNonIDPartOfName($fieldlabel);
									//bleh is necessary because it is by reference, but i have nothing i want to do with it
									$fieldform=foreigntablepulldown($strDatabase,$arrFK[0], $arrFK[1], $strDefault, $strFieldNamePrefix .$name, $bleh, false);
							 
								}
								else
								{
									$skip=false;
									$width =5;
									//$strPrettyLabelField=firstnonidcolumname($strDatabase, $arrFK[0]);
									$strPickerLabel=LabelForID($strDatabase, $arrFK[0], $arrFK[1], $strDefault);
									$strPickerLink= "<input style=\"font-size:9px; border:0px;\" class=\"" . $strThisBgClass . "\" type=\"text\" name=\"" . $strFieldNamePrefix .  qpre . "a|" .  $name . "\" size=\"20\" value=\"" . deescape($strPickerLabel)  . "\">\n";
									$strPickerLink.=" [<a href=\"#\" onclick=\"pickerwindow('". $strDatabase . "','" . $arrFK[0] . "','".  $strFieldNamePrefix . $name ."')\">browse</a>]\n";
									
								}
								//$fieldlabel=$info["foreign"]; //for foreign keys with dropdowns, label them with table name
								//add a link to an editor for the foreign key label because i'm all cool like that
								
								$strFieldLabelLink= qbuild($strPHP, $strDatabase, $arrFK[0], "edit", $arrFK[1], $strDefault) . "&" . qpre . "extrajs=closeclickrecycle";
						 
						}
						if ($bwlHypLabel==true)
						{
							if (!contains($strExtrajs,"complete"))
							{
								$fieldlabel="<a target=\"secondarytool\" href=\"". $strFieldLabelLink . "\">" . $fieldlabel . "</a>\n";
							}
							else
							{
								$fieldlabel="<a onclick=\"javascript:return(popdetachedwindow('" . $strFieldLabelLink . "','300','500'))\">" . $fieldlabel . "</a>\n";
							}
						}
					}
				elseif  ($strType=="text" || $intLen>100)
				{
					$skip=true;
					$width=gracefuldecay($arrWidth[$nameforhelp],intval($intDefaultWide *.8));
					$height=gracefuldecay($arrHeight[$nameforhelp], intval(strlen($strDefault)/80)+5);
					if (textarea=="textarea" || $strType!="text" )
					{
						//old way: with textarea.  do this if no wysiwyg installed or the field type isn't actually text
						$fieldform="<textarea name=\"" . $strFieldNamePrefix . $name . "\" cols=\"" . $width . "\" rows=\"" .$height . "\">" .  $strDefault . "</textarea>\n";
					}
					else
					{
						//using wysiwygPro
						$editorcount++;
						if($width<10)
						{
							$width=10;
						}
						if($height<40)
						{
							$height=40;
						}
						$editor[$editorcount]= new wysiwygPro();
						$editor[$editorcount]->set_code($strDefault);
						$editor[$editorcount]->set_name($strFieldNamePrefix . $name);
						$fieldform=$editor[$editorcount]->return_editor(gracefuldecay($arrWidth[$nameforhelp],$width *10),gracefuldecay($arrHeight[$nameforhelp],$height*5));
					}
				}
				elseif  ($strType=="date")
				{
					$skip=true;
					$fieldform=datepulldowns($strFieldNamePrefix . $name, $strDefault);
				}
				elseif  ($strType=="tinyint" || $strType=="bit" )
				{
					$skip=true;
					$fieldform=boolcheck($strFieldNamePrefix . $name, $strDefault);
				}
				else 
				{
					$width=intval($width * ($intDefaultWide/90));
					
				}
				if ($info["Extra"]!="auto_increment"  && !$skip)
				{
				
					$strFormType="text";
					
					if ($name=="password"  || $arrIsPassword[$nameforhelp]==1)
					{
						$strFormType="password";
					}
					if($strTableLookingOutWith !="" && (contains($name, "column") || contains($name, "field")))
					{
						//echo $strType . "-" . $strTableLookingOutWith . "<br>";
						//echo  $strTableLookingOutWith;
						
						$fieldform=FieldDropdown($strDatabase, $strTableLookingOutWith, $name, $strDefault);
						//$strTableLookingOutWith="";
						//TableDropdown($strDatabase, $strDefault,$strFieldNamePrefix . $name, "BForm","column_name");
					
					}
					elseif (contains($name, "table_name")) //special case for references to tables
					{
						// TableDropdown($strDatabase, $strDefaultTable, $strTableFormName, $strOurFormName='BForm', $strFieldFormName="")
						
						//time to speculate about the field names for the fields that goes with this table dropdown:
						//i have it so my primitive ajax tech can update all the selects automatically with a change of the table dropdown
						$blwNextColumn=false;
						$associatedColumnName="";
						foreach($descr as $fnom=>$finfo)
						{
							
							$fname=$finfo["Field"];
							//echo $fname . "=<br>";
							//echo $blwNextColumn . "%<br>";
							if ($fname==$name)
							{
								$blwNextColumn=true;
							}
							elseif ($blwNextColumn  && contains($fname, "_table"))
							{
								$blwNextColumn=false;
								break;
								
							}
							if ($blwNextColumn  && (contains($fname, "column") || contains($fname, "field")))
							{
								//i use plus here because i happen to know it is urlencoded space and i will later split on space on my hidden ajax page
								//and then cycle through all the select dropdowns that need to have their fields updated to reflect the new table
								$associatedColumnName.=$fname . "+" ;
								//$blwNextColumn=false;
								
							}
							
						}
						$associatedColumnName=RemoveEndCharactersIfMatch($associatedColumnName, "+" );
						//if associatedColumnName doesn't contain anything, then none of the fancy ajax stuff is turned on for this table select
						$fieldform=TableDropdown($strDatabase, $strDefault,$strFieldNamePrefix . $name, "BForm",$associatedColumnName);
						//i use a space here to force a fielddropdown if we have a tabledropdown
						$strTableLookingOutWith=gracefuldecay($strDefault, " ");
					
					}
					else
					{
						 
						$fieldform="";
						$strAboveForm="";
						$strValString="value=\"". forinputform($strDefault) . "\"";
						//i determine whether or not we make this form item an upload based entirely on its field name, not its type,
						//as in, does the field name contain either the string "filename" or "banner" 
						//(alter the NeedsUpload function to change this behavior)
						
						if (NeedsUpload($name)  || $arrIsFileUpload[$nameforhelp]==1)
						{	
							$path=fieldNameToFolderPath($strFieldNamePrefix . $name, imagepath) . $strDefault;
							$ahtml="";
							$slasha="";
							if (file_exists($path))
							{
								$ahtml="<a href=\"#\" onclick=\"popwindow('" . $path . "', '" . 200 . "', '" . 500 . "','picwindow'); \">";
								$slasha="</a>";
							}
							$fieldform=   PictureIfThere($path, "100") . "\n";
							$width=intval($width*.5);
							$strFormType="file";
					 		$strAboveForm="&nbsp;&nbsp;&nbsp;" . $ahtml . $strDefault . $slasha . "<br>" . "<input type=\"hidden\" name=\"" .$strFieldNamePrefix . $name . "\"   value=\"".  $strDefault . "\">\n";
							
							$name=$strFieldNamePrefix . qpre . "u|" . $name;
							$strValString="";
						}
						$fieldform=$strAboveForm . "<input type=\"" . $strFormType . "\" name=\"" . $strFieldNamePrefix . $name . "\" size=\"" . gracefuldecay($arrWidth[$nameforhelp],$width) . "\" " . deescape($strValString) . ">\n" . $fieldform . $strPickerLink;
					}
				}
			
				elseif ($info["Extra"]=="auto_increment"  && $strValDefault=="")
				{
					$fieldform="&nbsp;&nbsp;&nbsp;<strong>autoincrement:</strong> \n";
				}
				elseif ($info["Extra"]=="auto_increment" && $strValDefault!="")
				{
					$fieldform="&nbsp;&nbsp;&nbsp;<strong>" .  $strValDefault. "</strong> \n";
				}
				
				$out.="<tr class=\"" .  $strThisBgClass . "\">\n";
				$out.="<td valign=\"top\">\n";
				$out.=$fieldlabel . "\n";
				$out.="</td>\n";
				$out.="<td>\n";
				$out.=$fieldform ; 
				
				//help link/text
				if ($bwlSuperAdmin)
				{
				
					$strHelpLink="help('" .$strDatabase . "','" . $strTable  . "','" . $nameforhelp. "')";
				}	
				else
				{
				
					$strHelpLink="return(false)";
				}
				if ($arrValidationType[$nameforhelp]!="")
				{
					//echo HexDump($arrValidationPattern[$nameforhelp]);
					if (!$bwlInvisible)
					{
						$strValidationJS.= $nameforhelp . "~" . $arrValidationType[$nameforhelp] . "~"  . $arrPrettyName[$nameforhelp]  ."~"  . html_entity_decode(decode_entities($arrValidationPattern[$nameforhelp])) . "<validata/>"; 
					}
				}
				if ($arrHelpText[$nameforhelp]!="")
				{
					$out.="<span onmouseover='return escape(\"" . htmlcodify($arrHelpText[$nameforhelp]) . "\")' href=\"" . $strHelpLink . "\">?</span>";
				}
				else if ($bwlSuperAdmin)
				{
					$out.="<span onclick=\"" . $strHelpLink . "\">?!</span>";
				}
				$out.="</td>\n";
				$out.="</tr>\n";
				$out.=$strPseudo;
				if ($strPseudo!="")
				{
					$strThisBgClass=Alternate($strClassFirst, $strClassSecond, $strThisBgClass);
				}
			}
			
	 	}
	}

	$out.="<tr>\n<td colspan=2 align=\"right\">\n";
	if ($strValDefault!="")
	{
			$out.="<input class=\"btn\"
   onmouseover=\"this.className='btn btnhov'\" onmouseout=\"this.className='btn'\" name=\"" . qpre . "submit_clearid\" type=\"submit\" value=\"" . $strOtherButtonText ."\">\n";
	
	}
	$out.="<input class=\"btn\"
   onmouseover=\"this.className='btn btnhov'\" onmouseout=\"this.className='btn'\" name=\"" . qpre . "submit\" type=\"submit\" value=\"" . $strButtonText ."\">\n";
	$out.="</td>\n</tr>\n";
	$out.=HiddenInputs(array("dropdowntextvalue"=>"", "rec"=>$intRecord, "column"=>$strSort, "direction"=>$strDirection));
	$out.=HiddenInputs(array("table"=>$strTable,"table"=>$strTable,"db"=>$strDatabase,"mode"=>$strMode,"idfield"=>$strIDField,"extrajs"=>$strExtrajs ),qpre, $strFieldNamePrefix);
	$out.="<input type=\"hidden\" name=\"" . $strFieldNamePrefix . $strIDField . "\"   value=\"".  $strValDefault . "\">\n";
	if (strpos(" " . $strExtrajs, "noform")<1)
	{
		$out.="</form>";
	}
	$out.="</table>\n<p>";

	$strLowerLeftContent="\n<iframe frameborder=\"0\" marginwidth=\"0\" marginheight=\"0\" width=\"340\" height=\"400\" name=\"foreignstuff\" src=\"" . qbuild("foreign.php", $strDatabase, $strTable, "", $strIDField, $strValDefault). "&" . qpre . "extrajs=noextras&" . qpre . "iddefault=" .  $strValDefault . "\"></iframe>";

	$strLowerRightContent="\n<iframe frameborder=\"0\" marginwidth=\"0\" marginheight=\"0\" width=\"450\" height=\"400\" name=\"secondarytool\" src=\"message.php\"></iframe>";
	
	//$out.= ForeignKeyReferralLists($strDatabase, $strTable,$strIDField , $strValDefault, $strPHP);
	if (!contains($strExtrajs, "noextra"))
	{
		if ($strExtrajs!="noextras"  && !contains($strExtrajs,"complete"))
		{
			$out=FormEncapsulate($out, $strLowerLeftContent, $strLowerRightContent);
		}
		elseif ($strValDefault!="")
		{
			$out.="<p>\n";
			$out.="<a target=\"_new\" href=\"" . qbuild($strPHP, $strDatabase, $strTable, "edit", $strIDField, $strValDefault) . "\">Edit this " . $strTable . " and <em>its</em> Associated Items</a> starting in a new window.</a>";
			
		}
	}
	$out.="\n<script>\nvalidationconfig='" . $strValidationJS . "'\n</script>\n";
	return $out;
}
 
function FormEncapsulate($strMainFormContent, $strLowerLeftContent, $strLowerRightContent)
//throws an editor into a three-pane editor for real down-and dirty editing possibilities
{
	$out="<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"800\">\n";
	$out.="<tr>\n<td colspan=\"2\">\n";
	$out.=$strMainFormContent;
	$out.="</td>\n";
	$out.="<tr>\n";
	$out.="<td>\n";
	$out.=$strLowerLeftContent;
	$out.="</td>\n";
	$out.="<td>";
	$out.=$strLowerRightContent;
	$out.="</td>\n</tr>\n";
	$out.="</tr>\n";
	$out.="</table>\n";
	return $out;
}
?>