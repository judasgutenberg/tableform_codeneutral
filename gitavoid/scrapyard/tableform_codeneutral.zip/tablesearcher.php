<? 
//Gus Mueller January 2006
//provides a web front end admin tool for any mysql db
//i've modified txtsql to be aware of foreign keys so this tool can dynamically build complicated tools

include('admin_functions.php');

echo main();

function main()
	{
	
		
		//$olderror=error_reporting(0);
		$mode=$_REQUEST[qpre . "mode"];
		$idfield=$_REQUEST[qpre . "idfield"];
		$launcherfield=$_REQUEST[qpre . "launcherfield"];
		$id=$_REQUEST[qpre . "iddefault"];
		$strTable=$_REQUEST[qpre . "table"];
		$strDatabase=deMoronizeDB(gracefuldecay($_REQUEST[qpre . "db"],our_db));
		$strColumn=$_REQUEST[qpre . "column"];
		$strDirection=$_REQUEST[qpre . "direction"];
		$strExtrajs=$_REQUEST[qpre . "extrajs"];
		$strSearchField=$_REQUEST[qpre . "searchfield"];
		$strSearchString=$_REQUEST[qpre . "searchstring"];
		$intRecord=$_REQUEST[qpre . "rec"];
		$intSearchType=$_REQUEST[qpre . "searchtype"];
		error_reporting($olderror);
		$strPHP=$_SERVER['PHP_SELF'];
		$out="";
		//echo $id . " " .$idfield ;
		$out=LoginDecisions($strDatabase,  $strPHP, $strUser, true);
		
		if ($strUser!="")
		{
		
			$intAdminType= AdministerType($strDatabase, $strTable, $strUser);
	 
			if ($intAdminType>1)
				{
					 
				if ($intSearchType=="")
				{
					$intSearchType=0;
				}
				if ($intRecord=="")
				{
					$intRecord=0;
				}
				
				$out.= "
				<script>
						function handback(tablename, fieldname, thisvalue, prettyname, returnfield, returnid)
						{
							targetfield='" .$launcherfield . "';
							if (opener.document.BForm)
							{
								opener.document.BForm." . $launcherfield . ".value=thisvalue;
								opener.document.BForm[\"" . qpre . "a|" . $launcherfield . "\"].value=prettyname;
							}
							else
							{
								
								opener.top.secondarytool.location.href='tableform.php?' +  returnfield + '=' +  returnid + '&" . qpre . "table=" . $strTable . "&" . qpre . "mode=edit&" . qpre . "id=' + thisvalue + '&" . qpre . "idfield=' + fieldname + '&' + fieldname + '=' + thisvalue + '&" . qpre . "extrajs=closeclickrecycle';
							}
							window.close();
						}
				
				</script>
						";
				
				$out.=  DisplayDataTable($strDatabase, $strTable, $idfield, $strColumn, $strPHP, $strDirection, $intRecord, $strSearchString, $strSearchField, $intSearchType, 50, "", 0,6, false, true, true, $launcherfield);
				}
		}
		$out =  PageHeader($strTable . " Searcher", $strExtrajs) . $out . PageFooter();
		
		return $out;
	}

?>