<?include("admin_functions.php");

$strUser=WhoIsLoggedIn();
$strDatabase=deMoronizeDB(gracefuldecay($_REQUEST[qpre . "db"],our_db));
$strTable=$_REQUEST[qpre . "table"];
if (IsSuperUser($strDatabase, $strUser)  || ($_REQUEST["passcode"]=="spider12"  && !beginswith($strTable, "tf_")  ))
{
	$strWhereclause=$_REQUEST[qpre . "where"];
	$strXML= XMLselect(our_db, $strTable, $strWhereclause);
	$out= makeXMLNode(our_db, "", $strXML);
	header('Content-Type: text/xml');
	header("Content-Length: ". strlen($out));
	echo $out;
}

?>