<?php 
//Gus Mueller February 2007////////////////
//place to test new functions




  
?>