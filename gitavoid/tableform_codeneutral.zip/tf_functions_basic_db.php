<?php 
class sqldb //I'm not big into PHP classes, but I use one here as part of the legacy of how this tool came to be.
{
	var $c=TRUE;
	function disconDB()
	{
		mysql_close($c);
		return($c);
	}
 
	function query($strSQL , $type="gusstyle", $strDatabase="")
	{
		GLOBAL $db_type;
		//if(defined("db_type")  && db_type=="odbc")
		//{
		if( $db_type=="odbc")
		{
			return odbc_query($strSQL);
		}
		//}
	
		if($strDatabase=="")
		{
			$strDatabase=our_db;
		}
		$c=FALSE;
		if(defined("remote_sql_url"))
		{
		
			$out=RemoteSQLCall(remote_sql_url, $strSQL, remote_sql_password);
		}
		else
		{
			if ($type=="gusstyle"  || $type==true)
			{
				//echo $_SERVER["SERVER_NAME"] . "<br>";
				$bwlNeedConnection=false;
				
				if (!$c)
				{
					if(defined("dburl"))
					{
					
					}
					else
					{
						if ($_SERVER["SERVER_NAME"]==optionalhost)
						{
							$c = mysql_connect(con_server_optional, con_user_optional,urldecode(con_pwd_optional));
						}
						else
						{
							$c = mysql_connect(con_server_web, con_user_web, urldecode(con_pwd_web));
							
						}
					}
					//echo $strDatabase .  "<br><b>" .  $strSQL  . "</b><p>";
					mysql_select_db($strDatabase, $c);
					$bwlNeedConnection=true;
				}
				$res= mysql_query($strSQL, $c);
				if ($bwlNeedConnection)
				{
					//mysql_close($c);
				}
	 		}
 
			else
			{
				$res= tep_db_query($strSQL);
			}
			$out=array();
			$count=0;
	
			if (gettype($res)=="resource")
			{
				for ($i=0; $i<mysql_num_rows($res); $i++)
				{
					$record=mysql_fetch_assoc($res);
				 
					$out[$count]=$record;
					$count++;
				}
	 		}
		}
		return $out;
	}	
}


//more complex db funcs

function TableExists($strDatabase, $strTable)
//Does the table exist?
{
 
  	$likeclause="LIKE '" .  $strTable . "'";
	//echo $strTable . "<BR>";
	
	$tables=ListTables($strDatabase, $likeclause);
	//echo count("-" . $tables);
	if (count($tables)<1)
    {
		return(false);
    }
	else 
	{
		return(true);
	}
}

function ListTables($strDatabase, $strLike="")
{
	$arrOut=Array();
	$tables=TableList($strDatabase, $strLike);
	$strFieldName="Tables_in_" . str_replace("`", "", $strDatabase);
	$i=0;
	foreach ($tables as  $k=>$v )
	{
		$tablename= $v[$strFieldName];
		$arrOut[$i]=$tablename;
		$i++;
		//echo $tablename . $strLike . " " . "<BR>";
	}
	//echo   "<BR>";
	return $arrOut;
}

function LookupName($strDatabase, $strTable, $strIDField, $strID, $strNameColumn="")
//Your basic lookup of a name given a table, idfield, and id
//As of Dec 18th, 2007, accepts a $strNameColumn in cases where this is known
{
	$sql=conDB();
	$strSQL="SELECT * FROM " . $strDatabase . "." .  $strTable . " WHERE " .  $strIDField . " = " . $strID;
	//echo "<font color=0000000>" .  $strSQL . "<br>";
	if ($strTable !="")
	{
		$records = $sql->query($strSQL);
		$record=$records[0];
		if($strNameColumn=="")//more complex if you don't have the name column of course
		{
			$strNameField1=NthNonIDColumName($strDatabase, $strTable, 1);
			$strNameField2 = NthNonIDColumName($strDatabase, $strTable, 2);
			//echo $firstnonidcolumn  . "<br>";
		 	//echo $strNameField1 . " " . $strNameField2 . "<br>";
			//fancy code to get text from two fields when one isn't sufficient
			$strLabel1 = $record[$strNameField1];
			$strLabel2 = $record[$strNameField2];
		 	//echo $strLabel1 . " " . $strLabel2  . "<br>";
			
			if ((strlen($strLabel1)<16 && $strLabel2!="" && !(strlen($strLabel2)>14)))
			 {
			 	$strLabel=$strLabel1  . " : " . $strLabel2;
			 }
			else
			{
			 	$strLabel=$strLabel1 ;
			}
		}
		else//you have a name column, so it's easy
		{
			$strLabel=$record[$strNameColumn];
		}
	}
	return $strLabel;
}

function GenericDBLookup($strDB, $strTable, $strIDFieldName, $strThisID, $strResultFieldName="", $bwlDebug=false, $bwlWorkUntilFound=true, $language_id="")
{
	if($strThisID!="")
	{
		return GenericDBLookupWhere($strDB, $strTable,   $strIDFieldName . " = '" . $strThisID . "'", $strResultFieldName, $bwlDebug,  $bwlWorkUntilFound, $language_id);
	}
}

function GenericDBLookupLast($strDB, $strTable, $strIDFieldName, $strThisID, $strResultFieldName, $bwlDebug=false, $bwlWorkUntilFound=true, $language_id="")
{
	$pk=PKLookup($strDB, $strTable);
	return GenericDBLookupWhere($strDB, $strTable,   $strIDFieldName . " = '" . $strThisID . "' ORDER BY " .  $pk. " DESC", $strResultFieldName, $bwlDebug,  $bwlWorkUntilFound, $language_id);
} 

function GenericDBLookupWhere($strDB, $strTable, $strWhereClause, $strResultFieldName="", $bwlDebug=false, $bwlWorkUntilFound=true, $language_id="")
//modified 10-2-2007 to allow for the returning of a whole row
{
	$fieldtosearchfor=$strResultFieldName;
	if($strResultFieldName=="")
	{
		$fieldtosearchfor="*";
	}
	$strSQL="SELECT " . $fieldtosearchfor . " FROM " . $strDB . "." . $strTable . " WHERE " . $strWhereClause;
	if($bwlDebug)
	{
		echo $strSQL . "<br>";
	}
	if($language_id=="")
	{
		$sql=conDB();
		$records = $sql->query($strSQL);
	}
	else
	{
		$records =TranslatedQuery($strSQL, $language_id,  "");
	}

	$record = $records[0];
	//this part of the code keeps scanning through the data until a valid record is found
	if($strResultFieldName=="")
	{
		return $record;
	}
	if (count($records)>1 && $bwlWorkUntilFound  && $strResultFieldName!="")
	{
		foreach($records as $record)
		{
			if($record[$strResultFieldName]!="")
			{
				return $record[$strResultFieldName];
			}
		}
	}
	return $record[$strResultFieldName];
}

function GenericDBLookupFromArray($strDB, $strTable, $arrSpec, $strResultFieldName, $bwlDebug=false, $bwlWorkUntilFound=true)
{
 	$strWhereClause=ArrayToWhereClause($arrSpec);

	return GenericDBLookupWhere($strDB, $strTable, $strWhereClause, $strResultFieldName, $bwlDebug, $bwlWorkUntilFound);
}



function TableExplain($strDatabase, $strTable, $bwlFollowRelations=false)
//explains the columns across several tables linked by relations in the relation table or do a simple explain
{
	GLOBAL $db_type;
	if( $db_type=="odbc")
	{
		return odbc_TableExplain($strDatabase, $strTable, $bwlFollowRelations);
	}
 
	$sql=conDB();
	$arrOut=Array();

	if($bwlFollowRelations)
	{
		$strSQL="SELECT * FROM " . $strDatabase . "." . tfpre . "relation WHERE relation_type_id=0 AND table_name='" . $strTable . "'";
		$records = $sql->query($strSQL);
		foreach($records as $record)
		{
			$strThisTable=$record["f_table_name"];
			$trecords = $sql->query("EXPLAIN " . $strDatabase . "." . $strThisTable);
		 	$arrOut=array_merge($arrOut, $trecords);
		}
	}
	 
	$records = $sql->query("EXPLAIN " . $strDatabase . "." . $strTable);
 
	$arrOut=array_merge($arrOut, $records);
	return $arrOut;
}

function TableFieldsAsBlankRS($strDatabase, $strTable)
{
	$arrOut=Array();
	$arrROut=Array();
	$records = TableExplain($strDatabase, $strTable);
	foreach($records as $record)
	{
		$arrROut[$record["Field"]]="";
	}
	$arrOut[0]=$arrROut;
	return $arrOut;
}

function GetFieldTypeArray($strDatabase, $strTable)
//Give me the types of a columns for a table as an array.
{
	$arrOut=Array();
	$records=TableExplain($strDatabase, $strTable);
	foreach ($records as $k => $v )
	{
		$arrOut[$v["Field"]]= $v["Type"];
	}
	return $arrOut;
}

function GetFieldArray($strDatabase, $strTable)
//Give me an array of field names for a table.
{
	$arrOut=Array();
	$records=TableExplain($strDatabase, $strTable);
	foreach ($records as $k => $v )
	{
		$arrOut[$count]= $v["Field"];
		$count++;
	}
	return $arrOut;
}

function generateFieldTypeArray($strDatabase, $strTable)
//Returns an associative array keyed to the names of columns containing types.
//nov 2006
{
	$arrFieldType=array();
	$descr=TableExplain($strDatabase, $strTable);
	foreach ($descr as $nom=>$info)
	{
		$strName=$info["Field"];
		$strType=TypeParse($info["Type"], 0);
		$arrFieldType[$strName]=$strType;
		
	}
	return $arrFieldType;
}


function UpdateOrInsert($strDatabase, $strTable, $arrDescribedValuePairs, $arrAlteredValuePairs, $bwlEscape=true, $bwlDebug=false)
//Does an insert or an update depending on whether or not the described record exists.  
//Make sure to not include items in $arrAlteredValuePairs that are in  $arrDescribedValuePairs.
//If there are no $arrDescribedValuePairs, they become $arrAlteredValuePairs in an INSERT.
//this function has pretty much replaced my use of explicit SQL for updates and inserts, though Saveform still does things that way
{
	$sql=conDB();
	$strSQL="SELECT * FROM " . $strDatabase . "." .  $strTable . " WHERE ";
	//echo $strSQL . "<p>";
	$strAlterSQL="";
	$strUpdateSQL="";
	$strAlterSetSQL="";
	$bwlMustShortenByFour=false;
	if(is_array($arrDescribedValuePairs))
	{
		foreach($arrDescribedValuePairs as $k=>$v)
		{
			$bwlMustShortenByFour=true;
			$valtostore=$v;
			if($bwlEscape)
			{
	 			$valtostore= singlequoteescape($v);
			}
			if(is_array($arrAlteredValuePairs))
			{
				if(!array_key_exists($k, $arrAlteredValuePairs))
				{
					$strSQL.= " " . $k . "='" . $valtostore . "' AND";
					$strUpdateSQL.= $k . "='" . $valtostore . "',";
					$strAlterWhereSQL.=" " . $k . "='" . $valtostore . "' AND";
				}
			}
			else
			{
				$strSQL.= " " . $k . "='" . $valtostore . "' AND";
				$strUpdateSQL.= $k . "='" . $valtostore . "',";
				$strAlterWhereSQL.=" " . $k . "='" . $valtostore . "' AND";
			}
		
		}
	}
	if(is_array($arrAlteredValuePairs))
	{
		foreach($arrAlteredValuePairs as $k=>$v)
		{
			//echo $k . " " . $v . "==<br>";
			if ($k!="")
			{
				$valtostore=$v;
				if($bwlEscape)
				{
					//echo $v . "<BR>";
		 			$valtostore= singlequoteescape($v);
				}
				$strAlterSetSQL.= $k . "='" . $valtostore . "',";
			}
		}
	}
	//echo "strAlterSetSQL " . $strAlterSetSQL . "<p>";
	if($bwlMustShortenByFour)//gets rid of the " AND"
	{
		$strSQL= substr($strSQL, "0", strlen($strSQL)-4); 
	}
	$strAlterWhereSQL= substr($strAlterWhereSQL, "0", strlen($strAlterWhereSQL)-4); 
 
	$strUpdateSQL= RemoveLastCharacterIfMatch($strUpdateSQL, ",");
	$strAlterSetSQL= RemoveLastCharacterIfMatch($strAlterSetSQL, ",");
	$idInsert="";
	$bwlCanGetInsertID=false;
	$records=$sql->query($strSQL);
	//echo "count records: " . count($records) . "<br>";
	//echo "count descr val pairs: " . count($arrDescribedValuePairs) . "<br>";
	//echo "isarray descr val pairs: " . is_array($arrDescribedValuePairs) . "<br>";
	//echo "strAlterWhereSQL " . $strAlterWhereSQL . "<br>";
	//echo "strAlterSetSQL " . $strAlterSetSQL . "<p>";
	if (count($records)>0 && count($arrDescribedValuePairs)>0   && is_array($arrDescribedValuePairs) && $strAlterWhereSQL!=""  && $strAlterSetSQL!="")
	{
		//need an update
		$strSQL="UPDATE " . $strDatabase . "." .  $strTable . " SET ". $strAlterSetSQL . " WHERE " . $strAlterWhereSQL;
		 
	}
	else if (count($records)<1  ||  !is_array($arrDescribedValuePairs))
	{
		//need an insert
		$strSQL="INSERT INTO " . $strDatabase . "." .  $strTable . " SET ". $strAlterSetSQL . IfAThenB($strAlterSetSQL, ", ") . $strUpdateSQL ;
		$bwlCanGetInsertID=true;
		
	}

	if($strSQL!="")
	{
		$strSQL= RemoveLastCharacterIfMatch($strSQL, " ");
		$strSQL= RemoveLastCharacterIfMatch($strSQL, ",");
	 
		//echo $strSQL . "<br>";
		//die();
	 
		if(CanChange())
		{
			$records = $sql->query($strSQL);
			///echo sql_error() . "<p>";
			//die();
		}
		else
		{
			return "Database is read-only.<br/>";
		}
	
		if($bwlCanGetInsertID)
		{
			 
			$idInsert=sql_insert_id();
		}
		if($bwlDebug=="log")
		{
			
			logmysqlerror($strSQL, true);
		}
		else if($bwlDebug  || $bwlDebug=="die")
		{
			echo "<b>" . $strSQL . "</b><br>";
			echo sql_error() . "<p>";
			if ($bwlDebug=="die")
			{
				die();
			}
		}
	}
	
	//echo $idInsert . "=<br>";
	$out= gracefuldecay(sql_error(),$idInsert) ;
	return $out;
}


function TableList($strDatabase, $likeclause="")
{
	GLOBAL $db_type;
	if( $db_type=="odbc")
	{
		return odbc_TableList($strDatabase, $likeclause="");
	}
	$sql=conDB();
	$strSQL="SHOW TABLES FROM " . $strDatabase . " " .  $likeclause; 
	$records = $sql->query($strSQL);
	return $records;
}

function GetLimitClause($intRecord,  $intRecsPerPage)
{
	GLOBAL $db_type;
	if( $db_type=="odbc")
	{
		return;//no limit clause in odbc, so return for now until i find a workaround
	}
	return " LIMIT " . $intRecord . "," . $intRecsPerPage;
}
function sql_insert_id()
{
	//a wrapper function in case some day we're not using mysql
	return mysql_insert_id();
}

function sql_error()
{
	//a wrapper function in case some day we're not using mysql
	return mysql_error();
}

function conDB()
{
 	$sql=new sqldb();
	return($sql);
}

function disconDB()
{
	mysql_close($c);
	 
	return($c);
}

////////////////
function CanChange()
{
	if(defined("mode"))
	{
		if(contains(mode, 'readonly'))
		{
			return false;
		}
	}
	return true;
}
?>