<?php

function odbc_query($strQuery, $strSpecial="")
{
	//echo "<font color=red>" . $strQuery . "</font><BR>";
	include("odbc_config.php");
	$conn = odbc_connect($connStr,$odbcuser,$odbcpass, SQL_CUR_USE_IF_NEEDED ) or die("Cannot start ADO");
	$recordsout=Array();
	if($strQuery=="tables")
	{
		$result=odbc_tables( $conn);
	}
	else if($strQuery=="columns")
	{
		$result=odbc_columns( $conn, $odbcdb, "%", $strSpecial);
	}
	else if($strQuery=="pks")
	{
		$result=odbc_exec($conn, "sp_pkeys ".$strSpecial);
	}
	else
	{	
		//echo $strQuery . "<p>";
		$result = odbc_exec( $conn, $strQuery);
	}
	
	$rowcount=0;
	$olderror= error_reporting (0);
	if($result)
	{
		if(is_resource($result))
		{
			while($row = odbc_fetch_array($result))
			{
				$arrError=error_get_last;
				if($arrError["type"]>1)
				{
					echo "ERROR DETECTED ON " . $strQuery . " " . $strSpecial . "\n";
				}
				//echo "^woop^" . var_dump($row) . "<p>";
			  	//echo "<li>" . odbc_result($result, "ID") . " ".  odbc_result($result,"TITLE")  . " " . odbc_result($result,"SUBJECT")  .  " " . "</li>";
				$recordsout[$rowcount]=$row;
				$rowcount++;
			}
			
			$arrError=error_get_last;
			if($arrError["type"]>1)
			{
				echo "!ERROR DETECTED ON " . $strQuery . " " . $strSpecial . "\n";
			}
		}
		else
		{
			echo "+ERROR DETECTED ON " . $strQuery . " " . $strSpecial . "\n";
		
		}
	
	}
	else
	{
		echo "=ERROR DETECTED ON " . $strQuery . " " . $strSpecial . "\n";
	}
	error_reporting ($olderror);
	odbc_close($conn);
	return $recordsout;
}

function odbc_TableExplain($strDatabase, $strTable, $bwlFollowRelations=false)
//explains the ms sql columns -- presenting the data in a format identical to the TableExplain function for mysql
{
	$recordout=array();
	$outcount=0;
	$prerecords=odbc_query("columns",  $strTable);
	//echo GenericRSDisplayFromRS($strPHP,"old way", $prerecords, 1, 999);
	foreach($prerecords as $record)
	{

		$columnname=$record["COLUMN_NAME"];
		$typename=$record["TYPE_NAME"];
		$typesize=$record["COLUMN_SIZE"];
		$nullable=$record["NULLABLE"];
		//echo $nullable . "<BR>";
		if(!inList("text", strtolower($typename)))
		{
			$typespec=$typename . "(" .$typesize . ")";
		}
		else
		{
			$typespec=$typename;
		}
		$sqlnullable="NO";
		if($nullable)
		{
			$sqlnullable="YES";
		}
		$arrThisRecord=array("Field"=>$columnname,"Type"=>$typespec, "Null"=>$sqlnullable);
		$recordout[$outcount]=$arrThisRecord;
		$outcount++;
	}
	$prerecords=odbc_query("pks",  $strTable);
	//echo  "<BR>-";
	//foreach($prerecords as $record)
	{
		//foreach($record as $k=>$v)
		{
		//	echo $k . " " . $v . "<BR>";
		}
		//echo  "<BR>-";
		//$pk=$record["PK_NAME"];
	}
	//echo count($prerecords);
	return $recordout;
}

function odbc_TableList($strDatabase, $likeclause="")
{
	$sql=conDB();
	$records=odbc_query("tables");
	$arrOut=Array();
	$outcount=0;
	foreach($records as $record)
	{
		$tablename=$record["TABLE_NAME"];
		
		$tablecat=$record["TABLE_CAT"];
		$tabletype=$record["TABLE_TYPE"];
		if(strtolower($tabletype)=="table")
		{
			//echo $tablename . "<BR>";
			$arrRecord=Array("Tables_in_" . $strDatabase=>$tablename);
			$arrOut[$outcount]=$arrRecord;
			$outcount++;
		}
		
	}
	return $arrOut;
}

//$recs= odbc_TableList("dbo") ;
//echo   GenericRSDisplayFromRS($strPHP,"old way", $recs, 1, 999);
//odbc_TableExplain($strDatabase, $strTable, $bwlFollowRelations);

?>