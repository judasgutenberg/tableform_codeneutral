<?php
//Judas Gutenberg Dec 15 2007
//for compatibilty with old systems that refer to admin_functions.php
//which should have been named core_functions.php
require('core_functions.php');
?>