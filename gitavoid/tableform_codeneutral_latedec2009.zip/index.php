<?php 

header("location: ..");
?>