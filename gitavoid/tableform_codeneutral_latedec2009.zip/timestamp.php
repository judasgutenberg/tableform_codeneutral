<?php 
//Judas Gutenberg January 2006
//provides a web front end admin tool for any MySQL db
//depends on a table called tf_relation for foreign key info
//also needs admin table, permission table, and permission_type table

require('core_functions.php');
require('saveform.php');
require('serializeformfunctions.php');


echo time();
echo "<p>";
echo date(time);

?>