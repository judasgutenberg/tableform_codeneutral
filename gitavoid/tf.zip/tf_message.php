<html>
<head>
<title></title>
<?php
if(array_key_exists("mode", $_REQUEST))
{
	if($_REQUEST["mode"]=="")
	{
	?>
	
	<script>
	window.close();
	
	</script>
	
	<?php
	}
}
?>
</head>
<body>
<script>
//alert(window.name);
//copypaste.location.href='http://yahoo.com';
</script>
<?php

?>
</body>
</html>